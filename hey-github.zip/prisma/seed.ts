import { PrismaClient } from '@prisma/client'
import { hashPassword } from '../src/lib/auth'

const prisma = new PrismaClient()

async function main() {
  // Create admin user
  const adminPassword = await hashPassword('admin123')
  
  const admin = await prisma.user.upsert({
    where: { username: 'admin' },
    update: {
      isAdmin: true
    },
    create: {
      username: 'admin',
      email: 'admin@picsagram.com',
      password: adminPassword,
      fullName: 'Admin',
      isAdmin: true,
      isVerified: true,
    }
  })

  console.log('Admin user created/updated:')
  console.log('Username: admin')
  console.log('Password: admin123')
  console.log('isAdmin:', admin.isAdmin)
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
