import { db } from './src/lib/db'
import bcrypt from 'bcryptjs'

async function seed() {
  console.log('Seeding database...')
  
  // Create users
  const users = []
  const usernames = [
    'travel_adventures', 'food_lovers', 'photography_daily', 'fitness_guru',
    'art_studio', 'nature_explorer', 'tech_news', 'music_vibes',
    'fashion_week', 'coffee_time', 'sunset_chaser', 'wanderlust_soul'
  ]
  
  for (const username of usernames) {
    const hashedPassword = await bcrypt.hash('password123', 10)
    const user = await db.user.create({
      data: {
        username,
        email: `${username}@example.com`,
        password: hashedPassword,
        fullName: username.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '),
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`,
        bio: `Welcome to ${username}'s profile! 🌟`,
        isVerified: Math.random() > 0.5
      }
    })
    users.push(user)
    console.log(`Created user: ${username}`)
  }
  
  // Create posts
  for (let i = 0; i < users.length; i++) {
    const user = users[i]
    const numPosts = Math.floor(Math.random() * 3) + 1
    
    for (let j = 0; j < numPosts; j++) {
      const post = await db.post.create({
        data: {
          authorId: user.id,
          caption: [
            'Exploring new horizons 🌅 #travel #adventure #wanderlust',
            'Delicious moments ✨ #food #foodie #yummy #instafood',
            'Capturing the perfect light 📸 #photography #photooftheday',
            'Push your limits 💪 #fitness #gym #workout #motivation',
            'Art speaks louder than words 🎨 #art #artist #artwork',
            'In nature we find peace 🌿 #nature #outdoors #explore',
            'Innovation never stops 🚀 #tech #technology #startup',
            'Feel the rhythm 🎵 #music #song #vibes #playlist',
            'Style is a way to say who you are 👗 #fashion #style',
            'Coffee and contemplation ☕ #coffee #coffeelover #morning',
          ][Math.floor(Math.random() * 10)],
          location: ['New York, USA', 'Tokyo, Japan', 'Paris, France', 'London, UK', 'Sydney, Australia'][Math.floor(Math.random() * 5)],
          images: {
            create: [{
              url: `https://picsum.photos/seed/${user.username}-${j}/1080/1080`,
              order: 0
            }]
          }
        }
      })
      console.log(`Created post for ${user.username}`)
    }
  }
  
  // Create stories
  for (const user of users.slice(0, 8)) {
    const expiresAt = new Date()
    expiresAt.setHours(expiresAt.getHours() + 24)
    
    await db.story.create({
      data: {
        authorId: user.id,
        type: 'image',
        content: `https://picsum.photos/seed/story-${user.username}/1080/1920`,
        expiresAt
      }
    })
    console.log(`Created story for ${user.username}`)
  }
  
  // Create some follows
  for (let i = 0; i < users.length; i++) {
    for (let j = 0; j < users.length; j++) {
      if (i !== j && Math.random() > 0.5) {
        await db.follow.create({
          data: {
            followerId: users[i].id,
            followingId: users[j].id
          }
        })
      }
    }
  }
  
  // Create some likes
  const allPosts = await db.post.findMany()
  for (const user of users) {
    for (const post of allPosts) {
      if (post.authorId !== user.id && Math.random() > 0.7) {
        await db.like.create({
          data: {
            userId: user.id,
            postId: post.id
          }
        })
      }
    }
  }
  
  console.log('Seeding completed!')
}

seed()
  .catch(console.error)
  .finally(() => db.$disconnect())
