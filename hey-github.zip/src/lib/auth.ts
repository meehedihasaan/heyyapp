import { db } from '@/lib/db'
import { cookies } from 'next/headers'
import { Prisma } from '@prisma/client'

export interface AuthUser {
  id: string
  username: string
  email: string
  fullName: string | null
  avatar: string | null
  coverImage: string | null
  bio: string | null
  website: string | null
  phone: string | null
  gender: string | null
  isVerified: boolean
  isPrivate: boolean
  isAdmin: boolean
  isBanned: boolean
}

export async function hashPassword(password: string): Promise<string> {
  // Simple hash for demo - in production use bcrypt or similar
  const encoder = new TextEncoder()
  const data = encoder.encode(password + 'instagram_salt_2024')
  const hashBuffer = await crypto.subtle.digest('SHA-256', data)
  const hashArray = Array.from(new Uint8Array(hashBuffer))
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('')
}

export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  const hash = await hashPassword(password)
  return hash === hashedPassword
}

export async function getCurrentUser(): Promise<AuthUser | null> {
  try {
    const cookieStore = await cookies()
    const userId = cookieStore.get('userId')?.value
    
    console.log('getCurrentUser - userId from cookie:', userId)
    
    if (!userId) return null
    
    const user = await db.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        username: true,
        email: true,
        fullName: true,
        avatar: true,
        coverImage: true,
        bio: true,
        website: true,
        phone: true,
        gender: true,
        isVerified: true,
        isPrivate: true,
        isAdmin: true,
        isBanned: true,
      }
    })
    
    console.log('getCurrentUser - found user:', user?.id, user?.username)
    
    // Return null if user is banned
    if (user?.isBanned) return null
    
    return user
  } catch (error) {
    console.error('getCurrentUser error:', error)
    return null
  }
}

export async function setCurrentUser(userId: string) {
  const cookieStore = await cookies()
  cookieStore.set('userId', userId, {
    httpOnly: true,
    secure: false,
    sameSite: 'lax',
    maxAge: 60 * 60 * 24 * 7 // 7 days
  })
}

export async function clearCurrentUser() {
  const cookieStore = await cookies()
  cookieStore.delete('userId')
}

export async function getUserStats(userId: string) {
  const [postsCount, followersCount, followingCount] = await Promise.all([
    db.post.count({ where: { authorId: userId } }),
    db.follow.count({ where: { followingId: userId, isAccepted: true } }),
    db.follow.count({ where: { followerId: userId, isAccepted: true } }),
  ])
  
  return { postsCount, followersCount, followingCount }
}

export async function getUserWithStats(userId: string, currentUserId?: string) {
  const user = await db.user.findUnique({
    where: { id: userId },
    select: {
      id: true,
      username: true,
      fullName: true,
      avatar: true,
      coverImage: true,
      bio: true,
      website: true,
      isVerified: true,
      isPrivate: true,
    }
  })
  
  if (!user) return null
  
  const stats = await getUserStats(userId)
  
  let isFollowing = false
  if (currentUserId && currentUserId !== userId) {
    const follow = await db.follow.findUnique({
      where: { followerId_followingId: { followerId: currentUserId, followingId: userId } }
    })
    isFollowing = !!follow
  }
  
  return {
    ...user,
    ...stats,
    isFollowing,
  }
}
