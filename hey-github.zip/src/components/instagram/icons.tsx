'use client'

export function InstagramLogo({ className = '' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 1000 1000" fill="currentColor">
      <path d="M295.42 6c-53.2 2.51-76.9 11.32-104.49 24.62-28.43 13.72-52.61 31.83-76.64 55.86s-42.14 48.21-55.86 76.64c-13.3 27.59-22.11 51.29-24.62 104.49-2.54 53.62-3.17 70.77-3.17 207.39s.63 153.77 3.17 207.39c2.51 53.2 11.32 76.9 24.62 104.49 13.72 28.43 31.83 52.61 55.86 76.64s48.21 42.14 76.64 55.86c27.59 13.3 51.29 22.11 104.49 24.62 53.62 2.54 70.77 3.17 207.39 3.17s153.77-.63 207.39-3.17c53.2-2.51 76.9-11.32 104.49-24.62 28.43-13.72 52.61-31.83 76.64-55.86s42.14-48.21 55.86-76.64c13.3-27.59 22.11-51.29 24.62-104.49 2.54-53.62 3.17-70.77 3.17-207.39s-.63-153.77-3.17-207.39c-2.51-53.2-11.32-76.9-24.62-104.49-13.72-28.43-31.83-52.61-55.86-76.64s-48.21-42.14-76.64-55.86c-27.59-13.3-51.29-22.11-104.49-24.62-53.62-2.54-70.77-3.17-207.39-3.17s-153.77.63-207.39 3.17zm-15 918.32c-48.75-2.21-75.22-10.41-92.86-17.31-23.37-9.09-40-19.94-57.53-37.51s-28.42-34.16-37.51-57.53c-6.9-17.64-15.1-44.11-17.31-92.86-2.39-52.71-2.94-68.51-2.94-201.75s.55-149 2.94-201.75c2.21-48.75 10.41-75.22 17.31-92.86 9.09-23.37 19.94-40 37.51-57.53s34.16-28.42 57.53-37.51c17.64-6.9 44.11-15.1 92.86-17.31 52.71-2.39 68.51-2.94 201.75-2.94s149 .55 201.75 2.94c48.75 2.21 75.22 10.41 92.86 17.31 23.37 9.09 40 19.94 57.53 37.51s28.42 34.16 37.51 57.53c6.9 17.64 15.1 44.11 17.31 92.86 2.39 52.71 2.94 68.51 2.94 201.75s-.55 149-2.94 201.75c-2.21 48.75-10.41 75.22-17.31 92.86-9.09 23.37-19.94 40-37.51 57.53s-34.16 28.42-57.53 37.51c-17.64 6.9-44.11 15.1-92.86 17.31-52.71 2.39-68.51 2.94-201.75 2.94s-149-.55-201.75-2.94z"/>
      <path d="M500 270.31c-139.19 0-252.12 112.93-252.12 252.12S360.81 774.55 500 774.55 752.12 661.62 752.12 522.43 639.19 270.31 500 270.31zm0 406.08c-85.02 0-154.07-69.05-154.07-154.07S414.98 368.36 500 368.36s154.07 69.05 154.07 154.07S585.02 676.39 500 676.39z"/>
      <circle cx="763.39" cy="258.01" r="58.86"/>
    </svg>
  )
}

export function HomeIcon({ className = '', filled = false }: { className?: string; filled?: boolean }) {
  if (filled) {
    return <svg className={className} viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.5c-.276 0-.549.074-.787.213l-7.5 4.5A1.5 1.5 0 0 0 3 8.5V19a2 2 0 0 0 2 2h3v-5.5a1.5 1.5 0 0 1 1.5-1.5h5a1.5 1.5 0 0 1 1.5 1.5V21h3a2 2 0 0 0 2-2V8.5a1.5 1.5 0 0 0-.713-1.287l-7.5-4.5A1.5 1.5 0 0 0 12 2.5z"/></svg>
  }
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path strokeLinecap="round" strokeLinejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
}

export function SearchIcon({ className = '' }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path strokeLinecap="round" d="M21 21l-4.35-4.35"/></svg>
}

export function ExploreIcon({ className = '', filled = false }: { className?: string; filled?: boolean }) {
  if (filled) {
    return <svg className={className} viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zm4.28 5.94l-2.22 5.22a1 1 0 01-.56.56l-5.22 2.22a.75.75 0 01-.98-.98l2.22-5.22a1 1 0 01.56-.56l5.22-2.22a.75.75 0 01.98.98z"/></svg>
  }
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="12" cy="12" r="10"/><polygon points="16.5,7.5 9.5,9.5 7.5,16.5 14.5,14.5" strokeLinecap="round" strokeLinejoin="round" fill="currentColor"/></svg>
}

export function ReelsIcon({ className = '', filled = false }: { className?: string; filled?: boolean }) {
  if (filled) {
    return <svg className={className} viewBox="0 0 24 24" fill="currentColor"><path d="M19.74 2H4.21A2.21 2.21 0 002 4.21v15.58A2.21 2.21 0 004.21 22h15.53A2.21 2.21 0 0022 19.79V4.21A2.21 2.21 0 0019.74 2zM9 17V7l7.5 5L9 17z"/></svg>
  }
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><rect x="2" y="2" width="20" height="20" rx="4"/><polygon points="9.5,7.5 16.5,12 9.5,16.5" fill="currentColor"/></svg>
}

export function MessengerIcon({ className = '' }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path strokeLinecap="round" strokeLinejoin="round" d="M12 3c-4.97 0-9 3.582-9 8s4.03 8 9 8c.634 0 1.25-.062 1.843-.18C15.283 19.62 17.099 20.1 18.4 20.24c.141.015.285-.01.414-.072.335-.159.463-.546.287-.859-.51-.907-.788-1.865-.906-2.512C20.006 15.203 21 12.871 21 11c0-4.418-4.03-8-9-8z"/></svg>
}

export function HeartIcon({ className = '', filled = false }: { className?: string; filled?: boolean }) {
  if (filled) {
    return <svg className={className} viewBox="0 0 24 24" fill="currentColor"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
  }
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path strokeLinecap="round" strokeLinejoin="round" d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
}

export function CommentIcon({ className = '' }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path strokeLinecap="round" strokeLinejoin="round" d="M20.65 12.49c.674 1.053 1.043 2.334.986 3.7-.148 3.525-2.953 6.371-6.477 6.57-1.534.087-2.976-.34-4.153-1.121-.446-.3-1.015-.3-1.46 0a7.503 7.503 0 01-7.06.17 1.5 1.5 0 01-.656-2.067 7.503 7.503 0 00.17-7.06c-.3-.446-.3-1.015 0-1.46a7.503 7.503 0 00-.17-7.06 1.5 1.5 0 01.656-2.067 7.503 7.503 0 017.06-.17c.446.3 1.015.3 1.46 0a7.503 7.503 0 017.06-.17c.987.518 1.37 1.74.853 2.727"/></svg>
}

export function ShareIcon({ className = '' }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path strokeLinecap="round" strokeLinejoin="round" d="M22 3L9.218 10.083M22 3l-6.89 18L12 13.11 4 9l18-6z"/></svg>
}

export function BookmarkIcon({ className = '', filled = false }: { className?: string; filled?: boolean }) {
  if (filled) {
    return <svg className={className} viewBox="0 0 24 24" fill="currentColor"><path d="M5 4c0-1.1.9-2 2-2h10a2 2 0 012 2v16a1 1 0 01-1.581.814L12 17.229l-6.419 3.585A1 1 0 015 20V4z"/></svg>
  }
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path strokeLinecap="round" strokeLinejoin="round" d="M5 5c0-1.1.9-2 2-2h10a2 2 0 012 2v16a1 1 0 01-1.581.814L12 17.229l-6.419 3.585A1 1 0 015 20V5z"/></svg>
}

export function PlusIcon({ className = '' }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path strokeLinecap="round" strokeLinejoin="round" d="M12 5v14M5 12h14"/></svg>
}

export function UserIcon({ className = '', filled = false }: { className?: string; filled?: boolean }) {
  if (filled) {
    return <svg className={className} viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>
  }
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="12" cy="8" r="4"/><path strokeLinecap="round" strokeLinejoin="round" d="M4 20c0-4 4-6 8-6s8 2 8 6"/></svg>
}

export function SettingsIcon({ className = '' }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="12" cy="12" r="3"/><path strokeLinecap="round" strokeLinejoin="round" d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
}

export function MoreIcon({ className = '' }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="1.5"/><circle cx="6" cy="12" r="1.5"/><circle cx="18" cy="12" r="1.5"/></svg>
}

export function CloseIcon({ className = '' }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path strokeLinecap="round" strokeLinejoin="round" d="M18 6L6 18M6 6l12 12"/></svg>
}

export function BackIcon({ className = '' }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M15 18l-6-6 6-6"/></svg>
}

export function GridIcon({ className = '' }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="currentColor"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
}

export function MenuIcon({ className = '' }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16"/></svg>
}

export function CameraIcon({ className = '' }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path strokeLinecap="round" strokeLinejoin="round" d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z"/><circle cx="12" cy="13" r="4"/></svg>
}

export function ImageIcon({ className = '' }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5" fill="currentColor"/><path d="M21 15l-5-5L5 21"/></svg>
}

export function VideoIcon({ className = '' }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><polygon points="23,7 16,12 23,17"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>
}

export function LikeIcon({ className = '' }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
}

export function NotificationsIcon({ className = '' }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
}

export function EditIcon({ className = '' }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path strokeLinecap="round" strokeLinejoin="round" d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path strokeLinecap="round" strokeLinejoin="round" d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
}

export function SendIcon({ className = '' }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path strokeLinecap="round" strokeLinejoin="round" d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/></svg>
}

export function CheckIcon({ className = '' }: { className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/></svg>
}
