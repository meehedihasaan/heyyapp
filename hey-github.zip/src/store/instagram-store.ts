'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export type TabType = 'home' | 'search' | 'explore' | 'reels' | 'create' | 'notifications' | 'messages' | 'profile' | 'settings' | 'story'
export type ThemeType = 'dark' | 'light'

export interface User {
  id: string
  username: string
  fullName: string | null
  avatar: string | null
  coverImage: string | null
  bio: string | null
  website: string | null
  isVerified: boolean
  isPrivate: boolean
  isAdmin: boolean
  isBanned?: boolean
  isFollowing?: boolean
  postsCount?: number
  followersCount?: number
  followingCount?: number
}

export interface Story {
  id: string
  type: 'image' | 'video' | 'text'
  content: string
  bgColor?: string | null
  textColor?: string | null
  duration: number
  createdAt: string
  author: User
  viewers?: { userId: string }[]
}

export interface Post {
  id: string
  caption: string | null
  location: string | null
  createdAt: string
  author: User
  images: { url: string; order: number }[]
  likes: { userId: string }[]
  comments: { id: string; content: string; author: User; createdAt: string }[]
  isSaved?: boolean
  backgroundColor?: string | null
}

export interface Notification {
  id: string
  type: 'like' | 'comment' | 'follow' | 'mention'
  content: string
  isRead: boolean
  createdAt: string
  fromUser?: User
  post?: Post
}

interface InstagramState {
  currentUser: User | null
  isAuthenticated: boolean
  authLoading: boolean
  users: User[]
  stories: Story[]
  posts: Post[]
  notifications: Notification[]
  
  currentTab: TabType
  setCurrentTab: (tab: TabType) => void
  
  selectedPost: Post | null
  setSelectedPost: (post: Post | null) => void
  
  selectedStory: Story | null
  setSelectedStory: (story: Story | null) => void
  selectedStoryUserId: string | null
  setSelectedStoryUserId: (userId: string | null) => void
  
  viewingUserProfile: User | null
  setViewingUserProfile: (user: User | null) => void
  
  setCurrentUser: (user: User | null) => void
  setAuthLoading: (loading: boolean) => void
  setUsers: (users: User[]) => void
  setStories: (stories: Story[]) => void
  setPosts: (posts: Post[]) => void
  setNotifications: (notifications: Notification[]) => void
  
  isCreatePostOpen: boolean
  setCreatePostOpen: (open: boolean) => void
  
  searchQuery: string
  setSearchQuery: (query: string) => void
  
  theme: ThemeType
  setTheme: (theme: ThemeType) => void
}

export const useInstagramStore = create<InstagramState>()(
  persist(
    (set) => ({
      currentUser: null,
      isAuthenticated: false,
      authLoading: true,
      users: [],
      stories: [],
      posts: [],
      notifications: [],
      
      currentTab: 'home',
      setCurrentTab: (tab) => set({ currentTab: tab }),
      
      selectedPost: null,
      setSelectedPost: (post) => set({ selectedPost: post }),
      
      selectedStory: null,
      setSelectedStory: (story) => set({ selectedStory: story }),
      selectedStoryUserId: null,
      setSelectedStoryUserId: (userId) => set({ selectedStoryUserId: userId }),
      
      viewingUserProfile: null,
      setViewingUserProfile: (user) => set({ viewingUserProfile: user }),
      
      setCurrentUser: (user) => set({ currentUser: user, isAuthenticated: !!user, authLoading: false }),
      setAuthLoading: (loading) => set({ authLoading: loading }),
      setUsers: (users) => set({ users }),
      setStories: (stories) => set({ stories }),
      setPosts: (posts) => set({ posts }),
      setNotifications: (notifications) => set({ notifications }),
      
      isCreatePostOpen: false,
      setCreatePostOpen: (open) => set({ isCreatePostOpen: open }),
      
      searchQuery: '',
      setSearchQuery: (query) => set({ searchQuery: query }),
      
      theme: 'dark',
      setTheme: (theme) => set({ theme }),
    }),
    {
      name: 'hey-storage',
      partialize: (state) => ({ 
        theme: state.theme,
        // Don't persist auth state - always validate with server
      }),
    }
  )
)
