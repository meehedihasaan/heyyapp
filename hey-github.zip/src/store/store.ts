'use client'

import { create } from 'zustand'

export type Tab = 'home' | 'search' | 'explore' | 'reels' | 'messages' | 'notifications' | 'create' | 'profile' | 'settings'

interface User {
  id: string
  username: string
  fullName: string | null
  avatar: string | null
  bio: string | null
  isVerified: boolean
  isPrivate: boolean
  website: string | null
  postsCount: number
  followersCount: number
  followingCount: number
  isFollowing?: boolean
}

interface Post {
  id: string
  caption: string | null
  location: string | null
  createdAt: string
  author: User
  images: { url: string }[]
  likesCount: number
  commentsCount: number
  isLiked: boolean
  isSaved: boolean
}

interface Story {
  id: string
  type: string
  content: string
  createdAt: string
  author: User
  isViewed: boolean
}

interface Store {
  currentUser: User | null
  users: User[]
  posts: Post[]
  stories: Story[]
  currentTab: Tab
  isLoading: boolean
  selectedPost: Post | null
  selectedStory: Story | null
  viewedProfile: User | null
  
  setCurrentTab: (tab: Tab) => void
  setCurrentUser: (user: User | null) => void
  setUsers: (users: User[]) => void
  setPosts: (posts: Post[]) => void
  setStories: (stories: Story[]) => void
  setSelectedPost: (post: Post | null) => void
  setSelectedStory: (story: Story | null) => void
  setViewedProfile: (user: User | null) => void
  
  toggleLike: (postId: string) => void
  toggleSave: (postId: string) => void
  toggleFollow: (userId: string) => void
  markStoryViewed: (storyId: string) => void
  
  addPost: (post: Post) => void
  addStory: (story: Story) => void
}

export const useStore = create<Store>((set, get) => ({
  currentUser: null,
  users: [],
  posts: [],
  stories: [],
  currentTab: 'home',
  isLoading: true,
  selectedPost: null,
  selectedStory: null,
  viewedProfile: null,
  
  setCurrentTab: (tab) => set({ currentTab: tab }),
  setCurrentUser: (user) => set({ currentUser: user }),
  setUsers: (users) => set({ users }),
  setPosts: (posts) => set({ posts }),
  setStories: (stories) => set({ stories }),
  setSelectedPost: (post) => set({ selectedPost: post }),
  setSelectedStory: (story) => set({ selectedStory: story }),
  setViewedProfile: (user) => set({ viewedProfile: user }),
  
  toggleLike: (postId) => set((state) => ({
    posts: state.posts.map(post => 
      post.id === postId 
        ? { ...post, isLiked: !post.isLiked, likesCount: post.isLiked ? post.likesCount - 1 : post.likesCount + 1 }
        : post
    )
  })),
  
  toggleSave: (postId) => set((state) => ({
    posts: state.posts.map(post => 
      post.id === postId 
        ? { ...post, isSaved: !post.isSaved }
        : post
    )
  })),
  
  toggleFollow: (userId) => set((state) => ({
    users: state.users.map(user => 
      user.id === userId 
        ? { ...user, isFollowing: !user.isFollowing }
        : user
    ),
    viewedProfile: state.viewedProfile?.id === userId 
      ? { ...state.viewedProfile, isFollowing: !state.viewedProfile.isFollowing }
      : state.viewedProfile
  })),
  
  markStoryViewed: (storyId) => set((state) => ({
    stories: state.stories.map(story => 
      story.id === storyId 
        ? { ...story, isViewed: true }
        : story
    )
  })),
  
  addPost: (post) => set((state) => ({ posts: [post, ...state.posts] })),
  addStory: (story) => set((state) => ({ stories: [story, ...state.stories] }))
}))
