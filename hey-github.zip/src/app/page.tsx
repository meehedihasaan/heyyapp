'use client'

import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react'
import { QRCodeSVG } from 'qrcode.react'
import { useInstagramStore, TabType, User, Post, Story } from '@/store/instagram-store'

// ============ ICONS (Iconly Pro) ============
const Icons = {
  // "hey" logo - pure typography style like Instagram
  Logo: ({ className = '' }: { className?: string }) => (
    <span 
      className={`text-3xl font-normal tracking-normal ${className}`}
      style={{ 
        fontFamily: "'Billabong', 'Grand Hotel', 'Segoe Script', 'Brush Script MT', cursive",
        color: '#4CAF50',
        letterSpacing: '0.02em'
      }}
    >
      hey
    </span>
  ),
  // Logo that adapts to theme
  LogoThemed: ({ isDark, className = '' }: { isDark: boolean; className?: string }) => (
    <span 
      className={`text-3xl font-normal tracking-normal ${className}`}
      style={{ 
        fontFamily: "'Billabong', 'Grand Hotel', 'Segoe Script', 'Brush Script MT', cursive",
        color: '#4CAF50',
        letterSpacing: '0.02em'
      }}
    >
      hey
    </span>
  ),
  // Auth screen logo - large centered typography
  LogoAuth: ({ className = '' }: { className?: string }) => (
    <span 
      className={`text-5xl font-normal tracking-normal ${className}`}
      style={{ 
        fontFamily: "'Billabong', 'Grand Hotel', 'Segoe Script', 'Brush Script MT', cursive",
        color: '#4CAF50',
        letterSpacing: '0.02em'
      }}
    >
      hey
    </span>
  ),
  Home: ({ filled }: { filled?: boolean }) => filled ? (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M9.02 2.84004L3.02 7.74004C2.02 8.56004 1.41 10.16 1.61 11.44L2.76 18.34C3.04 20.03 4.59 21.27 6.29 21.27H17.7C19.39 21.27 20.95 20.02 21.23 18.34L22.38 11.44C22.57 10.16 21.96 8.56004 20.97 7.74004L14.97 2.85004C13.64 1.72004 11.35 1.72004 9.02 2.84004Z" fill="currentColor" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M12 17.27V14.27" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ) : (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M9.02 2.84004L3.02 7.74004C2.02 8.56004 1.41 10.16 1.61 11.44L2.76 18.34C3.04 20.03 4.59 21.27 6.29 21.27H17.7C19.39 21.27 20.95 20.02 21.23 18.34L22.38 11.44C22.57 10.16 21.96 8.56004 20.97 7.74004L14.97 2.85004C13.64 1.72004 11.35 1.72004 9.02 2.84004Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M12 17.27V14.27" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Search: ({ filled }: { filled?: boolean }) => filled ? (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M11 20C15.9706 20 20 15.9706 20 11C20 6.02944 15.9706 2 11 2C6.02944 2 2 6.02944 2 11C2 15.9706 6.02944 20 11 20Z" fill="currentColor"/>
      <path d="M18.9299 20.6898C19.4599 22.2898 20.6699 22.4498 21.5999 21.0498C22.4499 19.7698 21.8899 18.7098 20.3499 18.6998L19.0299 18.6898C18.4699 18.6898 18.0199 18.2498 18.0099 17.6798L17.9499 14.4298C17.9299 12.8898 16.8599 12.2998 15.5699 13.1198C14.1699 14.0298 14.2999 15.2498 15.8899 15.7998" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ) : (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M11 20C15.9706 20 20 15.9706 20 11C20 6.02944 15.9706 2 11 2C6.02944 2 2 6.02944 2 11C2 15.9706 6.02944 20 11 20Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M18.9299 20.6898C19.4599 22.2898 20.6699 22.4498 21.5999 21.0498C22.4499 19.7698 21.8899 18.7098 20.3499 18.6998L19.0299 18.6898C18.4699 18.6898 18.0199 18.2498 18.0099 17.6798L17.9499 14.4298C17.9299 12.8898 16.8599 12.2998 15.5699 13.1198C14.1699 14.0298 14.2999 15.2498 15.8899 15.7998" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Explore: ({ filled }: { filled?: boolean }) => filled ? (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" fill="currentColor"/>
      <path d="M8 12L11 9L15.5 13.5L13.5 15.5L9 11L8 12Z" fill="white"/>
      <path d="M15.5 8.5L9 11L13.5 15.5L16 9L15.5 8.5Z" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ) : (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M15.5 8.5L9 11L13.5 15.5L16 9L15.5 8.5Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Reels: ({ filled }: { filled?: boolean }) => filled ? (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <rect x="2" y="2" width="20" height="20" rx="5" fill="currentColor"/>
      <path d="M9.5 7.5V16.5L16.5 12L9.5 7.5Z" fill="white"/>
    </svg>
  ) : (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <rect x="2" y="2" width="20" height="20" rx="5" stroke="currentColor" strokeWidth="1.5"/>
      <path d="M9.5 7.5V16.5L16.5 12L9.5 7.5Z" fill="currentColor"/>
    </svg>
  ),
  Heart: ({ filled, className }: { filled?: boolean; className?: string }) => filled ? (
    <svg viewBox="0 0 24 24" fill="none" className={`w-6 h-6 ${className || ''}`}>
      <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" fill="currentColor"/>
    </svg>
  ) : (
    <svg viewBox="0 0 24 24" fill="none" className={`w-6 h-6 ${className || ''}`}>
      <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  // Clap icon for text posts
  Clap: ({ filled, className }: { filled?: boolean; className?: string }) => (
    <svg viewBox="0 0 24 24" fill="none" className={`w-6 h-6 ${className || ''}`}>
      {/* Clapping hands */}
      <path 
        d="M11.5 3.5L8 7M12.5 2.5L9.5 5.5M13.5 3.5L10.5 6.5M19 11L15.5 7.5C15.1 7.1 14.5 7.1 14.1 7.5L11.5 10.1C11.1 10.5 11.1 11.1 11.5 11.5L15 15M8 20L4.5 16.5C4.1 16.1 4.1 15.5 4.5 15.1L9.5 10.1C9.9 9.7 10.5 9.7 10.9 10.1L14.5 13.7M8 20L14 14M8 20H5C4.4 20 4 19.6 4 19V16M19 11L22 14M19 11L15 15M19 11V19C19 19.6 18.6 20 18 20H15" 
        stroke="currentColor" 
        strokeWidth={filled ? 0 : 1.5} 
        strokeLinecap="round" 
        strokeLinejoin="round"
        fill={filled ? 'currentColor' : 'none'}
      />
      {/* Sparkles */}
      <circle cx="6" cy="4" r="1" fill={filled ? 'currentColor' : 'none'} />
      <circle cx="3" cy="8" r="0.5" fill={filled ? 'currentColor' : 'none'} />
      <circle cx="21" cy="9" r="1" fill={filled ? 'currentColor' : 'none'} />
    </svg>
  ),
  Comment: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M8.5 19H8C4 19 2 17 2 13V8C2 4 4 2 8 2H16C20 2 22 4 22 8V13C22 17 20 19 16 19H15.5C15.19 19 14.89 19.15 14.7 19.4L13.2 21.4C12.54 22.28 11.46 22.28 10.8 21.4L9.3 19.4C9.14 19.18 8.77 19 8.5 19Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Share: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M22 2L11 13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M22 2L15 22L11 13L2 9L22 2Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Bookmark: ({ filled }: { filled?: boolean }) => filled ? (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M6 4C6 2.9 6.9 2 8 2H16C17.1 2 18 2.9 18 4V22L12 17L6 22V4Z" fill="currentColor"/>
    </svg>
  ) : (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M6 4C6 2.9 6.9 2 8 2H16C17.1 2 18 2.9 18 4V22L12 17L6 22V4Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Plus: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M6 12H18" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M12 6V18" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  User: ({ filled }: { filled?: boolean }) => filled ? (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M12 12C14.7614 12 17 9.76142 17 7C17 4.23858 14.7614 2 12 2C9.23858 2 7 4.23858 7 7C7 9.76142 9.23858 12 12 12Z" fill="currentColor"/>
      <path d="M20.59 22C20.59 18.13 16.74 15 12 15C7.26 15 3.41 18.13 3.41 22" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ) : (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M12 12C14.7614 12 17 9.76142 17 7C17 4.23858 14.7614 2 12 2C9.23858 2 7 4.23858 7 7C7 9.76142 9.23858 12 12 12Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M20.59 22C20.59 18.13 16.74 15 12 15C7.26 15 3.41 18.13 3.41 22" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Settings: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M3 9H21M3 15H21M12 3V21M7 3V21M17 3V21" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <rect x="2" y="8" width="4" height="8" rx="1" fill="currentColor"/>
      <rect x="10" y="6" width="4" height="12" rx="1" fill="currentColor"/>
      <rect x="18" y="10" width="4" height="4" rx="1" fill="currentColor"/>
    </svg>
  ),
  More: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M5 10C3.9 10 3 10.9 3 12C3 13.1 3.9 14 5 14C6.1 14 7 13.1 7 12C7 10.9 6.1 10 5 10Z" fill="currentColor"/>
      <path d="M19 10C17.9 10 17 10.9 17 12C17 13.1 17.9 14 19 14C20.1 14 21 13.1 21 12C21 10.9 20.1 10 19 10Z" fill="currentColor"/>
      <path d="M12 10C10.9 10 10 10.9 10 12C10 13.1 10.9 14 12 14C13.1 14 14 13.1 14 12C14 10.9 13.1 10 12 10Z" fill="currentColor"/>
    </svg>
  ),
  Close: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Back: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M15.5 19L8.5 12L15.5 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Grid: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <rect x="3" y="3" width="8" height="8" rx="2" stroke="currentColor" strokeWidth="1.5"/>
      <rect x="13" y="3" width="8" height="8" rx="2" stroke="currentColor" strokeWidth="1.5"/>
      <rect x="3" y="13" width="8" height="8" rx="2" stroke="currentColor" strokeWidth="1.5"/>
      <rect x="13" y="13" width="8" height="8" rx="2" stroke="currentColor" strokeWidth="1.5"/>
    </svg>
  ),
  Options: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M12 3C10.9 3 10 3.9 10 5C10 6.1 10.9 7 12 7C13.1 7 14 6.1 14 5C14 3.9 13.1 3 12 3Z" fill="currentColor"/>
      <path d="M12 10C10.9 10 10 10.9 10 12C10 13.1 10.9 14 12 14C13.1 14 14 13.1 14 12C14 10.9 13.1 10 12 10Z" fill="currentColor"/>
      <path d="M12 17C10.9 17 10 17.9 10 19C10 20.1 10.9 21 12 21C13.1 21 14 20.1 14 19C14 17.9 13.1 17 12 17Z" fill="currentColor"/>
    </svg>
  ),
  Camera: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M18 6H16.5L15.5 5H8.5L7.5 6H6C4.34 6 3 7.34 3 9V17C3 18.66 4.34 20 6 20H18C19.66 20 21 18.66 21 17V9C21 7.34 19.66 6 18 6Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M12 17C14.2091 17 16 15.2091 16 13C16 10.7909 14.2091 9 12 9C9.79086 9 8 10.7909 8 13C8 15.2091 9.79086 17 12 17Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Edit: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M11 4H4C2.9 4 2 4.9 2 6V20C2 21.1 2.9 22 4 22H18C19.1 22 20 21.1 20 20V13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M18.5 2.50001C19.3284 1.67158 20.6716 1.67158 21.5 2.50001C22.3284 3.32844 22.3284 4.67158 21.5 5.50001L12 15L8 16L9 12L18.5 2.50001Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  ChevronRight: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-4 h-4">
      <path d="M8 4L16 12L8 20" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  // Facebook/Instagram style verified badge - green circle with white checkmark
  Verified: ({ className = '' }: { className?: string }) => (
    <svg viewBox="0 0 24 24" className={`w-[0.875em] h-[0.875em] ${className}`} style={{ verticalAlign: 'baseline' }}>
      {/* Green circle background */}
      <circle cx="12" cy="12" r="10.5" fill="#4CAF50" />
      {/* Subtle inner shadow for depth */}
      <circle cx="12" cy="12" r="10" fill="none" stroke="rgba(255,255,255,0.15)" strokeWidth="0.5" />
      {/* White checkmark - proportional size */}
      <path 
        d="M7 12L10 15L17 8" 
        stroke="white" 
        strokeWidth="2.5" 
        strokeLinecap="round" 
        strokeLinejoin="round"
        fill="none"
      />
    </svg>
  ),
  // Verified badge - larger size for profile headers
  VerifiedLarge: ({ className = '' }: { className?: string }) => (
    <svg viewBox="0 0 24 24" className={`w-5 h-5 ${className}`}>
      {/* Green circle background */}
      <circle cx="12" cy="12" r="10.5" fill="#4CAF50" />
      {/* Subtle inner shadow for depth */}
      <circle cx="12" cy="12" r="10" fill="none" stroke="rgba(255,255,255,0.15)" strokeWidth="0.5" />
      {/* White checkmark - proportional size */}
      <path 
        d="M7 12L10 15L17 8" 
        stroke="white" 
        strokeWidth="2.5" 
        strokeLinecap="round" 
        strokeLinejoin="round"
        fill="none"
      />
    </svg>
  ),
  Logout: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M17 16L21 12L17 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M21 12H9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M9 21H5C3.9 21 3 20.1 3 19V5C3 3.9 3.9 3 5 3H9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Image: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <rect x="3" y="3" width="18" height="18" rx="2" stroke="currentColor" strokeWidth="1.5"/>
      <circle cx="8.5" cy="8.5" r="1.5" fill="currentColor"/>
      <path d="M21 15L16 10L5 21" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Messenger: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M4 12C4 7.58 7.58 4 12 4C16.42 4 20 7.58 20 12C20 16.42 16.42 20 12 20H4L5.5 18.5C4.55 17.17 4 15.62 4 14V12Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M7.5 14L9.5 10L12 13L14 10L16.5 14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
}

// ============ LETTER AVATAR (Z.ai style) ============
const AVATAR_COLORS = [
  'bg-gradient-to-br from-pink-500 to-rose-500',
  'bg-gradient-to-br from-violet-500 to-purple-500',
  'bg-gradient-to-br from-emerald-500 to-teal-500',
  'bg-gradient-to-br from-amber-500 to-orange-500',
  'bg-gradient-to-br from-cyan-500 to-sky-500',
  'bg-gradient-to-br from-rose-500 to-pink-500',
  'bg-gradient-to-br from-indigo-500 to-violet-500',
  'bg-gradient-to-br from-teal-500 to-emerald-500',
  'bg-gradient-to-br from-orange-500 to-amber-500',
  'bg-gradient-to-br from-sky-500 to-cyan-500',
]

function getAvatarColor(name: string): string {
  const charCode = name?.toUpperCase().charCodeAt(0) || 65
  const index = charCode % AVATAR_COLORS.length
  return AVATAR_COLORS[index]
}

function LetterAvatar({ 
  name, 
  username, 
  size = 'md',
  className = '',
  withBorder = true
}: { 
  name?: string | null
  username?: string
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl'
  className?: string
  withBorder?: boolean
}) {
  const displayName = name || username || 'U'
  const initial = displayName?.charAt(0)?.toUpperCase() || 'U'
  const colorClass = getAvatarColor(displayName)
  
  const sizeClasses = {
    xs: 'w-5 h-5 text-[10px]',
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-14 h-14 text-xl',
    xl: 'w-20 h-20 text-3xl',
  }
  
  // Instagram-style thin border (skip for xs size)
  const borderClass = withBorder && size !== 'xs' ? 'border-[1.5px] border-white/20 dark:border-white/10' : ''
  
  return (
    <div 
      className={`${sizeClasses[size]} ${colorClass} ${borderClass} rounded-xl flex items-center justify-center font-semibold text-white select-none flex-shrink-0 overflow-hidden ${className}`}
    >
      {initial}
    </div>
  )
}

// Avatar component that shows image or letter fallback
function Avatar({ 
  src, 
  name, 
  username, 
  size = 'md',
  className = '',
  withBorder = true
}: { 
  src?: string | null
  name?: string | null
  username?: string
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl'
  className?: string
  withBorder?: boolean
}) {
  // Check if src is a valid URL
  if (src && (src.startsWith('http') || src.startsWith('/uploads'))) {
    const sizeClasses = {
      xs: 'w-5 h-5',
      sm: 'w-8 h-8',
      md: 'w-10 h-10',
      lg: 'w-14 h-14',
      xl: 'w-20 h-20',
    }
    // Instagram-style thin border (skip for xs size)
    const borderClass = withBorder && size !== 'xs' ? 'border-[1.5px] border-white/30 dark:border-white/20 shadow-sm' : ''
    return (
      <div className={`${sizeClasses[size]} ${borderClass} rounded-xl overflow-hidden flex-shrink-0 ${className}`}>
        <img 
          src={src} 
          alt={name || username || 'Avatar'} 
          className="w-full h-full object-cover"
        />
      </div>
    )
  }
  
  return <LetterAvatar name={name} username={username} size={size} className={className} withBorder={withBorder} />
}

// ============ SHIMMER/SKELETON COMPONENTS ============
const Shimmer = () => (
  <div className="animate-pulse bg-gradient-to-r from-transparent via-zinc-700/20 to-transparent bg-[length:200%_100%] animate-shimmer" />
)

const SkeletonPostCard = () => {
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'
  
  return (
    <article className={`border-b ${isDark ? 'border-zinc-800 bg-black' : 'border-zinc-200 bg-white'}`}>
      {/* Header Skeleton */}
      <div className="flex items-center justify-between p-3">
        <div className="flex items-center gap-3">
          <div className={`w-8 h-8 rounded-xl animate-pulse ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`} />
          <div className="space-y-2">
            <div className={`h-3 w-24 rounded animate-pulse ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`} />
            <div className={`h-2 w-16 rounded animate-pulse ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`} />
          </div>
        </div>
        <div className={`w-6 h-6 rounded animate-pulse ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`} />
      </div>
      
      {/* Image Skeleton */}
      <div className={`aspect-square animate-pulse ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`} />
      
      {/* Actions Skeleton */}
      <div className="p-3">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-4">
            <div className={`w-6 h-6 rounded animate-pulse ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`} />
            <div className={`w-6 h-6 rounded animate-pulse ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`} />
            <div className={`w-6 h-6 rounded animate-pulse ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`} />
          </div>
          <div className={`w-6 h-6 rounded animate-pulse ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`} />
        </div>
        <div className={`h-3 w-20 rounded animate-pulse ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`} />
      </div>
    </article>
  )
}

const SkeletonStory = () => {
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'
  
  return (
    <div className="flex-shrink-0 flex flex-col items-center w-[72px]">
      <div className={`w-[66px] h-[66px] rounded-xl animate-pulse ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`} />
      <div className={`h-2 w-12 rounded mt-2 animate-pulse ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`} />
    </div>
  )
}

const SkeletonUserRow = () => {
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'
  
  return (
    <div className="flex items-center justify-between py-2">
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 rounded-xl animate-pulse ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`} />
        <div className="space-y-2">
          <div className={`h-3 w-24 rounded animate-pulse ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`} />
          <div className={`h-2 w-32 rounded animate-pulse ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`} />
        </div>
      </div>
      <div className={`h-6 w-16 rounded-lg animate-pulse ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`} />
    </div>
  )
}

// ============ AUTH SCREEN (Threads-style) ============
function AuthScreen({ onAuth }: { onAuth: (user?: any, isNewUser?: boolean) => void }) {
  const [isLogin, setIsLogin] = useState(true)
  const [username, setUsername] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [fullName, setFullName] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      const endpoint = isLogin ? '/api/auth/login' : '/api/auth/register'
      const body = isLogin 
        ? { username, password }
        : { username, email, password, fullName }

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.error || 'Something went wrong')
        setLoading(false)
        return
      }

      // Pass user data and isNewUser flag from response
      onAuth(data.user, data.isNewUser)
    } catch {
      setError('Network error. Please try again.')
      setLoading(false)
    }
  }

  return (
    <div className={`min-h-screen flex flex-col ${isDark ? 'bg-black' : 'bg-white'}`}>
      {/* Main Content */}
      <div className="flex-1 flex flex-col items-center justify-center p-6">
        {/* Logo */}
        <div className="mb-6">
          <Icons.LogoAuth />
        </div>

        {/* Title */}
        <h1 className={`text-2xl font-semibold mb-2 ${isDark ? 'text-white' : 'text-black'}`}>
          {isLogin ? 'Welcome back' : 'Create account'}
        </h1>
        
        <p className={`text-center mb-8 ${isDark ? 'text-zinc-500' : 'text-zinc-600'}`}>
          {isLogin 
            ? 'Log in to your account' 
            : 'Create an account to get started'}
        </p>

        {/* Form */}
        <form onSubmit={handleSubmit} className="w-full max-w-sm space-y-3">
          {!isLogin && (
            <>
              <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={`w-full border rounded-lg px-4 py-3 text-sm placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-500 ${isDark ? 'bg-transparent border-zinc-700 text-white' : 'bg-transparent border-zinc-300 text-black'}`}
                required
              />
              <input
                type="text"
                placeholder="Full Name"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className={`w-full border rounded-lg px-4 py-3 text-sm placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-500 ${isDark ? 'bg-transparent border-zinc-700 text-white' : 'bg-transparent border-zinc-300 text-black'}`}
              />
            </>
          )}
          
          <input
            type="text"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className={`w-full border rounded-lg px-4 py-3 text-sm placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-500 ${isDark ? 'bg-transparent border-zinc-700 text-white' : 'bg-transparent border-zinc-300 text-black'}`}
            required
          />
          
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className={`w-full border rounded-lg px-4 py-3 text-sm placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-500 pr-16 ${isDark ? 'bg-transparent border-zinc-700 text-white' : 'bg-transparent border-zinc-300 text-black'}`}
              required
            />
            {password && (
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-sm font-medium text-zinc-500 hover:text-zinc-400"
              >
                {showPassword ? 'Hide' : 'Show'}
              </button>
            )}
          </div>

          {error && (
            <p className="text-red-500 text-sm text-center py-2">{error}</p>
          )}

          <button
            type="submit"
            disabled={loading || !username || !password || (!isLogin && (!email || !fullName))}
            className={`w-full py-3 rounded-lg font-semibold text-sm transition-colors ${
              isDark 
                ? 'bg-white text-black hover:bg-zinc-200 disabled:bg-zinc-800 disabled:text-zinc-500' 
                : 'bg-black text-white hover:bg-zinc-800 disabled:bg-zinc-200 disabled:text-zinc-400'
            } disabled:cursor-not-allowed`}
          >
            {loading ? (isLogin ? 'Logging in...' : 'Creating account...') : (isLogin ? 'Log in' : 'Create account')}
          </button>
        </form>

        {/* Switch */}
        <div className={`mt-8 pt-6 border-t w-full max-w-sm text-center ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
          <p className={`text-sm ${isDark ? 'text-zinc-400' : 'text-zinc-600'}`}>
            {isLogin ? "Don't have an account? " : "Already have an account? "}
            <button 
              onClick={() => { setIsLogin(!isLogin); setError(''); }} 
              className="font-semibold text-[#4CAF50] hover:underline"
            >
              {isLogin ? 'Sign up' : 'Log in'}
            </button>
          </p>
        </div>
      </div>

      {/* Footer */}
      <div className={`py-6 text-center text-xs ${isDark ? 'text-zinc-600' : 'text-zinc-400'}`}>
        <p>© 2024 hey</p>
      </div>
    </div>
  )
}

// ============ PROFILE PICTURE SETUP ============
function ProfilePictureSetup({ user, onComplete }: { user: User; onComplete: (user: User) => void }) {
  const [avatar, setAvatar] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const formData = new FormData()
    formData.append('file', file)
    try {
      const res = await fetch('/api/upload/image', { method: 'POST', body: formData })
      const data = await res.json()
      if (data.url) setAvatar(data.url)
    } catch (error) {
      console.error('Upload error:', error)
    }
  }

  const handleContinue = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/users/me', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ avatar })
      })
      const data = await res.json()
      onComplete(data.user)
    } catch (error) {
      console.error('Update error:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className={`min-h-screen flex flex-col ${isDark ? 'bg-black' : 'bg-white'}`}>
      <div className="flex-1 flex flex-col items-center justify-center p-6">
        {/* Logo */}
        <div className="mb-6">
          <Icons.LogoAuth />
        </div>

        <h1 className={`text-2xl font-semibold mb-2 ${isDark ? 'text-white' : 'text-black'}`}>
          Add a profile picture
        </h1>
        
        <p className={`text-center mb-8 ${isDark ? 'text-zinc-500' : 'text-zinc-600'}`}>
          Add a photo so your friends know it&apos;s you
        </p>

        {/* Avatar Upload */}
        <div className="mb-8">
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="relative"
          >
            {avatar ? (
              <img 
                src={avatar} 
                alt="Profile" 
                className="w-32 h-32 rounded-full object-cover"
              />
            ) : (
              <div className={`w-32 h-32 rounded-full flex items-center justify-center ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`}>
                <svg className={`w-16 h-16 ${isDark ? 'text-zinc-600' : 'text-zinc-400'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </div>
            )}
            <div className={`absolute bottom-0 right-0 w-10 h-10 rounded-full flex items-center justify-center ${isDark ? 'bg-zinc-700' : 'bg-zinc-300'}`}>
              <svg className={`w-5 h-5 ${isDark ? 'text-white' : 'text-black'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </div>
          </button>
          <input 
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="hidden"
          />
        </div>

        {/* Buttons */}
        <div className="w-full max-w-sm space-y-3">
          <button
            onClick={handleContinue}
            disabled={loading}
            className={`w-full py-3 rounded-lg font-semibold text-sm transition-colors ${
              isDark 
                ? 'bg-white text-black hover:bg-zinc-200 disabled:bg-zinc-800 disabled:text-zinc-500' 
                : 'bg-black text-white hover:bg-zinc-800 disabled:bg-zinc-200 disabled:text-zinc-400'
            } disabled:cursor-not-allowed`}
          >
            {loading ? 'Saving...' : avatar ? 'Continue' : 'Skip for now'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ============ USERNAME SETUP ============
function UsernameSetup({ user, onComplete }: { user: User; onComplete: (user: User) => void }) {
  const [username, setUsername] = useState(user.username || '')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'

  const handleSubmit = async () => {
    if (!username.trim()) {
      setError('Username is required')
      return
    }
    if (username.length < 3) {
      setError('Username must be at least 3 characters')
      return
    }
    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
      setError('Username can only contain letters, numbers, and underscores')
      return
    }

    setLoading(true)
    setError('')
    try {
      const res = await fetch('/api/users/me', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username })
      })
      const data = await res.json()
      if (!res.ok) {
        setError(data.error || 'Failed to update username')
        setLoading(false)
        return
      }
      onComplete(data.user)
    } catch (error) {
      console.error('Update error:', error)
      setError('Something went wrong')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className={`min-h-screen flex flex-col ${isDark ? 'bg-black' : 'bg-white'}`}>
      <div className="flex-1 flex flex-col items-center justify-center p-6">
        {/* Logo */}
        <div className="mb-6">
          <Icons.LogoAuth />
        </div>

        <h1 className={`text-2xl font-semibold mb-2 ${isDark ? 'text-white' : 'text-black'}`}>
          Create a username
        </h1>
        
        <p className={`text-center mb-8 ${isDark ? 'text-zinc-500' : 'text-zinc-600'}`}>
          Choose a unique username for your account
        </p>

        {/* Username Input */}
        <div className="w-full max-w-sm mb-4">
          <input
            type="text"
            placeholder="Username"
            value={username}
            onChange={(e) => { setUsername(e.target.value); setError('') }}
            className={`w-full border rounded-lg px-4 py-3 text-sm placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-[#4CAF50] ${isDark ? 'bg-transparent border-zinc-700 text-white' : 'bg-transparent border-zinc-300 text-black'}`}
          />
          {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
        </div>

        {/* Buttons */}
        <div className="w-full max-w-sm">
          <button
            onClick={handleSubmit}
            disabled={loading || !username.trim()}
            className={`w-full py-3 rounded-lg font-semibold text-sm transition-colors ${
              isDark 
                ? 'bg-white text-black hover:bg-zinc-200 disabled:bg-zinc-800 disabled:text-zinc-500' 
                : 'bg-black text-white hover:bg-zinc-800 disabled:bg-zinc-200 disabled:text-zinc-400'
            } disabled:cursor-not-allowed`}
          >
            {loading ? 'Saving...' : 'Continue'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ============ STORY REACTIONS ============
const STORY_REACTIONS = [
  { type: 'like', emoji: '👍', label: 'Like' },
  { type: 'love', emoji: '❤️', label: 'Love' },
  { type: 'laugh', emoji: '😂', label: 'Haha' },
  { type: 'wow', emoji: '😮', label: 'Wow' },
  { type: 'sad', emoji: '😢', label: 'Sad' },
  { type: 'angry', emoji: '😡', label: 'Angry' },
]

// Helper function to render caption with highlighted hashtags
function renderCaptionWithHashtags(caption: string, isDark: boolean) {
  if (!caption) return null
  
  // Split by hashtag pattern (word starting with #)
  const parts = caption.split(/(\#[\w\u0590-\u05ff]+)/g)
  
  return parts.map((part, index) => {
    if (part.startsWith('#')) {
      // Hashtag - render in green bold
      return (
        <span key={index} className="text-[#4CAF50] font-semibold">
          {part}
        </span>
      )
    }
    // Regular text
    return <span key={index}>{part}</span>
  })
}

// ============ INSTAGRAM-STYLE STORY CARD ============
function StoryCard({ user, hasStory, viewed, storyCount, onClick, onCreate, isOwn }: { 
  user: User
  hasStory: boolean
  viewed: boolean
  storyCount?: number
  onClick: () => void
  onCreate?: () => void
  isOwn?: boolean
}) {
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'

  // Rectangular avatar with gradient border
  return (
    <button 
      onClick={isOwn && !hasStory ? onCreate : onClick} 
      className="flex-shrink-0 flex flex-col items-center w-[72px]"
    >
      {/* Avatar with ring */}
      <div className="relative">
        {/* Gradient ring for unviewed stories */}
        <div className={`w-[66px] h-[66px] rounded-xl p-[2px] ${
          hasStory && !viewed 
            ? 'bg-gradient-to-tr from-[#1B5E20] via-[#4CAF50] to-[#81C784]' 
            : isDark ? 'bg-zinc-700' : 'bg-zinc-300'
        }`}>
          <div className={`w-full h-full rounded-xl p-[2px] ${isDark ? 'bg-black' : 'bg-white'}`}>
            <Avatar src={user.avatar} name={user.fullName} username={user.username} size="md" className="w-full h-full rounded-xl object-cover" />
          </div>
        </div>
        
        {/* Add button for own story */}
        {isOwn && (
          <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-[#4CAF50] border-2 border-black flex items-center justify-center">
            {hasStory ? (
              <span className="text-white text-xs font-bold">+</span>
            ) : (
              <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" />
              </svg>
            )}
          </div>
        )}
      </div>
      
      {/* Username */}
      <span className={`mt-1.5 text-xs truncate max-w-[72px] text-center ${isDark ? 'text-white' : 'text-black'}`}>
        {isOwn ? 'Your story' : user.username}
      </span>
    </button>
  )
}

// ============ STORY VIEWER ============
function StoryViewer({ stories, onClose, onRefresh }: { 
  stories: any[]
  onClose: () => void
  onRefresh: () => void
}) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const progressRef = useRef(0)
  const [displayProgress, setDisplayProgress] = useState(0)
  const timerRef = useRef<NodeJS.Timeout | null>(null)
  const [showReactions, setShowReactions] = useState(false)
  const [showViewers, setShowViewers] = useState(false)
  const [replyText, setReplyText] = useState('')
  const [replies, setReplies] = useState<any[]>([])
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'

  // Handle story progress
  useEffect(() => {
    if (stories.length === 0) return
    
    const story = stories[currentIndex]
    
    // Mark as viewed
    fetch(`/api/stories/${story.id}`, { method: 'POST' }).catch(console.error)
    
    progressRef.current = 0
    
    timerRef.current = setInterval(() => {
      progressRef.current += 2
      setDisplayProgress(progressRef.current)
      
      if (progressRef.current >= 100) {
        if (currentIndex < stories.length - 1) {
          progressRef.current = 0
          setCurrentIndex(i => i + 1)
        } else {
          // Refresh and close
          onRefresh()
          onClose()
        }
      }
    }, 100)

    return () => {
      if (timerRef.current) clearInterval(timerRef.current)
    }
  }, [currentIndex, stories, onClose, onRefresh])
  
  // Initialize replies when story changes
  const currentStory = stories[currentIndex]
  useEffect(() => {
    // Use a ref or handle replies differently to avoid cascading renders
  }, [currentStory?.id])

  const handleReaction = async (type: string) => {
    const story = stories[currentIndex]
    try {
      await fetch(`/api/stories/${story.id}/react`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type })
      })
      setShowReactions(false)
      onRefresh()
    } catch (error) {
      console.error('Reaction error:', error)
    }
  }

  const handleReply = async () => {
    if (!replyText.trim()) return
    const story = stories[currentIndex]
    
    try {
      const res = await fetch(`/api/stories/${story.id}/reply`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: replyText })
      })
      const data = await res.json()
      if (data.reply) {
        setReplies(prev => [...prev, data.reply])
        setReplyText('')
      }
    } catch (error) {
      console.error('Reply error:', error)
    }
  }

  const handleClose = () => {
    onRefresh() // Refresh stories to update viewed status
    onClose()
  }

  if (stories.length === 0) return null

  const story = stories[currentIndex]
  if (!story) return null
  
  const author = story.author || { username: 'Unknown', avatar: null, isVerified: false }

  return (
    <div className="fixed inset-0 bg-black z-50 flex items-center justify-center">
      <div className="relative w-full max-w-md h-full bg-black overflow-hidden">
        {/* Progress bars */}
        <div className="absolute top-2 left-2 right-2 flex gap-1 z-20">
          {stories.map((s, i) => (
            <div key={s.id || i} className="flex-1 h-1 bg-zinc-600 rounded-full overflow-hidden">
              <div 
                className="h-full bg-white transition-all duration-100"
                style={{ width: i < currentIndex ? '100%' : i === currentIndex ? `${displayProgress}%` : '0%' }}
              />
            </div>
          ))}
        </div>

        {/* Header */}
        <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-20">
          <div className="flex items-center gap-2">
            <Avatar src={author.avatar} name={author.fullName} username={author.username} size="md" className="w-10 h-10 rounded-xl border-2 border-white" />
            <div>
              <span className="text-white font-semibold text-sm flex items-center gap-1">
                {author.username}
                {author.isVerified && <Icons.Verified />}
              </span>
              <span className="text-white/70 text-xs">
                {story.createdAt ? new Date(story.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
              </span>
            </div>
          </div>
          <button onClick={handleClose} className="text-white">
            <Icons.Close />
          </button>
        </div>

        {/* Navigation */}
        <button 
          onClick={() => currentIndex > 0 && setCurrentIndex(i => i - 1)}
          className="absolute left-0 top-0 bottom-0 w-1/4 z-10"
        />
        <button 
          onClick={() => currentIndex < stories.length - 1 && setCurrentIndex(i => i + 1)}
          className="absolute right-0 top-0 bottom-0 w-1/4 z-10"
        />

        {/* Content */}
        <div 
          className="absolute inset-0 flex items-center justify-center"
          style={{ backgroundColor: story.bgColor || '#000' }}
        >
          {story.type === 'image' ? (
            <img src={story.content} alt="Story" className="max-w-full max-h-full object-contain" />
          ) : story.type === 'text' ? (
            <p className="text-2xl font-bold text-center px-8" style={{ color: story.textColor || '#fff' }}>
              {story.content}
            </p>
          ) : (
            <video src={story.content} className="max-w-full max-h-full" autoPlay />
          )}
        </div>

        {/* View count */}
        <button 
          onClick={() => setShowViewers(true)}
          className="absolute bottom-24 left-4 text-white/80 text-sm z-20 flex items-center gap-1"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
          </svg>
          {story.viewers?.length || 0} views
        </button>

        {/* Reactions */}
        <div className="absolute bottom-20 left-4 flex gap-2 z-20">
          {story.reactions?.slice(0, 3).map((r: any, i: number) => (
            <span key={r.id} className="text-lg">{STORY_REACTIONS.find(re => re.type === r.type)?.emoji}</span>
          ))}
          {(story.reactions?.length || 0) > 3 && (
            <span className="text-white/70 text-sm">+{story.reactions.length - 3}</span>
          )}
        </div>

        {/* Bottom actions */}
        <div className="absolute bottom-0 left-0 right-0 p-4 z-20 bg-gradient-to-t from-black/80 to-transparent">
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleReply()}
              placeholder="Reply to story..."
              className="flex-1 bg-white/20 text-white placeholder-white/60 rounded-full px-4 py-2 text-sm outline-none"
            />
            <button 
              onClick={() => setShowReactions(!showReactions)}
              className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center"
            >
              <span className="text-lg">😊</span>
            </button>
            <button 
              onClick={handleReply}
              disabled={!replyText.trim()}
              className="w-10 h-10 rounded-full bg-[#4CAF50] flex items-center justify-center disabled:opacity-50"
            >
              <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
              </svg>
            </button>
          </div>
        </div>

        {/* Reactions popup */}
        {showReactions && (
          <div className="absolute bottom-20 left-4 right-4 z-30">
            <div className={`rounded-xl p-3 ${isDark ? 'bg-zinc-900' : 'bg-white'} shadow-lg`}>
              <div className="flex justify-around">
                {STORY_REACTIONS.map((reaction) => (
                  <button
                    key={reaction.type}
                    onClick={() => handleReaction(reaction.type)}
                    className={`flex flex-col items-center p-2 rounded-lg ${story.myReaction === reaction.type ? 'bg-green-500/20' : ''}`}
                  >
                    <span className="text-2xl">{reaction.emoji}</span>
                    <span className={`text-xs ${isDark ? 'text-zinc-400' : 'text-zinc-600'}`}>{reaction.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Viewers modal */}
        {showViewers && (
          <div className="absolute inset-0 bg-black z-30 flex flex-col">
            <div className={`flex items-center gap-3 p-4 border-b ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
              <button onClick={() => setShowViewers(false)}>
                <Icons.Back />
              </button>
              <h2 className="font-semibold">Story Views</h2>
            </div>
            <div className="flex-1 overflow-y-auto">
              {story.viewers?.filter((v: any) => v?.user).map((v: any) => (
                <div key={v.id} className="flex items-center gap-3 p-4">
                  <Avatar src={v.user?.avatar} name={v.user?.fullName} username={v.user?.username} size="md" className="w-10 h-10 rounded-xl" />
                  <div>
                    <span className="font-medium">{v.user?.username || 'Unknown'}</span>
                    <span className={`text-sm ${isDark ? 'text-zinc-400' : 'text-zinc-600'} ml-2`}>
                      {v.viewedAt ? new Date(v.viewedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                    </span>
                  </div>
                </div>
              ))}
              {(!story.viewers || story.viewers.length === 0) && (
                <div className={`text-center py-8 ${isDark ? 'text-zinc-500' : 'text-zinc-600'}`}>
                  No views yet
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

// ============ CREATE STORY (Instagram Full-screen) ============
function CreateStoryModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [mode, setMode] = useState<'camera' | 'text' | 'gallery'>('gallery')
  const [content, setContent] = useState('')
  const [bgColor, setBgColor] = useState('#000')
  const [textColor, setTextColor] = useState('#fff')
  const [loading, setLoading] = useState(false)
  const [textStyle, setTextStyle] = useState<'normal' | 'bold' | 'modern'>('modern')
  const [fontSize, setFontSize] = useState(24)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const { theme, currentUser } = useInstagramStore()
  const isDark = theme === 'dark'

  // Gradient backgrounds for text mode
  const gradients = [
    'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
    'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
    'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
    'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
    'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)',
    'linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)',
    'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
    '#000000',
    '#ffffff',
  ]

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setLoading(true)
    const formData = new FormData()
    formData.append('file', file)

    try {
      const res = await fetch('/api/upload/image', { method: 'POST', body: formData })
      const data = await res.json()
      if (data.url) {
        setContent(data.url)
        setMode('camera') // Show preview
      }
    } catch (error) {
      console.error('Upload error:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async () => {
    if (!content && mode !== 'text') return
    if (mode === 'text' && !content.trim()) return

    setLoading(true)
    try {
      const res = await fetch('/api/stories/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          type: mode === 'text' ? 'text' : 'image', 
          content: mode === 'text' ? content : content, 
          bgColor: mode === 'text' ? bgColor : null, 
          textColor: mode === 'text' ? textColor : null, 
          duration: 5,
          privacy: 'public',
          shareToFeed: false
        })
      })
      
      if (res.ok) {
        onCreated()
        onClose()
      }
    } catch (error) {
      console.error('Create story error:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 bg-black">
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-20">
        <div className="flex items-center justify-between px-4 py-3 safe-area-top">
          <button onClick={onClose} className="p-2 text-white">
            <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
              <path d="M6 18L18 6M6 6l12 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
          
          <div className="flex items-center gap-3">
            {mode !== 'gallery' && (
              <>
                <button className="p-2 text-white">
                  <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
                    <path d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </button>
                <button className="p-2 text-white">
                  <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
                    <path d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" stroke="currentColor" strokeWidth="1.5"/>
                  </svg>
                </button>
              </>
            )}
            <button 
              onClick={handleSubmit}
              disabled={loading || (mode === 'text' ? !content.trim() : mode !== 'gallery' && !content)}
              className="bg-[#4CAF50] text-white px-4 py-1.5 rounded-lg font-semibold text-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? '...' : 'Share'}
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="absolute inset-0 flex items-center justify-center">
        {mode === 'gallery' ? (
          /* Gallery Selection Mode */
          <div className="w-full h-full flex flex-col pt-14">
            {/* Gallery Grid */}
            <div className="flex-1 overflow-y-auto p-2">
              <div className="grid grid-cols-3 gap-1">
                {[...Array(12)].map((_, i) => (
                  <div 
                    key={i} 
                    className="aspect-[9/16] bg-zinc-800 rounded-lg flex items-center justify-center"
                  >
                    <svg viewBox="0 0 24 24" fill="none" className="w-8 h-8 text-zinc-600">
                      <rect x="3" y="3" width="18" height="18" rx="2" stroke="currentColor" strokeWidth="1.5"/>
                      <circle cx="8.5" cy="8.5" r="1.5" fill="currentColor"/>
                      <path d="M21 15L16 10L5 21" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                ))}
              </div>
            </div>

            {/* Gallery Upload Button */}
            <div className="p-4 bg-black">
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="w-full py-3 rounded-lg bg-zinc-800 text-white font-medium flex items-center justify-center gap-2"
              >
                <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5">
                  <rect x="3" y="3" width="18" height="18" rx="2" stroke="currentColor" strokeWidth="1.5"/>
                  <circle cx="8.5" cy="8.5" r="1.5" fill="currentColor"/>
                  <path d="M21 15L16 10L5 21" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                Select from Gallery
              </button>
            </div>
            <input 
              ref={fileInputRef} 
              type="file" 
              accept="image/*" 
              onChange={handleFileChange} 
              className="hidden" 
            />
          </div>
        ) : mode === 'text' ? (
          /* Text Mode */
          <div 
            className="w-full h-full flex items-center justify-center p-8"
            style={{ background: bgColor.startsWith('linear') ? bgColor : bgColor }}
          >
            <textarea
              ref={textareaRef}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Type something..."
              className="w-full h-64 bg-transparent text-center resize-none outline-none placeholder-white/50"
              style={{ 
                color: textColor,
                fontSize: `${fontSize}px`,
                fontWeight: textStyle === 'bold' ? '700' : textStyle === 'modern' ? '600' : '400',
                fontFamily: textStyle === 'modern' ? 'system-ui, -apple-system, sans-serif' : 'inherit',
                lineHeight: 1.3,
              }}
              autoFocus
            />
          </div>
        ) : (
          /* Image Preview */
          content && (
            <img 
              src={content} 
              alt="Story preview" 
              className="w-full h-full object-contain"
            />
          )
        )}
      </div>

      {/* Text Mode Tools */}
      {mode === 'text' && content && (
        <div className="absolute bottom-0 left-0 right-0 z-20">
          {/* Font Style Toggle */}
          <div className="flex justify-center gap-4 py-3 border-t border-white/10 bg-black/50 backdrop-blur-sm">
            <button 
              onClick={() => setTextStyle('normal')}
              className={`px-4 py-2 rounded-full text-sm ${textStyle === 'normal' ? 'bg-white text-black' : 'text-white/70'}`}
            >
              Normal
            </button>
            <button 
              onClick={() => setTextStyle('bold')}
              className={`px-4 py-2 rounded-full text-sm font-bold ${textStyle === 'bold' ? 'bg-white text-black' : 'text-white/70'}`}
            >
              Bold
            </button>
            <button 
              onClick={() => setTextStyle('modern')}
              className={`px-4 py-2 rounded-full text-sm ${textStyle === 'modern' ? 'bg-white text-black' : 'text-white/70'}`}
            >
              Modern
            </button>
          </div>

          {/* Background Colors */}
          <div className="flex gap-2 px-4 py-3 overflow-x-auto bg-black/50 backdrop-blur-sm">
            {gradients.map((gradient, i) => (
              <button
                key={i}
                onClick={() => {
                  setBgColor(gradient)
                  setTextColor(gradient === '#ffffff' ? '#000' : '#fff')
                }}
                className={`w-10 h-10 rounded-full flex-shrink-0 border-2 ${bgColor === gradient ? 'border-white' : 'border-transparent'}`}
                style={{ background: gradient }}
              />
            ))}
          </div>

          {/* Font Size Slider */}
          <div className="flex items-center gap-3 px-4 py-3 bg-black/50 backdrop-blur-sm">
            <span className="text-white/50 text-xs">A</span>
            <input
              type="range"
              min="16"
              max="48"
              value={fontSize}
              onChange={(e) => setFontSize(Number(e.target.value))}
              className="flex-1 accent-white"
            />
            <span className="text-white text-lg">A</span>
          </div>
        </div>
      )}

      {/* Image Preview Tools */}
      {mode === 'camera' && content && (
        <div className="absolute bottom-0 left-0 right-0 z-20">
          {/* Drawing/Text Tools */}
          <div className="flex justify-around py-4 bg-black/50 backdrop-blur-sm">
            <button className="flex flex-col items-center gap-1 text-white/70">
              <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
                <path d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="text-xs">Draw</span>
            </button>
            <button className="flex flex-col items-center gap-1 text-white/70">
              <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
                <path d="M4 7V4h3M20 7V4h-3M4 17v3h3M20 17v3h-3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="text-xs">Text</span>
            </button>
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="flex flex-col items-center gap-1 text-white/70"
            >
              <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
                <rect x="3" y="3" width="18" height="18" rx="2" stroke="currentColor" strokeWidth="1.5"/>
                <circle cx="8.5" cy="8.5" r="1.5" fill="currentColor"/>
                <path d="M21 15L16 10L5 21" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="text-xs">Photo</span>
            </button>
            <button className="flex flex-col items-center gap-1 text-white/70">
              <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
                <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="1.5"/>
                <path d="M12 8v4l2 2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
              <span className="text-xs">Timer</span>
            </button>
          </div>
        </div>
      )}

      {/* Bottom Mode Selector */}
      <div className="absolute bottom-0 left-0 right-0 z-20 safe-area-bottom">
        {/* Create Story Label */}
        <div className="flex justify-center py-3">
          <span className="text-white font-semibold">Create story</span>
        </div>

        {/* Mode Tabs */}
        <div className="flex justify-center gap-8 pb-4">
          <button 
            onClick={() => setMode('camera')}
            className={`flex flex-col items-center gap-1 ${mode === 'camera' ? 'text-white' : 'text-white/50'}`}
          >
            <svg viewBox="0 0 24 24" fill="none" className="w-7 h-7">
              <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" stroke="currentColor" strokeWidth="1.5"/>
              <circle cx="12" cy="13" r="4" stroke="currentColor" strokeWidth="1.5"/>
            </svg>
            <span className="text-xs">Camera</span>
          </button>
          
          <button 
            onClick={() => setMode('gallery')}
            className={`flex flex-col items-center gap-1 ${mode === 'gallery' ? 'text-white' : 'text-white/50'}`}
          >
            <svg viewBox="0 0 24 24" fill="none" className="w-7 h-7">
              <rect x="3" y="3" width="18" height="18" rx="2" stroke="currentColor" strokeWidth="1.5"/>
              <circle cx="8.5" cy="8.5" r="1.5" fill="currentColor"/>
              <path d="M21 15L16 10L5 21" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="text-xs">Gallery</span>
          </button>
          
          <button 
            onClick={() => { setMode('text'); setContent(''); }}
            className={`flex flex-col items-center gap-1 ${mode === 'text' ? 'text-white' : 'text-white/50'}`}
          >
            <svg viewBox="0 0 24 24" fill="none" className="w-7 h-7">
              <path d="M4 7V4h16v3M9 20h6M12 4v16" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="text-xs">Text</span>
          </button>
          
          <button 
            onClick={() => setMode('camera')}
            className={`flex flex-col items-center gap-1 ${mode === 'camera' ? 'text-white' : 'text-white/50'}`}
          >
            <svg viewBox="0 0 24 24" fill="none" className="w-7 h-7">
              <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="1.5"/>
              <path d="M16 12l-4-4-4 4M12 16V8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="text-xs">Boomerang</span>
          </button>
        </div>
      </div>

      {/* Side Tools for Camera Mode */}
      {(mode === 'camera' || mode === 'text') && (
        <div className="absolute right-3 top-1/2 -translate-y-1/2 z-20 flex flex-col gap-4">
          <button className="p-2 text-white">
            <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
              <path d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
            </svg>
          </button>
          <button className="p-2 text-white">
            <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
              <path d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        </div>
      )}
    </div>
  )
}

// ============ VERIFICATION MODAL ============
function VerificationModal({ onClose, onVerified }: { onClose: () => void; onVerified: () => void }) {
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [existingRequest, setExistingRequest] = useState<any>(null)
  const [formData, setFormData] = useState({
    fullName: '',
    category: 'Personal',
    idType: 'passport',
    idNumber: '',
    idImageUrl: '',
    selfieUrl: '',
  })
  const idInputRef = useRef<HTMLInputElement>(null)
  const selfieInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    fetch('/api/verification')
      .then(r => r.json())
      .then(data => {
        if (data.request) {
          setExistingRequest(data.request)
        }
      })
      .catch(console.error)
  }, [])

  const handleIdUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setLoading(true)
    const form = new FormData()
    form.append('file', file)

    try {
      const res = await fetch('/api/upload/image', { method: 'POST', body: form })
      const data = await res.json()
      if (data.url) {
        setFormData(prev => ({ ...prev, idImageUrl: data.url }))
      }
    } catch (error) {
      console.error('Upload error:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSelfieUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setLoading(true)
    const form = new FormData()
    form.append('file', file)

    try {
      const res = await fetch('/api/upload/image', { method: 'POST', body: form })
      const data = await res.json()
      if (data.url) {
        setFormData(prev => ({ ...prev, selfieUrl: data.url }))
      }
    } catch (error) {
      console.error('Upload error:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/verification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      })
      const data = await res.json()
      if (res.ok) {
        onVerified()
        onClose()
      } else {
        alert(data.error || 'Failed to submit')
      }
    } catch (error) {
      console.error('Submit error:', error)
    } finally {
      setLoading(false)
    }
  }

  // Show existing request status
  if (existingRequest) {
    return (
      <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
        <div className={`rounded-xl w-full max-w-md ${isDark ? 'bg-zinc-900' : 'bg-white'}`}>
          <div className="flex items-center justify-between p-4 border-b border-zinc-800">
            <button onClick={onClose}><Icons.Close /></button>
            <h2 className="font-semibold">Verification Status</h2>
            <div className="w-6" />
          </div>
          <div className="p-6 text-center">
            {existingRequest.status === 'pending' && (
              <>
                <div className="w-16 h-16 rounded-full bg-yellow-500/20 flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold mb-2">Request Pending</h3>
                <p className="text-zinc-500 text-sm">Your verification request is being reviewed. This usually takes 1-3 business days.</p>
              </>
            )}
            {existingRequest.status === 'approved' && (
              <>
                <div className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-4">
                  <Icons.Verified />
                </div>
                <h3 className="text-lg font-semibold mb-2">Verified!</h3>
                <p className="text-zinc-500 text-sm">Congratulations! Your account has been verified.</p>
              </>
            )}
            {existingRequest.status === 'rejected' && (
              <>
                <div className="w-16 h-16 rounded-full bg-red-500/20 flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </div>
                <h3 className="text-lg font-semibold mb-2">Request Rejected</h3>
                <p className="text-zinc-500 text-sm mb-4">{existingRequest.reason || 'Your verification request was rejected.'}</p>
                <button 
                  onClick={() => setExistingRequest(null)}
                  className="bg-[#4CAF50] text-white px-6 py-2 rounded-lg"
                >
                  Try Again
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
      <div className={`rounded-xl w-full max-w-md max-h-[90vh] overflow-y-auto ${isDark ? 'bg-zinc-900' : 'bg-white'}`}>
        <div className={`flex items-center justify-between p-4 border-b ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
          <button onClick={onClose}><Icons.Close /></button>
          <h2 className="font-semibold">Request Verification</h2>
          <div className="w-6" />
        </div>

        <div className="p-4">
          {step === 1 && (
            <div className="space-y-4">
              <p className={`text-sm ${isDark ? 'text-zinc-400' : 'text-zinc-600'}`}>
                Submit a request to get your account verified. You'll need to provide a government-issued ID.
              </p>
              
              <div>
                <label className={`text-xs ${isDark ? 'text-zinc-500' : 'text-zinc-600'}`}>Full Legal Name</label>
                <input
                  type="text"
                  value={formData.fullName}
                  onChange={(e) => setFormData(prev => ({ ...prev, fullName: e.target.value }))}
                  className={`w-full border rounded-lg p-3 mt-1 ${isDark ? 'bg-zinc-800 border-zinc-700' : 'bg-zinc-100 border-zinc-300'}`}
                  placeholder="As shown on your ID"
                />
              </div>

              <div>
                <label className={`text-xs ${isDark ? 'text-zinc-500' : 'text-zinc-600'}`}>Category</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
                  className={`w-full border rounded-lg p-3 mt-1 ${isDark ? 'bg-zinc-800 border-zinc-700' : 'bg-zinc-100 border-zinc-300'}`}
                >
                  <option value="Personal">Personal</option>
                  <option value="Creator">Creator</option>
                  <option value="Business">Business</option>
                </select>
              </div>

              <button
                onClick={() => setStep(2)}
                disabled={!formData.fullName}
                className="w-full bg-[#4CAF50] text-white py-3 rounded-lg font-semibold disabled:opacity-50"
              >
                Next
              </button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <div>
                <label className={`text-xs ${isDark ? 'text-zinc-500' : 'text-zinc-600'}`}>ID Type</label>
                <select
                  value={formData.idType}
                  onChange={(e) => setFormData(prev => ({ ...prev, idType: e.target.value }))}
                  className={`w-full border rounded-lg p-3 mt-1 ${isDark ? 'bg-zinc-800 border-zinc-700' : 'bg-zinc-100 border-zinc-300'}`}
                >
                  <option value="passport">Passport</option>
                  <option value="drivers_license">Driver's License</option>
                  <option value="national_id">National ID Card</option>
                </select>
              </div>

              <div>
                <label className={`text-xs ${isDark ? 'text-zinc-500' : 'text-zinc-600'}`}>ID Number</label>
                <input
                  type="text"
                  value={formData.idNumber}
                  onChange={(e) => setFormData(prev => ({ ...prev, idNumber: e.target.value }))}
                  className={`w-full border rounded-lg p-3 mt-1 ${isDark ? 'bg-zinc-800 border-zinc-700' : 'bg-zinc-100 border-zinc-300'}`}
                  placeholder="Enter your ID number"
                />
              </div>

              <div>
                <label className={`text-xs ${isDark ? 'text-zinc-500' : 'text-zinc-600'}`}>Upload ID Photo</label>
                <div 
                  onClick={() => idInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer mt-1 ${isDark ? 'border-zinc-700' : 'border-zinc-300'}`}
                >
                  {formData.idImageUrl ? (
                    <img src={formData.idImageUrl} alt="ID" className="max-h-32 mx-auto rounded" />
                  ) : (
                    <>
                      <Icons.Camera />
                      <p className="text-sm mt-2">Click to upload photo of your ID</p>
                    </>
                  )}
                </div>
                <input ref={idInputRef} type="file" accept="image/*" onChange={handleIdUpload} className="hidden" />
              </div>

              <div className="flex gap-2">
                <button onClick={() => setStep(1)} className={`flex-1 py-3 rounded-lg font-semibold ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`}>
                  Back
                </button>
                <button
                  onClick={() => setStep(3)}
                  disabled={!formData.idNumber || !formData.idImageUrl}
                  className="flex-1 bg-[#4CAF50] text-white py-3 rounded-lg font-semibold disabled:opacity-50"
                >
                  Next
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <p className={`text-sm ${isDark ? 'text-zinc-400' : 'text-zinc-600'}`}>
                Upload a selfie holding your ID next to your face for verification.
              </p>

              <div 
                onClick={() => selfieInputRef.current?.click()}
                className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer ${isDark ? 'border-zinc-700' : 'border-zinc-300'}`}
              >
                {formData.selfieUrl ? (
                  <img src={formData.selfieUrl} alt="Selfie" className="max-h-32 mx-auto rounded" />
                ) : (
                  <>
                    <Icons.Camera />
                    <p className="text-sm mt-2">Click to upload selfie with ID</p>
                  </>
                )}
              </div>
              <input ref={selfieInputRef} type="file" accept="image/*" onChange={handleSelfieUpload} className="hidden" />

              <div className="flex gap-2">
                <button onClick={() => setStep(2)} className={`flex-1 py-3 rounded-lg font-semibold ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`}>
                  Back
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={loading || !formData.selfieUrl}
                  className="flex-1 bg-[#4CAF50] text-white py-3 rounded-lg font-semibold disabled:opacity-50"
                >
                  {loading ? 'Submitting...' : 'Submit Request'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ============ POST OPTIONS MENU (Instagram-style bottom sheet) ============
function PostOptionsMenu({ 
  post, 
  isOwnPost, 
  isSaved,
  onClose, 
  onEdit, 
  onDelete, 
  onSave,
  onShare,
  onCopyLink,
  onHide
}: { 
  post: Post
  isOwnPost: boolean
  isSaved: boolean
  onClose: () => void
  onEdit: () => void
  onDelete: () => void
  onSave: () => void
  onShare: () => void
  onCopyLink: () => void
  onHide: () => void
}) {
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)

  const menuItems = isOwnPost ? [
    { icon: '✏️', label: 'Edit', onClick: () => { onEdit(); onClose() }, danger: false },
    { icon: '🔖', label: isSaved ? 'Remove from saved' : 'Save', onClick: () => { onSave(); onClose() }, danger: false },
    { icon: '🔗', label: 'Copy link', onClick: () => { onCopyLink(); onClose() }, danger: false },
    { icon: '📤', label: 'Share', onClick: () => { onShare(); onClose() }, danger: false },
    { icon: '🚫', label: 'Hide like count', onClick: () => { onHide(); onClose() }, danger: false },
    { icon: '🗑️', label: 'Delete', onClick: () => setShowDeleteConfirm(true), danger: true },
  ] : [
    { icon: '🔖', label: isSaved ? 'Remove from saved' : 'Save', onClick: () => { onSave(); onClose() }, danger: false },
    { icon: '🔗', label: 'Copy link', onClick: () => { onCopyLink(); onClose() }, danger: false },
    { icon: '📤', label: 'Share', onClick: () => { onShare(); onClose() }, danger: false },
    { icon: '🚫', label: 'Hide', onClick: () => { onHide(); onClose() }, danger: false },
    { icon: '⚠️', label: 'Report', onClick: () => { onClose() }, danger: true },
  ]

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50" onClick={onClose}>
      <div 
        className={`w-full max-w-lg rounded-t-xl overflow-hidden transform transition-transform ${isDark ? 'bg-zinc-900' : 'bg-white'}`}
        onClick={e => e.stopPropagation()}
      >
        {/* Handle bar */}
        <div className="flex justify-center py-3">
          <div className={`w-10 h-1 rounded-full ${isDark ? 'bg-zinc-700' : 'bg-zinc-300'}`} />
        </div>

        {!showDeleteConfirm ? (
          <>
            {/* Menu Items */}
            <div className={`divide-y ${isDark ? 'divide-zinc-800' : 'divide-zinc-200'}`}>
              {menuItems.map((item, index) => (
                <button
                  key={index}
                  onClick={item.onClick}
                  className={`w-full flex items-center gap-4 px-6 py-4 text-left transition-colors ${
                    item.danger 
                      ? 'text-red-500 hover:bg-red-500/10' 
                      : isDark 
                        ? 'hover:bg-zinc-800 text-white' 
                        : 'hover:bg-zinc-100 text-black'
                  }`}
                >
                  <span className="text-xl">{item.icon}</span>
                  <span className="font-medium">{item.label}</span>
                </button>
              ))}
            </div>

            {/* Cancel Button */}
            <button 
              onClick={onClose}
              className={`w-full py-4 border-t font-semibold ${
                isDark 
                  ? 'border-zinc-800 hover:bg-zinc-800 text-white' 
                  : 'border-zinc-200 hover:bg-zinc-100 text-black'
              }`}
            >
              Cancel
            </button>
          </>
        ) : (
          /* Delete Confirmation */
          <div className="p-4">
            <div className="text-center mb-4">
              <p className="font-semibold text-lg">Delete Post?</p>
              <p className={`text-sm mt-2 ${isDark ? 'text-zinc-400' : 'text-zinc-600'}`}>
                Are you sure you want to delete this post? This action cannot be undone.
              </p>
            </div>
            <button
              onClick={() => { onDelete(); onClose() }}
              className="w-full py-3 bg-red-500 text-white rounded-lg font-semibold mb-2 hover:bg-red-600"
            >
              Delete
            </button>
            <button
              onClick={() => setShowDeleteConfirm(false)}
              className={`w-full py-3 rounded-lg font-semibold ${
                isDark ? 'bg-zinc-800 text-white hover:bg-zinc-700' : 'bg-zinc-200 text-black hover:bg-zinc-300'
              }`}
            >
              Cancel
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

// ============ EDIT POST MODAL ============
function EditPostModal({ post, onClose, onUpdated }: { 
  post: Post
  onClose: () => void
  onUpdated: (caption: string) => void
}) {
  const [caption, setCaption] = useState(post.caption || '')
  const [loading, setLoading] = useState(false)
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'

  const handleSave = async () => {
    setLoading(true)
    try {
      const res = await fetch(`/api/posts/${post.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ caption })
      })
      if (res.ok) {
        onUpdated(caption)
        onClose()
      }
    } catch (error) {
      console.error('Edit post error:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center p-4 ${isDark ? 'bg-black/80' : 'bg-black/50'}`}>
      <div className={`rounded-xl w-full max-w-md overflow-hidden ${isDark ? 'bg-zinc-900' : 'bg-white'}`}>
        {/* Header */}
        <div className={`flex items-center justify-between p-4 border-b ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
          <button onClick={onClose} className={isDark ? 'text-white' : 'text-black'}>
            <Icons.Close />
          </button>
          <span className="font-semibold">Edit Info</span>
          <button 
            onClick={handleSave} 
            disabled={loading}
            className="text-[#4CAF50] font-semibold disabled:opacity-50"
          >
            {loading ? 'Saving...' : 'Done'}
          </button>
        </div>

        {/* Content */}
        <div className="p-4">
          {/* Image Preview */}
          <div className="flex gap-3 mb-4">
            <img 
              src={post.images[0]?.url} 
              alt="Post" 
              className="w-16 h-16 rounded object-cover flex-shrink-0"
            />
            <textarea
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              placeholder="Write a caption..."
              className={`flex-1 rounded-lg p-3 text-sm resize-none h-24 outline-none ${
                isDark ? 'bg-zinc-800 placeholder-zinc-500 text-white' : 'bg-zinc-100 placeholder-zinc-500 text-black'
              }`}
            />
          </div>
        </div>
      </div>
    </div>
  )
}

// ============ SHARE POST MODAL ============
function SharePostModal({ post, onClose }: { 
  post: Post
  onClose: () => void
}) {
  const [copied, setCopied] = useState(false)
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'
  
  const postUrl = typeof window !== 'undefined' 
    ? `${window.location.origin}?post=${post.id}`
    : ''

  const handleCopyLink = async () => {
    await navigator.clipboard.writeText(postUrl)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleSharePost = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${post.author.username}'s post on hey`,
          text: post.caption || 'Check out this post on hey',
          url: postUrl
        })
      } catch {
        // User cancelled share
      }
    } else {
      handleCopyLink()
    }
  }

  const shareOptions = [
    { icon: '📋', label: 'Copy link', onClick: handleCopyLink },
    { icon: '📷', label: 'Share to Story', onClick: () => {} },
    { icon: '💬', label: 'Share to Messenger', onClick: () => {} },
    { icon: '🐦', label: 'Share to Twitter', onClick: () => window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(post.caption || 'Check this out')}&url=${encodeURIComponent(postUrl)}`) },
    { icon: '📘', label: 'Share to Facebook', onClick: () => window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(postUrl)}`) },
    { icon: '📧', label: 'Share via Email', onClick: () => window.open(`mailto:?subject=${encodeURIComponent('Check out this post')}&body=${encodeURIComponent(postUrl)}`) },
  ]

  return (
    <div className={`fixed inset-0 z-50 flex items-end justify-center bg-black/50`} onClick={onClose}>
      <div 
        className={`w-full max-w-lg rounded-t-xl overflow-hidden ${isDark ? 'bg-zinc-900' : 'bg-white'}`}
        onClick={e => e.stopPropagation()}
      >
        {/* Handle bar */}
        <div className="flex justify-center py-3">
          <div className={`w-10 h-1 rounded-full ${isDark ? 'bg-zinc-700' : 'bg-zinc-300'}`} />
        </div>

        {/* Header */}
        <div className={`px-6 py-4 border-b ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
          <h3 className="font-semibold text-center">Share</h3>
        </div>

        {/* Share Options */}
        <div className="p-4">
          {/* Post Preview */}
          <div className="flex items-center gap-3 mb-4 p-3 rounded-lg bg-zinc-100 dark:bg-zinc-800">
            <img 
              src={post.images[0]?.url} 
              alt="Post" 
              className="w-12 h-12 rounded object-cover"
            />
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm truncate">{post.author.username}</p>
              <p className="text-xs text-zinc-500 truncate">{post.caption || 'No caption'}</p>
            </div>
          </div>

          {/* Quick Share Buttons */}
          <div className="flex gap-3 overflow-x-auto pb-4">
            {shareOptions.map((option, index) => (
              <button
                key={index}
                onClick={option.onClick}
                className="flex flex-col items-center gap-2 flex-shrink-0"
              >
                <div className={`w-14 h-14 rounded-full flex items-center justify-center text-2xl ${
                  isDark ? 'bg-zinc-800' : 'bg-zinc-200'
                }`}>
                  {option.icon}
                </div>
                <span className={`text-xs ${isDark ? 'text-zinc-400' : 'text-zinc-600'}`}>{option.label}</span>
              </button>
            ))}
          </div>

          {/* QR Code Section */}
          <div className="flex flex-col items-center py-4 border-t border-zinc-200 dark:border-zinc-800">
            <div className="p-3 bg-white rounded-2xl">
              <QRCodeSVG 
                value={postUrl}
                size={150}
                level="H"
                bgColor="#ffffff"
                fgColor="#000000"
              />
            </div>
            <p className={`text-xs mt-2 ${isDark ? 'text-zinc-400' : 'text-zinc-600'}`}>
              Scan to view post
            </p>
          </div>
        </div>

        {/* Share Button */}
        <div className={`p-4 border-t ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
          <button
            onClick={handleSharePost}
            className="w-full bg-[#4CAF50] text-white py-3 rounded-lg font-semibold hover:bg-[#4CAF50] transition-colors"
          >
            Share Post
          </button>
          {copied && (
            <p className="text-center text-green-500 text-sm mt-2">✓ Link copied!</p>
          )}
        </div>

        {/* Cancel */}
        <button 
          onClick={onClose}
          className={`w-full py-4 border-t font-semibold ${
            isDark 
              ? 'border-zinc-800 hover:bg-zinc-800 text-white' 
              : 'border-zinc-200 hover:bg-zinc-100 text-black'
          }`}
        >
          Cancel
        </button>
      </div>
    </div>
  )
}

// ============ POST CARD ============
function PostCard({ post, currentUserId, onLike, onComment, onSave, onUserClick, onDeleted }: { 
  post: Post
  currentUserId?: string
  onLike: () => void
  onComment: (text: string) => void
  onSave: () => void
  onUserClick: () => void
  onDeleted?: () => void
}) {
  const [showComments, setShowComments] = useState(false)
  const [comments, setComments] = useState(post.comments)
  const [currentImage, setCurrentImage] = useState(0)
  const [isLiked, setIsLiked] = useState(post.likes.some(l => l.userId === currentUserId))
  const [isSaved, setIsSaved] = useState(post.isSaved || false)
  const [showHeart, setShowHeart] = useState(false)
  const [showOptions, setShowOptions] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [showShareModal, setShowShareModal] = useState(false)
  const [caption, setCaption] = useState(post.caption || '')
  const [copyToast, setCopyToast] = useState(false)
  const [isFollowing, setIsFollowing] = useState(post.author.isFollowing || false)
  const [followLoading, setFollowLoading] = useState(false)
  const [swipeOffset, setSwipeOffset] = useState(0)
  const lastTapRef = useRef<number>(0)
  const touchStartX = useRef<number>(0)
  const touchStartY = useRef<number>(0)
  const isSwiping = useRef<boolean>(false)
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'
  
  const isOwnPost = post.author.id === currentUserId

  // Touch handlers for swipe
  const handleTouchStart = (e: React.TouchEvent) => {
    if (post.images.length <= 1) return
    touchStartX.current = e.touches[0].clientX
    touchStartY.current = e.touches[0].clientY
    isSwiping.current = true
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isSwiping.current || post.images.length <= 1) return
    
    const currentX = e.touches[0].clientX
    const currentY = e.touches[0].clientY
    const diffX = currentX - touchStartX.current
    const diffY = currentY - touchStartY.current
    
    // Only swipe if horizontal movement is greater than vertical
    if (Math.abs(diffX) > Math.abs(diffY)) {
      setSwipeOffset(diffX)
    }
  }

  const handleTouchEnd = () => {
    if (!isSwiping.current || post.images.length <= 1) return
    isSwiping.current = false
    
    const threshold = 50 // Minimum swipe distance
    
    if (swipeOffset < -threshold && currentImage < post.images.length - 1) {
      // Swipe left - next image
      setCurrentImage(prev => prev + 1)
    } else if (swipeOffset > threshold && currentImage > 0) {
      // Swipe right - previous image
      setCurrentImage(prev => prev - 1)
    }
    
    setSwipeOffset(0)
  }

  const handleFollow = async (e: React.MouseEvent) => {
    e.stopPropagation()
    if (followLoading || isOwnPost) return
    setFollowLoading(true)
    try {
      const res = await fetch(`/api/users/${post.author.id}/follow`, { method: 'POST' })
      const data = await res.json()
      setIsFollowing(data.isFollowing)
    } catch (error) {
      console.error('Follow error:', error)
    } finally {
      setFollowLoading(false)
    }
  }

  const handleDoubleTap = () => {
    const now = Date.now()
    const DOUBLE_TAP_DELAY = 300
    
    if (now - lastTapRef.current < DOUBLE_TAP_DELAY) {
      // Double tap detected - toggle like
      if (!isLiked) {
        // Like the post and show heart animation
        setIsLiked(true)
        onLike()
        setShowHeart(true)
        setTimeout(() => setShowHeart(false), 1000)
      } else {
        // Unlike the post
        setIsLiked(false)
        onLike()
      }
      lastTapRef.current = 0
    } else {
      lastTapRef.current = now
    }
  }

  const handleLikeClick = () => {
    setIsLiked(!isLiked)
    onLike()
  }

  const handleSave = async () => {
    try {
      const res = await fetch(`/api/posts/${post.id}/save`, { method: 'POST' })
      const data = await res.json()
      setIsSaved(data.isSaved)
      onSave()
    } catch (error) {
      console.error('Save error:', error)
    }
  }

  const handleDelete = async () => {
    try {
      const res = await fetch(`/api/posts/${post.id}`, { method: 'DELETE' })
      if (res.ok && onDeleted) {
        onDeleted()
      }
    } catch (error) {
      console.error('Delete error:', error)
    }
  }

  const handleCopyLink = async () => {
    const postUrl = `${window.location.origin}?post=${post.id}`
    await navigator.clipboard.writeText(postUrl)
    setCopyToast(true)
    setTimeout(() => setCopyToast(false), 2000)
  }

  const handleHideLikeCount = async () => {
    try {
      await fetch(`/api/posts/${post.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ hideLikeCount: true })
      })
    } catch (error) {
      console.error('Hide like count error:', error)
    }
  }

  const handleEditComplete = (newCaption: string) => {
    setCaption(newCaption)
  }

  return (
    <article className={`border-b ${isDark ? 'border-zinc-800 bg-black' : 'border-zinc-200 bg-white'}`}>
      {/* Header */}
      <div className="flex items-center justify-between p-3">
        <div className="flex items-center gap-3">
          <button onClick={onUserClick}>
            <Avatar src={post.author.avatar} name={post.author.fullName} username={post.author.username} size="sm" className="w-8 h-8 rounded-xl object-cover" />
          </button>
          <div className="text-left">
            <div className="flex items-center gap-1.5">
              <button onClick={onUserClick} className="font-semibold text-sm hover:underline">
                {post.author.fullName || post.author.username}
              </button>
              {post.author.isVerified && <Icons.Verified />}
              {/* Follow/Following button next to name */}
              {!isOwnPost && (
                <>
                  <span className="text-zinc-500">•</span>
                  <button 
                    onClick={handleFollow}
                    disabled={followLoading}
                    className={`text-sm font-semibold ${
                      isFollowing 
                        ? isDark ? 'text-zinc-400 hover:text-white' : 'text-zinc-500 hover:text-black'
                        : 'text-[#4CAF50]'
                    } ${followLoading ? 'opacity-50' : ''}`}
                  >
                    {followLoading ? '...' : isFollowing ? 'Following' : 'Follow'}
                  </button>
                </>
              )}
            </div>
            <div className="flex items-center gap-1 text-xs text-zinc-500">
              <span>@{post.author.username}</span>
              {post.location && <span>·</span>}
              {post.location && <span>{post.location}</span>}
              <span>·</span>
              <span>{timeAgo(new Date(post.createdAt))}</span>
            </div>
          </div>
        </div>
        <button onClick={() => setShowOptions(true)} className="p-2"><Icons.More /></button>
      </div>

      {/* Image */}
      <div 
        className={`relative aspect-square select-none overflow-hidden ${isDark ? 'bg-zinc-900' : 'bg-zinc-100'}`}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {post.images.length > 0 ? (
          <>
            {/* Images container with swipe */}
            <div 
              className="flex h-full transition-transform duration-200 ease-out"
              style={{ 
                transform: `translateX(${-currentImage * 100 + (swipeOffset / post.images.length) * 100}%)`,
                transitionDuration: swipeOffset === 0 ? '200ms' : '0ms'
              }}
            >
              {post.images.map((img, index) => (
                <div 
                  key={img.id || index}
                  className="flex-shrink-0 w-full h-full"
                  onClick={handleDoubleTap}
                >
                  <img 
                    src={img.url} 
                    alt={`Post image ${index + 1}`} 
                    className="w-full h-full object-cover"
                    draggable={false}
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.style.display = 'none';
                    }}
                  />
                </div>
              ))}
            </div>
            
            {/* Heart Animation Overlay */}
            {showHeart && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
                <svg 
                  className="w-24 h-24 text-white animate-ping"
                  viewBox="0 0 24 24" 
                  fill="currentColor"
                  style={{ animationDuration: '0.8s' }}
                >
                  <path fillRule="evenodd" clipRule="evenodd" d="M2 8.5C2 5.46243 4.46243 3 7.5 3C9.36017 3 11.0039 3.91085 12 5.31311C12.9961 3.91085 14.6398 3 16.5 3C19.5376 3 22 5.46243 22 8.5C22 9.81371 21.5478 11.0208 20.7924 11.9765L12 21L3.20759 11.9765C2.45218 11.0208 2 9.81371 2 8.5Z"/>
                </svg>
              </div>
            )}
            
            {/* Navigation arrows for desktop */}
            {post.images.length > 1 && (
              <>
                {currentImage > 0 && (
                  <button 
                    onClick={() => setCurrentImage(prev => prev - 1)}
                    className="hidden sm:flex absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/50 items-center justify-center text-white hover:bg-black/70 transition-colors z-10"
                  >
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                    </svg>
                  </button>
                )}
                {currentImage < post.images.length - 1 && (
                  <button 
                    onClick={() => setCurrentImage(prev => prev + 1)}
                    className="hidden sm:flex absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/50 items-center justify-center text-white hover:bg-black/70 transition-colors z-10"
                  >
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </button>
                )}
                {/* Dots indicator */}
                <div className="absolute bottom-2 left-0 right-0 flex justify-center gap-1 z-10">
                  {post.images.map((_, i) => (
                    <div 
                      key={i} 
                      className={`h-1.5 rounded-full transition-all duration-200 ${i === currentImage ? 'w-2 bg-white' : 'w-1.5 bg-white/50'}`} 
                    />
                  ))}
                </div>
              </>
            )}
          </>
        ) : (
          <div className={`absolute inset-0 flex items-center justify-center ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`}>
            <div className="text-center text-zinc-500">
              <Icons.Camera />
              <p className="text-sm mt-2">No image</p>
            </div>
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="p-3">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-4">
            <button onClick={handleLikeClick} className="transition-transform active:scale-125">
              <Icons.Heart filled={isLiked} className={isLiked ? 'text-[#4CAF50]' : ''} />
            </button>
            <button onClick={() => setShowComments(true)}>
              <Icons.Comment />
            </button>
            <button onClick={() => setShowShareModal(true)}>
              <Icons.Share />
            </button>
          </div>
          <button onClick={handleSave}>
            <Icons.Bookmark filled={isSaved} />
          </button>
        </div>

        <div className="font-semibold text-sm mb-1">{post.likes.length.toLocaleString()} likes</div>

        {/* Caption - Instagram style */}
        {caption && (
          <div className="mt-1">
            <p className={`text-sm ${isDark ? 'text-white' : 'text-black'}`}>
              <span className="font-semibold">{post.author.username}</span>{' '}
              <span className={caption.length > 80 ? '' : ''}>
                {caption.length > 80 ? (
                  <>
                    {renderCaptionWithHashtags(caption.slice(0, 80), isDark)}
                    <button 
                      onClick={() => setShowComments(true)}
                      className="text-zinc-500 ml-1"
                    >
                      more
                    </button>
                  </>
                ) : (
                  renderCaptionWithHashtags(caption, isDark)
                )}
              </span>
            </p>
          </div>
        )}

        {/* View comments */}
        {comments.length > 0 && (
          <button
            onClick={() => setShowComments(true)}
            className="text-zinc-500 text-sm mt-1 block"
          >
            View all {comments.length} comments
          </button>
        )}
      </div>

      {/* Comments Modal */}
      {showComments && (
        <CommentModal
          post={post}
          comments={comments}
          isDark={isDark}
          onClose={() => setShowComments(false)}
          onComment={(text, replyToId) => {
            fetch(`/api/posts/${post.id}/comments`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ content: text, replyToId })
            })
              .then(r => r.json())
              .then(data => {
                if (data.comment) {
                  setComments(prev => [...prev, data.comment])
                  onComment(text)
                }
              })
              .catch(console.error)
          }}
        />
      )}

      {/* Post Options Menu */}
      {showOptions && (
        <PostOptionsMenu
          post={post}
          isOwnPost={isOwnPost}
          isSaved={isSaved}
          onClose={() => setShowOptions(false)}
          onEdit={() => setShowEditModal(true)}
          onDelete={handleDelete}
          onSave={handleSave}
          onShare={() => setShowShareModal(true)}
          onCopyLink={handleCopyLink}
          onHide={handleHideLikeCount}
        />
      )}

      {/* Edit Post Modal */}
      {showEditModal && (
        <EditPostModal
          post={{ ...post, caption }}
          onClose={() => setShowEditModal(false)}
          onUpdated={handleEditComplete}
        />
      )}

      {/* Share Post Modal */}
      {showShareModal && (
        <SharePostModal
          post={{ ...post, caption }}
          onClose={() => setShowShareModal(false)}
        />
      )}

      {/* Copy Link Toast */}
      {copyToast && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 bg-zinc-800 text-white px-4 py-2 rounded-lg text-sm z-50">
          ✓ Link copied to clipboard
        </div>
      )}
    </article>
  )
}

// ============ TEXT POST CARD (Facebook-style) ============
function TextPostCard({ post, currentUserId, onLike, onComment, onUserClick, onDeleted }: { 
  post: Post
  currentUserId?: string
  onLike: () => void
  onComment: (text: string) => void
  onUserClick: () => void
  onDeleted?: () => void
}) {
  const [showComments, setShowComments] = useState(false)
  const [comments, setComments] = useState(post.comments)
  const [isLiked, setIsLiked] = useState(post.likes.some(l => l.userId === currentUserId))
  const [showOptions, setShowOptions] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [showShareModal, setShowShareModal] = useState(false)
  const [likeCount, setLikeCount] = useState(post.likes.length)
  const [showHeartAnimation, setShowHeartAnimation] = useState(false)
  const [isSaved, setIsSaved] = useState(post.isSaved || false)
  const { theme, currentUser } = useInstagramStore()
  const isDark = theme === 'dark'
  
  const isOwnPost = post.author.id === currentUserId

  const handleSave = async () => {
    try {
      const res = await fetch(`/api/posts/${post.id}/save`, { method: 'POST' })
      const data = await res.json()
      setIsSaved(data.isSaved)
    } catch (error) {
      console.error('Save error:', error)
    }
  }

  const handleLike = () => {
    if (isLiked) {
      setIsLiked(false)
      setLikeCount(prev => prev - 1)
    } else {
      setIsLiked(true)
      setLikeCount(prev => prev + 1)
      setShowHeartAnimation(true)
      setTimeout(() => setShowHeartAnimation(false), 600)
    }
    onLike()
  }

  const handleDelete = async () => {
    try {
      const res = await fetch(`/api/posts/${post.id}`, { method: 'DELETE' })
      if (res.ok && onDeleted) {
        onDeleted()
      }
    } catch (error) {
      console.error('Delete error:', error)
    }
  }

  const timeAgo = (date: Date) => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000)
    if (seconds < 60) return 'Just now'
    const minutes = Math.floor(seconds / 60)
    if (minutes < 60) return `${minutes}m`
    const hours = Math.floor(minutes / 60)
    if (hours < 24) return `${hours}h`
    const days = Math.floor(hours / 24)
    if (days < 7) return `${days}d`
    return date.toLocaleDateString()
  }

  return (
    <article className={`${isDark ? 'bg-black border-b border-zinc-800' : 'bg-white border-b border-zinc-200'}`}>
      {/* Header */}
      <div className="flex items-center justify-between p-3">
        <button onClick={onUserClick} className="flex items-center gap-3">
          <Avatar src={post.author.avatar} name={post.author.fullName} username={post.author.username} size="sm" />
          <div className="text-left">
            <div className="flex items-center gap-1">
              <span className="font-semibold text-sm">{post.author.fullName || post.author.username}</span>
              {post.author.isVerified && <Icons.Verified />}
            </div>
            <div className="flex items-center gap-1 text-xs text-zinc-500">
              <span>@{post.author.username}</span>
              <span>·</span>
              <span>{timeAgo(new Date(post.createdAt))}</span>
            </div>
          </div>
        </button>
        <button onClick={() => setShowOptions(true)} className={`p-2 rounded-full ${isDark ? 'hover:bg-zinc-800' : 'hover:bg-zinc-100'}`}>
          <Icons.More />
        </button>
      </div>

      {/* Text Content */}
      <div className="px-3 pb-3">
        <p className="text-sm whitespace-pre-wrap leading-relaxed">
          {renderCaptionWithHashtags(post.caption || '', isDark)}
        </p>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center justify-between px-3 py-2">
        <div className="flex items-center gap-4">
          <button 
            onClick={handleLike}
            className="transition-transform active:scale-125"
          >
            <Icons.Heart filled={isLiked} className={isLiked ? 'text-[#4CAF50]' : ''} />
          </button>
          <button onClick={() => setShowComments(true)}>
            <Icons.Comment />
          </button>
          <button onClick={() => setShowShareModal(true)}>
            <Icons.Share />
          </button>
        </div>
        <button onClick={handleSave}>
          <Icons.Bookmark filled={isSaved} />
        </button>
      </div>

      {/* Likes and Comments Count */}
      <div className="px-3 pb-2">
        {likeCount > 0 && (
          <p className="font-semibold text-sm mb-1">
            {likeCount.toLocaleString()} likes
          </p>
        )}
        {comments.length > 0 && (
          <button
            onClick={() => setShowComments(true)}
            className={`text-sm ${isDark ? 'text-zinc-500' : 'text-zinc-500'}`}
          >
            View all {comments.length} comments
          </button>
        )}
      </div>

      {/* Options Menu */}
      {showOptions && (
        <PostOptionsMenu
          post={post}
          isOwnPost={isOwnPost}
          isSaved={isSaved}
          onClose={() => setShowOptions(false)}
          onEdit={() => { setShowOptions(false); setShowEditModal(true) }}
          onDelete={handleDelete}
          onSave={handleSave}
          onShare={() => { setShowOptions(false); setShowShareModal(true) }}
          onCopyLink={() => navigator.clipboard.writeText(`${window.location.origin}?post=${post.id}`)}
          onHide={() => setShowOptions(false)}
        />
      )}

      {/* Edit Modal */}
      {showEditModal && (
        <EditPostModal
          post={post}
          onClose={() => setShowEditModal(false)}
          onUpdated={() => {
            setShowEditModal(false)
            if (onDeleted) onDeleted() // Refresh to show updated post
          }}
        />
      )}

      {/* Share Modal */}
      {showShareModal && (
        <SharePostModal post={post} onClose={() => setShowShareModal(false)} />
      )}

      {/* Comments Modal */}
      {showComments && (
        <CommentModal
          post={post}
          comments={comments}
          isDark={isDark}
          onClose={() => setShowComments(false)}
          onComment={(text) => {
            setComments(prev => [...prev, {
              id: Date.now().toString(),
              content: text,
              author: currentUser!,
              createdAt: new Date().toISOString()
            }])
            onComment(text)
          }}
        />
      )}
    </article>
  )
}

// ============ COMMENT MODAL (Popup with swipe to close) ============
function CommentModal({ 
  post, 
  comments, 
  isDark, 
  onClose, 
  onComment 
}: { 
  post: Post
  comments: any[]
  isDark: boolean
  onClose: () => void
  onComment: (text: string, replyToId?: string) => void
}) {
  const [commentText, setCommentText] = useState('')
  const [replyTo, setReplyTo] = useState<{ id: string; username: string } | null>(null)
  const [commentLikes, setCommentLikes] = useState<Record<string, boolean>>({})
  const [isAnimating, setIsAnimating] = useState(true)
  const [isClosing, setIsClosing] = useState(false)
  const [swipeY, setSwipeY] = useState(0)
  const [isDragging, setIsDragging] = useState(false)
  const [expandedReplies, setExpandedReplies] = useState<Set<string>>(new Set())
  const startYRef = useRef(0)
  const modalRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // Group comments into main comments and replies
  const { mainComments, repliesMap } = useMemo(() => {
    const mainComments: any[] = []
    const repliesMap: Record<string, any[]> = {}
    
    comments.forEach(comment => {
      if (comment.replyToId) {
        // This is a reply
        if (!repliesMap[comment.replyToId]) {
          repliesMap[comment.replyToId] = []
        }
        repliesMap[comment.replyToId].push(comment)
      } else {
        // This is a main comment
        mainComments.push(comment)
      }
    })
    
    return { mainComments, repliesMap }
  }, [comments])

  useEffect(() => {
    // Trigger open animation
    const timer = setTimeout(() => setIsAnimating(false), 10)
    return () => clearTimeout(timer)
  }, [])

  const handleClose = useCallback(() => {
    setIsClosing(true)
    setTimeout(onClose, 300)
  }, [onClose])

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    startYRef.current = e.touches[0].clientY
    setIsDragging(true)
  }, [])

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!isDragging) return
    const currentY = e.touches[0].clientY
    const diff = currentY - startYRef.current
    if (diff > 0) {
      setSwipeY(diff)
    }
  }, [isDragging])

  const handleTouchEnd = useCallback(() => {
    setIsDragging(false)
    if (swipeY > 150) {
      handleClose()
    } else {
      setSwipeY(0)
    }
  }, [swipeY, handleClose])

  const handleCommentLike = (commentId: string) => {
    setCommentLikes(prev => ({
      ...prev,
      [commentId]: !prev[commentId]
    }))
  }

  const handleReply = (commentId: string, username: string) => {
    setReplyTo({ id: commentId, username })
    setCommentText(`@${username} `)
    inputRef.current?.focus()
  }

  const toggleReplies = (commentId: string) => {
    setExpandedReplies(prev => {
      const next = new Set(prev)
      if (next.has(commentId)) {
        next.delete(commentId)
      } else {
        next.add(commentId)
      }
      return next
    })
  }

  const handleSubmit = () => {
    if (!commentText.trim()) return
    onComment(commentText, replyTo?.id)
    setCommentText('')
    setReplyTo(null)
  }

  const EMOJI_REACTIONS = ['❤️', '👏', '🔥', '😢', '😍', '😮', '😂', '🎉']

  const renderComment = (comment: any, isReply = false) => (
    <div key={comment.id} className={`${isReply ? 'ml-12 mt-3' : ''}`}>
      <div className="flex gap-3">
        {/* Avatar */}
        <Avatar 
          src={comment.author.avatar} 
          name={comment.author.fullName} 
          username={comment.author.username}
          size={isReply ? 'sm' : 'md'}
          className={`${isReply ? 'w-7 h-7' : 'w-9 h-9'} rounded-lg flex-shrink-0`}
        />
        
        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className={`font-semibold text-sm ${isDark ? 'text-white' : 'text-black'}`}>{comment.author.username}</span>
            <span className="text-zinc-500 text-xs">{timeAgo(new Date(comment.createdAt))}</span>
          </div>
          <p className={`text-sm mt-0.5 break-words ${isDark ? 'text-white' : 'text-black'}`}>
            {comment.replyToUsername && (
              <span className="text-[#4CAF50]">@{comment.replyToUsername} </span>
            )}
            {comment.content}
          </p>
          
          {/* Actions */}
          <div className="flex items-center gap-4 mt-2">
            {!isReply && (
              <button 
                onClick={() => handleReply(comment.id, comment.author.username)}
                className="text-zinc-500 text-xs font-medium"
              >
                Reply
              </button>
            )}
            <button 
              onClick={() => handleCommentLike(comment.id)}
              className="text-zinc-500 text-xs font-medium flex items-center gap-1"
            >
              {commentLikes[comment.id] ? '❤️' : '♡'} {commentLikes[comment.id] ? '1' : ''}
            </button>
          </div>
        </div>

        {/* Like button */}
        <button 
          onClick={() => handleCommentLike(comment.id)}
          className="flex-shrink-0"
        >
          <svg 
            viewBox="0 0 24 24" 
            fill={commentLikes[comment.id] ? 'currentColor' : 'none'} 
            stroke="currentColor"
            className={`${isReply ? 'w-4 h-4' : 'w-5 h-5'} ${commentLikes[comment.id] ? 'text-[#4CAF50]' : isDark ? 'text-white' : 'text-black'}`}
            strokeWidth={commentLikes[comment.id] ? 0 : 1.5}
          >
            <path fillRule="evenodd" clipRule="evenodd" d="M2 8.5C2 5.46243 4.46243 3 7.5 3C9.36017 3 11.0039 3.91085 12 5.31311C12.9961 3.91085 14.6398 3 16.5 3C19.5376 3 22 5.46243 22 8.5C22 9.81371 21.5478 11.0208 20.7924 11.9765L12 21L3.20759 11.9765C2.45218 11.0208 2 9.81371 2 8.5Z"/>
          </svg>
        </button>
      </div>
    </div>
  )

  return (
    <div 
      className={`fixed inset-0 z-50 transition-colors duration-300 ${isClosing ? 'bg-transparent' : 'bg-black/50'}`}
      onClick={handleClose}
    >
      <div 
        ref={modalRef}
        className={`absolute bottom-0 left-0 right-0 max-w-lg mx-auto rounded-t-3xl overflow-hidden transition-transform duration-300 ${isDark ? 'bg-black' : 'bg-white'} ${
          isAnimating || isClosing ? 'translate-y-full' : ''
        }`}
        style={{ 
          transform: swipeY > 0 ? `translateY(${swipeY}px)` : undefined,
          transition: isDragging ? 'none' : 'transform 0.3s ease-out'
        }}
        onClick={e => e.stopPropagation()}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* Drag Handle */}
        <div className="flex justify-center pt-3 pb-1 cursor-grab active:cursor-grabbing">
          <div className={`w-10 h-1 rounded-full ${isDark ? 'bg-zinc-700' : 'bg-zinc-300'}`} />
        </div>

        {/* Header */}
        <div className={`flex items-center justify-center p-4 border-b relative ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
          <button 
            onClick={handleClose}
            className="absolute left-4"
          >
            <Icons.Close />
          </button>
          <h2 className="font-semibold">Comments</h2>
        </div>

        {/* Comments List */}
        <div className="max-h-[60vh] overflow-y-auto">
          {comments.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-zinc-500">
              <Icons.Comment />
              <p className="mt-2">No comments yet</p>
              <p className="text-sm">Be the first to comment!</p>
            </div>
          ) : (
            <div className={`divide-y ${isDark ? 'divide-zinc-800' : 'divide-zinc-200'}`}>
              {mainComments.map((comment) => {
                const replies = repliesMap[comment.id] || []
                const hasReplies = replies.length > 0
                const showReplies = expandedReplies.has(comment.id)
                
                return (
                  <div key={comment.id} className="p-4">
                    {renderComment(comment)}
                    
                    {/* View Replies Button */}
                    {hasReplies && !showReplies && (
                      <button 
                        onClick={() => toggleReplies(comment.id)}
                        className="flex items-center gap-2 mt-3 ml-12 text-zinc-500 text-xs"
                      >
                        <div className="w-7 border-t border-zinc-600" />
                        View {replies.length} {replies.length === 1 ? 'reply' : 'replies'}
                      </button>
                    )}
                    
                    {/* Replies */}
                    {hasReplies && showReplies && (
                      <div className="mt-2">
                        {replies.map(reply => renderComment(reply, true))}
                        <button 
                          onClick={() => toggleReplies(comment.id)}
                          className="flex items-center gap-2 mt-2 ml-12 text-zinc-500 text-xs"
                        >
                          <div className="w-7 border-t border-zinc-600" />
                          Hide replies
                        </button>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          )}
        </div>

        {/* Bottom Section */}
        <div className={`border-t ${isDark ? 'border-zinc-800 bg-black' : 'border-zinc-200 bg-white'}`}>
          {/* Emoji Reactions Row */}
          <div className={`flex items-center justify-center gap-2 py-2 px-4 border-b ${isDark ? 'border-zinc-800/50' : 'border-zinc-200'}`}>
            {EMOJI_REACTIONS.map((emoji, i) => (
              <button 
                key={i}
                onClick={() => setCommentText(prev => prev + emoji)}
                className="text-xl hover:scale-125 transition-transform"
              >
                {emoji}
              </button>
            ))}
          </div>

          {/* Input Section */}
          <div className="flex items-center gap-3 p-3">
            <Avatar src={post.author.avatar} name={post.author.fullName} username={post.author.username} size="sm" className="w-8 h-8 rounded-xl flex-shrink-0" />
            <div className={`flex-1 flex items-center rounded-full px-4 py-2 ${isDark ? 'bg-zinc-800' : 'bg-zinc-100'}`}>
              {replyTo && (
                <span className="text-[#4CAF50] text-sm font-medium mr-1">
                  @{replyTo.username}
                  <button 
                    onClick={() => { setReplyTo(null); setCommentText(''); }}
                    className="ml-1 text-zinc-500"
                  >
                    ×
                  </button>
                </span>
              )}
              <input
                ref={inputRef}
                type="text"
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder={replyTo ? `Replying...` : "Join the conversation..."}
                className={`flex-1 bg-transparent text-sm outline-none ${isDark ? 'text-white placeholder-zinc-500' : 'text-black placeholder-zinc-400'}`}
                onKeyPress={(e) => e.key === 'Enter' && handleSubmit()}
              />
            </div>
            <button 
              onClick={handleSubmit}
              disabled={!commentText.trim()}
              className="flex-shrink-0"
            >
              <svg 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor"
                strokeWidth="2"
                className={`w-6 h-6 ${commentText.trim() ? 'text-[#4CAF50]' : isDark ? 'text-zinc-600' : 'text-zinc-300'}`}
              >
                <path d="M22 2L11 13M22 2L15 22L11 13M22 2L2 9L11 13" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

// ============ CREATE POST MODAL (Facebook Style - Full Screen) ============
function CreatePostModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [postType, setPostType] = useState<'text' | 'image'>('text')
  const [images, setImages] = useState<string[]>([])
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [caption, setCaption] = useState('')
  const [loading, setLoading] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [backgroundColor, setBackgroundColor] = useState<string>('')
  const fileInputRef = useRef<HTMLInputElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const { theme, currentUser } = useInstagramStore()
  const isDark = theme === 'dark'

  const backgroundColors = [
    '', // Default
    'bg-gradient-to-br from-[#ff6b6b] to-[#ee5a24]',
    'bg-gradient-to-br from-[#4ecdc4] to-[#44bd32]',
    'bg-gradient-to-br from-[#a55eea] to-[#8854d0]',
    'bg-gradient-to-br from-[#fd9644] to-[#fc5c65]',
    'bg-gradient-to-br from-[#26de81] to-[#20bf6b]',
    'bg-gradient-to-br from-[#45aaf2] to-[#2d98da]',
    'bg-gradient-to-br from-[#f7b731] to-[#fa8231]',
    'bg-gradient-to-br from-[#fd79a8] to-[#e84393]',
  ]

  const handleFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    setUploading(true)
    const uploadedUrls: string[] = []

    for (const file of Array.from(files)) {
      const formData = new FormData()
      formData.append('file', file)
      try {
        const res = await fetch('/api/upload/image', { method: 'POST', body: formData })
        const data = await res.json()
        if (data.url) uploadedUrls.push(data.url)
      } catch (error) {
        console.error('Upload error:', error)
      }
    }

    setImages(prev => [...prev, ...uploadedUrls])
    setUploading(false)
  }

  const handleRemoveImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index))
    if (currentImageIndex >= images.length - 1) {
      setCurrentImageIndex(Math.max(0, images.length - 2))
    }
  }

  const handleSubmit = async () => {
    if (postType === 'text' && !caption.trim()) return
    if (postType === 'image' && images.length === 0) return

    setLoading(true)
    try {
      const formData = new FormData()
      formData.append('caption', caption)
      formData.append('postType', postType)
      if (backgroundColor) formData.append('backgroundColor', backgroundColor)
      images.forEach(url => formData.append('images', url))

      const res = await fetch('/api/posts', { method: 'POST', body: formData })
      if (res.ok) {
        onCreated()
        onClose()
      }
    } catch (error) {
      console.error('Create post error:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black">
      {/* Header */}
      <div className={`flex items-center justify-between px-4 py-3 border-b ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200'}`}>
        <div className="flex items-center gap-3">
          <button onClick={onClose} className={`p-2 rounded-full ${isDark ? 'hover:bg-zinc-800' : 'hover:bg-zinc-100'}`}>
            <Icons.Close />
          </button>
          <span className="font-bold text-xl">Create post</span>
        </div>
        <button 
          onClick={handleSubmit}
          disabled={loading || (postType === 'text' ? !caption.trim() : images.length === 0)}
          className={`px-4 py-1.5 rounded-lg font-semibold text-sm transition-colors ${
            (postType === 'text' ? caption.trim() : images.length > 0)
              ? 'bg-[#4CAF50] text-white hover:bg-[#43A047]'
              : isDark ? 'bg-zinc-700 text-zinc-500' : 'bg-zinc-200 text-zinc-400'
          } disabled:opacity-50`}
        >
          {loading ? 'Posting...' : 'Post'}
        </button>
      </div>

      {/* User Info */}
      <div className={`flex items-center gap-3 px-4 py-3 ${isDark ? 'bg-zinc-900' : 'bg-white'}`}>
        <Avatar src={currentUser?.avatar} name={currentUser?.fullName} username={currentUser?.username} size="md" className="w-12 h-12 rounded-xl" />
        <div>
          <div className="flex items-center gap-1.5">
            <span className="font-semibold">{currentUser?.fullName || currentUser?.username}</span>
            {currentUser?.isVerified && <Icons.Verified />}
          </div>
        </div>
      </div>

      {/* Post Type Tabs */}
      <div className={`flex border-b ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200'}`}>
        <button
          onClick={() => setPostType('text')}
          className={`flex-1 py-3 text-sm font-medium transition-colors relative ${
            postType === 'text' 
              ? 'text-[#4CAF50]' 
              : isDark ? 'text-zinc-400' : 'text-zinc-600'
          }`}
        >
          Text Post
          {postType === 'text' && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#4CAF50]" />
          )}
        </button>
        <button
          onClick={() => setPostType('image')}
          className={`flex-1 py-3 text-sm font-medium transition-colors relative ${
            postType === 'image' 
              ? 'text-[#4CAF50]' 
              : isDark ? 'text-zinc-400' : 'text-zinc-600'
          }`}
        >
          Photo/Video
          {postType === 'image' && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#4CAF50]" />
          )}
        </button>
      </div>

      {/* Content Area */}
      <div className={`flex-1 overflow-y-auto ${isDark ? 'bg-zinc-900' : 'bg-white'}`}>
        {postType === 'text' ? (
          <div className="flex flex-col h-full">
            {/* Text Input */}
            <div className={`flex-1 p-4 ${backgroundColor || ''}`}>
              <textarea
                ref={textareaRef}
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                placeholder="What's on your mind?"
                className={`w-full h-full min-h-[200px] resize-none outline-none text-2xl font-medium bg-transparent ${
                  backgroundColor 
                    ? 'text-white placeholder-white/60 text-center' 
                    : isDark 
                      ? 'text-white placeholder-zinc-500' 
                      : 'text-black placeholder-zinc-400'
                }`}
                style={{ minHeight: '300px' }}
              />
            </div>

            {/* Background Color Selector */}
            <div className={`p-4 border-t ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
              <p className={`text-sm font-medium mb-2 ${isDark ? 'text-zinc-400' : 'text-zinc-600'}`}>
                Background Color
              </p>
              <div className="flex gap-2 overflow-x-auto pb-2">
                {backgroundColors.map((color, i) => (
                  <button
                    key={i}
                    onClick={() => setBackgroundColor(color)}
                    className={`w-10 h-10 rounded-full flex-shrink-0 transition-all ${
                      color || (isDark ? 'bg-zinc-700' : 'bg-zinc-200')
                    } ${backgroundColor === color ? 'ring-2 ring-[#4CAF50] ring-offset-2' : ''}`}
                  >
                    {i === 0 && (
                      <span className={`text-xs ${isDark ? 'text-zinc-400' : 'text-zinc-600'}`}>Aa</span>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="flex flex-col h-full">
            {/* Images Preview */}
            {images.length > 0 ? (
              <div className="relative flex-1 flex items-center justify-center bg-black min-h-[300px]">
                <img 
                  src={images[currentImageIndex]} 
                  alt={`Preview ${currentImageIndex + 1}`} 
                  className="max-w-full max-h-[50vh] object-contain"
                />
                
                {/* Multiple Images Navigation */}
                {images.length > 1 && (
                  <>
                    {currentImageIndex > 0 && (
                      <button 
                        onClick={() => setCurrentImageIndex(i => i - 1)}
                        className="absolute left-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/60 flex items-center justify-center"
                      >
                        <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                        </svg>
                      </button>
                    )}
                    {currentImageIndex < images.length - 1 && (
                      <button 
                        onClick={() => setCurrentImageIndex(i => i + 1)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/60 flex items-center justify-center"
                      >
                        <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                      </button>
                    )}
                    {/* Dots */}
                    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-1.5">
                      {images.map((_, i) => (
                        <div 
                          key={i} 
                          className={`w-2 h-2 rounded-full transition-all ${i === currentImageIndex ? 'bg-white w-4' : 'bg-white/50'}`}
                        />
                      ))}
                    </div>
                  </>
                )}
              </div>
            ) : (
              <div className={`flex-1 flex flex-col items-center justify-center p-8 ${isDark ? 'bg-zinc-800' : 'bg-zinc-100'}`}>
                <div className={`w-20 h-20 rounded-full flex items-center justify-center mb-4 ${isDark ? 'bg-zinc-700' : 'bg-zinc-200'}`}>
                  <svg viewBox="0 0 24 24" fill="none" className="w-10 h-10">
                    <rect x="3" y="3" width="18" height="18" rx="2" stroke="currentColor" strokeWidth="1.5"/>
                    <circle cx="8.5" cy="8.5" r="1.5" fill="currentColor"/>
                    <path d="M21 15L16 10L5 21" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <p className={`text-lg font-medium mb-1 ${isDark ? 'text-white' : 'text-black'}`}>
                  Add photos to your post
                </p>
                <p className={`text-sm mb-4 ${isDark ? 'text-zinc-400' : 'text-zinc-600'}`}>
                  Drag or select up to 10 photos
                </p>
              </div>
            )}

            {/* Caption for image post */}
            <div className={`p-4 border-t ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
              <textarea
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                placeholder="Write a caption..."
                className={`w-full h-20 resize-none outline-none text-sm bg-transparent ${isDark ? 'text-white placeholder-zinc-500' : 'text-black placeholder-zinc-400'}`}
              />
            </div>

            {/* Thumbnails Strip */}
            {images.length > 0 && (
              <div className={`flex gap-2 p-3 border-t overflow-x-auto ${isDark ? 'border-zinc-800 bg-zinc-900' : 'border-zinc-200 bg-white'}`}>
                {images.map((url, i) => (
                  <div key={i} className="relative flex-shrink-0">
                    <img 
                      src={url} 
                      alt={`Thumb ${i + 1}`}
                      className={`w-16 h-16 object-cover rounded-lg cursor-pointer transition-all ${
                        i === currentImageIndex ? 'ring-2 ring-[#4CAF50]' : 'opacity-70'
                      }`}
                      onClick={() => setCurrentImageIndex(i)}
                    />
                    <button
                      onClick={() => handleRemoveImage(i)}
                      className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-red-500 flex items-center justify-center"
                    >
                      <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>
                ))}
                {images.length < 10 && (
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className={`w-16 h-16 rounded-lg flex items-center justify-center flex-shrink-0 border-2 border-dashed ${isDark ? 'border-zinc-700' : 'border-zinc-300'}`}
                  >
                    <Icons.Plus />
                  </button>
                )}
              </div>
            )}

            {/* Add Photo Button */}
            <div className={`p-4 border-t ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
              <button 
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className={`w-full py-3 rounded-lg font-semibold text-sm flex items-center justify-center gap-2 ${
                  isDark ? 'bg-zinc-800 hover:bg-zinc-700 text-white' : 'bg-zinc-100 hover:bg-zinc-200 text-black'
                }`}
              >
                <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5">
                  <rect x="3" y="3" width="18" height="18" rx="2" stroke="currentColor" strokeWidth="1.5"/>
                  <circle cx="8.5" cy="8.5" r="1.5" fill="currentColor"/>
                  <path d="M21 15L16 10L5 21" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                {uploading ? 'Uploading...' : 'Add Photos'}
              </button>
            </div>

            <input 
              ref={fileInputRef} 
              type="file" 
              accept="image/*" 
              multiple 
              onChange={handleFiles} 
              className="hidden" 
            />
          </div>
        )}
      </div>
    </div>
  )
}

// ============ EDIT PROFILE MODAL ============
function EditProfileModal({ user, onClose, onUpdated }: { 
  user: User
  onClose: () => void
  onUpdated: (user: User) => void
}) {
  const [fullName, setFullName] = useState(user.fullName || '')
  const [bio, setBio] = useState(user.bio || '')
  const [website, setWebsite] = useState(user.website || '')
  const [avatar, setAvatar] = useState(user.avatar || '')
  const [loading, setLoading] = useState(false)
  const [uploading, setUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setUploading(true)
    const formData = new FormData()
    formData.append('file', file)

    try {
      const res = await fetch('/api/upload/image', { method: 'POST', body: formData })
      const data = await res.json()
      if (data.url) {
        setAvatar(data.url)
      }
    } catch (error) {
      console.error('Avatar upload error:', error)
    } finally {
      setUploading(false)
    }
  }

  const handleSave = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/users/me', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fullName, bio, website, avatar })
      })
      const data = await res.json()
      if (data.user) {
        onUpdated(data.user)
        onClose()
      }
    } catch (error) {
      console.error('Save error:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
      <div className={`w-full max-w-md rounded-xl ${isDark ? 'bg-zinc-900' : 'bg-white'}`}>
        <div className={`flex items-center justify-between p-4 border-b ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
          <button onClick={onClose} className={isDark ? 'text-white' : 'text-black'}><Icons.Close /></button>
          <span className="font-semibold">Edit profile</span>
          <button 
            onClick={handleSave} 
            disabled={loading}
            className="text-[#4CAF50] font-semibold disabled:opacity-50"
          >
            {loading ? 'Saving...' : 'Done'}
          </button>
        </div>

        <div className="p-6">
          {/* Avatar Section */}
          <div className="flex flex-col items-center mb-6">
            <div className="relative">
              <Avatar src={avatar} name={user.fullName} username={user.username} size="xl" className="w-20 h-20 rounded-xl object-cover" />
              {uploading && (
                <div className="absolute inset-0 rounded-lg bg-black/50 flex items-center justify-center">
                  <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
                </div>
              )}
            </div>
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="mt-2 text-[#4CAF50] text-sm font-semibold"
            >
              Change profile photo
            </button>
            <input 
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleAvatarChange}
              className="hidden"
            />
          </div>

          {/* Form Fields */}
          <div className="space-y-4">
            <div>
              <label className={`text-xs ${isDark ? 'text-zinc-500' : 'text-zinc-600'}`}>Name</label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className={`w-full border rounded-lg px-3 py-2 mt-1 text-sm ${isDark ? 'bg-zinc-800 border-zinc-700 text-white' : 'bg-zinc-100 border-zinc-300 text-black'}`}
                placeholder="Name"
              />
            </div>

            <div>
              <label className={`text-xs ${isDark ? 'text-zinc-500' : 'text-zinc-600'}`}>Bio</label>
              <textarea
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className={`w-full border rounded-lg px-3 py-2 mt-1 h-24 resize-none text-sm ${isDark ? 'bg-zinc-800 border-zinc-700 text-white' : 'bg-zinc-100 border-zinc-300 text-black'}`}
                placeholder="Write a bio..."
              />
            </div>

            <div>
              <label className={`text-xs ${isDark ? 'text-zinc-500' : 'text-zinc-600'}`}>Website</label>
              <input
                type="text"
                value={website}
                onChange={(e) => setWebsite(e.target.value)}
                className={`w-full border rounded-lg px-3 py-2 mt-1 text-sm ${isDark ? 'bg-zinc-800 border-zinc-700 text-white' : 'bg-zinc-100 border-zinc-300 text-black'}`}
                placeholder="Website"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// ============ HIGHLIGHT MODAL ============
function HighlightViewerModal({ highlight, onClose }: { 
  highlight: { id: string; title: string; coverImage?: string; stories: any[] }
  onClose: () => void
}) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [progress, setProgress] = useState(0)
  const timerRef = useRef<NodeJS.Timeout | null>(null)
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'

  const stories = highlight.stories || []

  useEffect(() => {
    if (stories.length === 0) return

    timerRef.current = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          if (currentIndex < stories.length - 1) {
            setCurrentIndex(i => i + 1)
            return 0
          } else {
            onClose()
            return 100
          }
        }
        return prev + 2
      })
    }, 100)

    return () => {
      if (timerRef.current) clearInterval(timerRef.current)
    }
  }, [currentIndex, stories.length, onClose])

  if (stories.length === 0) {
    return (
      <div className="fixed inset-0 bg-black z-50 flex items-center justify-center">
        <div className="text-white">No stories in this highlight</div>
        <button onClick={onClose} className="absolute top-4 right-4 text-white"><Icons.Close /></button>
      </div>
    )
  }

  const currentStory = stories[currentIndex]

  return (
    <div className="fixed inset-0 bg-black z-50 flex items-center justify-center">
      <div className="relative w-full max-w-md h-full">
        {/* Progress bars */}
        <div className="absolute top-2 left-2 right-2 flex gap-1 z-20">
          {stories.map((_, i) => (
            <div key={i} className="flex-1 h-1 bg-zinc-600 rounded-full overflow-hidden">
              <div 
                className="h-full bg-white transition-all duration-100"
                style={{ width: i < currentIndex ? '100%' : i === currentIndex ? `${progress}%` : '0%' }}
              />
            </div>
          ))}
        </div>

        {/* Header */}
        <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-20">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl border-2 border-zinc-600 overflow-hidden">
              <Avatar src={highlight.coverImage} name={null} username={highlight.title} size="md" className="w-full h-full object-cover" />
            </div>
            <span className="text-white font-semibold text-sm">{highlight.title}</span>
          </div>
          <button onClick={onClose} className="text-white"><Icons.Close /></button>
        </div>

        {/* Navigation */}
        <button 
          onClick={() => currentIndex > 0 && setCurrentIndex(i => i - 1)}
          className="absolute left-0 top-0 bottom-0 w-1/4 z-10"
        />
        <button 
          onClick={() => currentIndex < stories.length - 1 && setCurrentIndex(i => i + 1)}
          className="absolute right-0 top-0 bottom-0 w-1/4 z-10"
        />

        {/* Content */}
        <div className="absolute inset-0 flex items-center justify-center bg-black">
          {currentStory?.type === 'image' ? (
            <img src={currentStory.content} alt="Story" className="max-w-full max-h-full object-contain" />
          ) : currentStory?.type === 'text' ? (
            <p className="text-2xl font-bold text-center px-8" style={{ color: currentStory.textColor || '#fff' }}>
              {currentStory.content}
            </p>
          ) : (
            <img src={currentStory?.content || currentStory?.url} alt="Story" className="max-w-full max-h-full object-contain" />
          )}
        </div>
      </div>
    </div>
  )
}

// ============ CREATE HIGHLIGHT MODAL ============
function CreateHighlightModal({ onClose, onCreated }: { 
  onClose: () => void
  onCreated: () => void
}) {
  const [title, setTitle] = useState('')
  const [coverImage, setCoverImage] = useState('')
  const [loading, setLoading] = useState(false)
  const [stories, setStories] = useState<any[]>([])
  const [selectedStories, setSelectedStories] = useState<string[]>([])
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'

  useEffect(() => {
    // Fetch user's stories that can be added to highlights
    fetch('/api/stories')
      .then(r => r.json())
      .then(data => setStories(data.stories || []))
      .catch(console.error)
  }, [])

  const handleCoverUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setLoading(true)
    const formData = new FormData()
    formData.append('file', file)

    try {
      const res = await fetch('/api/upload/image', { method: 'POST', body: formData })
      const data = await res.json()
      if (data.url) {
        setCoverImage(data.url)
      }
    } catch (error) {
      console.error('Upload error:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleCreate = async () => {
    if (!title.trim()) return

    setLoading(true)
    try {
      const res = await fetch('/api/highlights', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, coverImage, storyIds: selectedStories })
      })
      if (res.ok) {
        onCreated()
        onClose()
      }
    } catch (error) {
      console.error('Create highlight error:', error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
      <div className={`w-full max-w-md rounded-xl ${isDark ? 'bg-zinc-900' : 'bg-white'}`}>
        <div className={`flex items-center justify-between p-4 border-b ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
          <button onClick={onClose} className={isDark ? 'text-white' : 'text-black'}><Icons.Close /></button>
          <span className="font-semibold">New highlight</span>
          <button 
            onClick={handleCreate}
            disabled={loading || !title.trim()}
            className="text-[#4CAF50] font-semibold disabled:opacity-50"
          >
            {loading ? 'Creating...' : 'Create'}
          </button>
        </div>

        <div className="p-4">
          {/* Cover Image */}
          <div className="flex items-center gap-4 mb-4">
            <button 
              onClick={() => fileInputRef.current?.click()}
              className={`w-16 h-16 rounded-lg overflow-hidden border-2 ${isDark ? 'border-zinc-700' : 'border-zinc-300'} flex items-center justify-center`}
            >
              {coverImage ? (
                <img src={coverImage} alt="Cover" className="w-full h-full object-cover" />
              ) : (
                <Icons.Plus />
              )}
            </button>
            <input 
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleCoverUpload}
              className="hidden"
            />
            <div className="flex-1">
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Highlight name"
                className={`w-full border-b py-2 text-sm ${isDark ? 'bg-transparent border-zinc-700 text-white' : 'bg-transparent border-zinc-300 text-black'}`}
              />
            </div>
          </div>

          {/* Stories Selection */}
          <div className="mt-4">
            <p className={`text-sm font-semibold mb-2 ${isDark ? 'text-zinc-400' : 'text-zinc-600'}`}>Select stories</p>
            <div className="grid grid-cols-3 gap-1 max-h-64 overflow-y-auto">
              {stories.map((story) => (
                <button
                  key={story.id}
                  onClick={() => {
                    setSelectedStories(prev => 
                      prev.includes(story.id) 
                        ? prev.filter(id => id !== story.id)
                        : [...prev, story.id]
                    )
                  }}
                  className={`aspect-[9/16] rounded overflow-hidden relative ${selectedStories.includes(story.id) ? 'ring-2 ring-[#4CAF50]' : ''}`}
                >
                  <img 
                    src={story.content} 
                    alt="" 
                    className="w-full h-full object-cover"
                  />
                  {selectedStories.includes(story.id) && (
                    <div className="absolute top-1 right-1 w-5 h-5 rounded-full bg-[#4CAF50] flex items-center justify-center">
                      <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// ============ SHARE PROFILE MODAL (QR CODE) ============
function ShareProfileModal({ user, onClose }: { 
  user: User
  onClose: () => void 
}) {
  const [copied, setCopied] = useState(false)
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'
  
  const profileUrl = typeof window !== 'undefined' 
    ? `${window.location.origin}?profile=${user.username}`
    : ''

  const handleCopyLink = async () => {
    await navigator.clipboard.writeText(profileUrl)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleShareProfile = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${user.username} on hey`,
          text: `Check out ${user.fullName || user.username}'s profile on hey`,
          url: profileUrl
        })
      } catch {
        // User cancelled share
      }
    } else {
      handleCopyLink()
    }
  }

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center p-4 ${isDark ? 'bg-black/80' : 'bg-black/50'}`}>
      <div className={`rounded-xl w-full max-w-sm overflow-hidden ${isDark ? 'bg-zinc-900' : 'bg-white'}`}>
        {/* Header */}
        <div className={`flex items-center justify-between p-4 border-b ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
          <button onClick={onClose} className={isDark ? 'text-white' : 'text-black'}>
            <Icons.Close />
          </button>
          <span className="font-semibold">Share profile</span>
          <div className="w-6" />
        </div>

        {/* QR Code Section */}
        <div className="flex flex-col items-center p-8">
          {/* QR Code with border */}
          <div className={`p-4 rounded-2xl ${isDark ? 'bg-white' : 'bg-white'}`}>
            <QRCodeSVG 
              value={profileUrl}
              size={200}
              level="H"
              includeMargin={false}
              bgColor="#ffffff"
              fgColor="#000000"
            />
          </div>
          
          {/* Username */}
          <div className="mt-4 text-center">
            <div className="flex items-center justify-center gap-1">
              <span className={`font-semibold ${isDark ? 'text-white' : 'text-black'}`}>
                {user.username}
              </span>
              {user.isVerified && <Icons.Verified />}
            </div>
            <p className={`text-sm ${isDark ? 'text-zinc-400' : 'text-zinc-600'}`}>
              Scan to view profile
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className={`p-4 border-t space-y-3 ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
          <button 
            onClick={handleShareProfile}
            className="w-full bg-[#4CAF50] text-white py-3 rounded-lg font-semibold text-sm hover:bg-[#4CAF50] transition-colors"
          >
            Share profile
          </button>
          <button 
            onClick={handleCopyLink}
            className={`w-full py-3 rounded-lg font-semibold text-sm transition-colors ${
              copied 
                ? 'bg-green-500/20 text-green-500' 
                : isDark 
                  ? 'bg-zinc-800 text-white hover:bg-zinc-700' 
                  : 'bg-zinc-200 text-black hover:bg-zinc-300'
            }`}
          >
            {copied ? '✓ Link copied' : 'Copy link'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ============ SAVED POSTS TAB ============
function SavedPostsTab({ currentUserId, onUserClick }: { 
  currentUserId?: string
  onUserClick: (user: User) => void 
}) {
  const [savedPosts, setSavedPosts] = useState<Post[]>([])
  const [loading, setLoading] = useState(true)
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'

  useEffect(() => {
    if (!currentUserId) return
    
    fetch(`/api/posts/saved?userId=${currentUserId}`)
      .then(r => r.json())
      .then(data => {
        setSavedPosts(data.posts || [])
        setLoading(false)
      })
      .catch(err => {
        console.error('Error fetching saved posts:', err)
        setLoading(false)
      })
  }, [currentUserId])

  if (loading) {
    return (
      <div className="py-16 text-center">
        <div className="w-8 h-8 border-2 border-t-transparent border-[#4CAF50] rounded-full animate-spin mx-auto" />
      </div>
    )
  }

  if (savedPosts.length === 0) {
    return (
      <div className="py-16 text-center">
        <div className={`w-16 h-16 rounded-full mx-auto flex items-center justify-center ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`}>
          <Icons.Bookmark />
        </div>
        <h3 className="mt-4 font-semibold">Save posts</h3>
        <p className="text-zinc-500 text-sm mt-1">Save posts to see them here.</p>
      </div>
    )
  }

  return (
    <div className="divide-y">
      {savedPosts.map((post) => (
        <PostCard
          key={post.id}
          post={post}
          currentUserId={currentUserId}
          onLike={async () => {
            try {
              await fetch(`/api/posts/${post.id}/like`, { method: 'POST' })
            } catch (error) {
              console.error('Like error:', error)
            }
          }}
          onComment={() => {}}
          onSave={async () => {
            try {
              const res = await fetch(`/api/posts/${post.id}/save`, { method: 'POST' })
              const data = await res.json()
              if (!data.isSaved) {
                // Remove from saved list if unsaved
                setSavedPosts(prev => prev.filter(p => p.id !== post.id))
              }
            } catch (error) {
              console.error('Save error:', error)
            }
          }}
          onUserClick={() => onUserClick(post.author)}
        />
      ))}
    </div>
  )
}

function ProfilePage({ user, isOwnProfile, currentUserId, onBack, onSettings, onUserClick, onMessage }: { 
  user: User
  isOwnProfile: boolean
  currentUserId?: string
  onBack: () => void
  onSettings: () => void
  onUserClick: (user: User) => void
  onMessage: (user: User) => void
}) {
  const [posts, setPosts] = useState<Post[]>([])
  const [followers, setFollowers] = useState<User[]>([])
  const [following, setFollowing] = useState<User[]>([])
  const [showFollowers, setShowFollowers] = useState(false)
  const [showFollowing, setShowFollowing] = useState(false)
  const [showEditProfile, setShowEditProfile] = useState(false)
  const [showShareModal, setShowShareModal] = useState(false)
  const [showProfileOptions, setShowProfileOptions] = useState(false)
  const [showReportModal, setShowReportModal] = useState(false)
  const [reportReason, setReportReason] = useState('')
  const [reportSubmitted, setReportSubmitted] = useState(false)
  const [activeTab, setActiveTab] = useState<'posts' | 'reels' | 'saved'>('posts')
  const [isFollowing, setIsFollowing] = useState(user.isFollowing || false)
  const [isRequested, setIsRequested] = useState(user.isRequested || false)
  const [isFollowedBy, setIsFollowedBy] = useState(user.isFollowedBy || false)
  const [isProfilePrivate, setIsProfilePrivate] = useState(false)
  const [followLoading, setFollowLoading] = useState(false)
  const [stats, setStats] = useState({ postsCount: user.postsCount || 0, followersCount: user.followersCount || 0, followingCount: user.followingCount || 0 })
  const [profileUser, setProfileUser] = useState(user)
  const [coverUploading, setCoverUploading] = useState(false)
  const [copiedLink, setCopiedLink] = useState(false)
  const [userFollowStates, setUserFollowStates] = useState<Record<string, boolean>>({})
  const [userFollowLoading, setUserFollowLoading] = useState<string | null>(null)
  const coverInputRef = useRef<HTMLInputElement>(null)
  const { theme, currentUser } = useInstagramStore()
  const isDark = theme === 'dark'

  // Copy profile link
  const handleCopyProfileLink = async () => {
    const profileUrl = `${window.location.origin}?profile=${profileUser.username}`
    await navigator.clipboard.writeText(profileUrl)
    setCopiedLink(true)
    setTimeout(() => setCopiedLink(false), 2000)
  }

  // Handle report submission
  const handleReportSubmit = async () => {
    if (!reportReason.trim()) return
    try {
      // In a real app, this would send to a reports API
      setReportSubmitted(true)
      setTimeout(() => {
        setShowReportModal(false)
        setReportSubmitted(false)
        setReportReason('')
      }, 2000)
    } catch (error) {
      console.error('Report error:', error)
    }
  }

  // Handle follow/unfollow for list items
  const handleUserFollow = async (userId: string) => {
    if (userFollowLoading === userId || userId === currentUser?.id) return
    setUserFollowLoading(userId)
    try {
      const res = await fetch(`/api/users/${userId}/follow`, { method: 'POST' })
      const data = await res.json()
      setUserFollowStates(prev => ({ ...prev, [userId]: data.isFollowing }))
      
      // Update the followers/following lists if needed
      if (data.isFollowing) {
        // If we just followed someone, they might appear in our following list
        setFollowing(prev => prev.some(u => u.id === userId) ? prev : [...prev, followers.find(f => f.id === userId) || following.find(f => f.id === userId)!].filter(Boolean))
      } else {
        // If we unfollowed, update the following count
        setStats(prev => ({ ...prev, followingCount: Math.max(0, prev.followingCount - 1) }))
      }
    } catch (error) {
      console.error('Follow error:', error)
    } finally {
      setUserFollowLoading(null)
    }
  }

  // Initialize follow states for followers/following lists
  useEffect(() => {
    const allUsers = [...followers, ...following]
    const states: Record<string, boolean> = {}
    allUsers.forEach(u => {
      states[u.id] = u.isFollowing || false
    })
    setUserFollowStates(states)
  }, [followers, following])

  // Handle cover image upload
  const handleCoverUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setCoverUploading(true)
    try {
      const formData = new FormData()
      formData.append('file', file)

      const res = await fetch('/api/users/cover-image', {
        method: 'POST',
        body: formData
      })
      const data = await res.json()
      
      if (data.coverImage) {
        setProfileUser(prev => ({ ...prev, coverImage: data.coverImage }))
      }
    } catch (error) {
      console.error('Cover upload error:', error)
    } finally {
      setCoverUploading(false)
    }
  }

  useEffect(() => {
    const fetchData = async () => {
      const [postsRes, followersRes, followingRes] = await Promise.all([
        fetch(`/api/posts?profileUserId=${profileUser.id}&userId=${currentUserId}`).then(r => r.json()),
        fetch(`/api/follow/followers/${profileUser.id}`).then(r => r.json()),
        fetch(`/api/follow/following/${profileUser.id}`).then(r => r.json()),
      ])
      setPosts(postsRes.posts || [])
      setFollowers(followersRes.followers || [])
      setFollowing(followingRes.following || [])
      
      // Handle private profile
      if (postsRes.isPrivate) {
        setIsProfilePrivate(true)
        setIsFollowing(postsRes.isFollowing || false)
        setIsRequested(postsRes.isRequested || false)
      }
    }
    fetchData()
  }, [profileUser.id, currentUserId])

  const handleFollow = async () => {
    if (followLoading) return
    setFollowLoading(true)
    try {
      const res = await fetch(`/api/users/${profileUser.id}/follow`, { method: 'POST' })
      const data = await res.json()
      setIsFollowing(data.isFollowing)
      setIsRequested(data.isRequested || false)
      setStats(prev => ({
        ...prev,
        followersCount: data.isFollowing ? prev.followersCount + 1 : data.isRequested ? prev.followersCount : prev.followersCount - 1
      }))
    } catch (error) {
      console.error('Follow error:', error)
    } finally {
      setFollowLoading(false)
    }
  }

  const handleShareProfile = () => {
    setShowShareModal(true)
  }

  const handleProfileUpdate = (updatedUser: User) => {
    setProfileUser(updatedUser)
  }

  return (
    <div className={`pb-16 min-h-screen ${isDark ? 'bg-black text-white' : 'bg-white text-black'}`}>
      {/* Header */}
      <div className={`flex items-center justify-between p-4 border-b ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
        <button onClick={onBack}><Icons.Back /></button>
        <div className="flex items-center gap-1">
          <span className="font-semibold">{profileUser.username}</span>
          {profileUser.isVerified && <Icons.Verified />}
        </div>
        <button onClick={() => isOwnProfile ? onSettings() : setShowProfileOptions(true)}><Icons.Options /></button>
      </div>

      {/* Cover Image - X/Twitter style */}
      <div className="relative h-36 sm:h-48 bg-zinc-800">
        {profileUser.coverImage ? (
          <img 
            src={profileUser.coverImage} 
            alt="Cover" 
            className="w-full h-full object-cover"
          />
        ) : (
          <div className={`w-full h-full ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`} />
        )}
        
        {/* Cover upload button for own profile */}
        {isOwnProfile && (
          <button 
            onClick={() => coverInputRef.current?.click()}
            className="absolute bottom-3 right-3 px-3 py-1.5 rounded-full bg-black/60 text-white text-sm font-medium flex items-center gap-1.5 hover:bg-black/70 transition-colors"
          >
            {coverUploading ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <svg viewBox="0 0 24 24" fill="none" className="w-4 h-4">
                <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                <circle cx="12" cy="13" r="4" stroke="currentColor" strokeWidth="1.5"/>
              </svg>
            )}
            <span>{profileUser.coverImage ? 'Change' : 'Add cover'}</span>
          </button>
        )}
        <input 
          ref={coverInputRef}
          type="file"
          accept="image/*"
          onChange={handleCoverUpload}
          className="hidden"
        />
      </div>

      {/* Profile Info */}
      <div className="px-4 pt-2">
        <div className="flex items-end justify-between -mt-12 mb-3">
          {/* Profile Picture - overlapping cover */}
          <div className="relative">
            <div className={`w-24 h-24 rounded-2xl p-1 ${isDark ? 'bg-black' : 'bg-white'}`}>
              <Avatar src={profileUser.avatar} name={profileUser.fullName} username={profileUser.username} size="xl" className="w-full h-full rounded-xl object-cover" />
            </div>
            {/* Story ring if has stories */}
            {isOwnProfile && (
              <div 
                className="absolute inset-0 rounded-2xl border-2 border-transparent hover:border-zinc-500 cursor-pointer"
                onClick={() => setShowEditProfile(true)}
              />
            )}
          </div>
          
          {/* Action Buttons - X style */}
          <div className="flex gap-2 mb-1">
            {isOwnProfile ? (
              <button 
                onClick={() => setShowEditProfile(true)}
                className={`px-4 py-1.5 rounded-full text-sm font-semibold border ${isDark ? 'border-zinc-600 hover:bg-zinc-900' : 'border-zinc-300 hover:bg-zinc-100'}`}
              >
                Edit profile
              </button>
            ) : (
              <>
                <button 
                  onClick={handleFollow}
                  disabled={followLoading}
                  className={`px-4 py-1.5 rounded-full text-sm font-semibold transition-colors ${
                    isFollowing 
                      ? `border ${isDark ? 'border-zinc-600 hover:bg-zinc-900' : 'border-zinc-300 hover:bg-zinc-100'}`
                      : isRequested
                        ? `border ${isDark ? 'border-zinc-600 hover:bg-zinc-900' : 'border-zinc-300 hover:bg-zinc-100'}`
                        : 'bg-[#4CAF50] text-white hover:bg-[#43A047]'
                  } ${followLoading ? 'opacity-50' : ''}`}
                >
                  {followLoading ? '...' : isFollowing ? 'Following' : isRequested ? 'Requested' : isFollowedBy ? 'Follow Back' : 'Follow'}
                </button>
                <button 
                  onClick={() => onMessage(profileUser)}
                  className={`px-4 py-1.5 rounded-full text-sm font-semibold border ${isDark ? 'border-zinc-600 hover:bg-zinc-900' : 'border-zinc-300 hover:bg-zinc-100'}`}
                >
                  Message
                </button>
              </>
            )}
          </div>
        </div>

        {/* Name & Bio - X style */}
        <div className="mt-2">
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-lg">{profileUser.fullName || profileUser.username}</span>
            {profileUser.isVerified && <Icons.Verified className="w-5 h-5" />}
            {profileUser.isPrivate && (
              <svg viewBox="0 0 24 24" fill="none" className={`w-4 h-4 ${isDark ? 'text-zinc-400' : 'text-zinc-500'}`}>
                <rect x="5" y="11" width="14" height="10" rx="2" stroke="currentColor" strokeWidth="1.5"/>
                <path d="M8 11V7a4 4 0 118 0v4" stroke="currentColor" strokeWidth="1.5"/>
              </svg>
            )}
          </div>
          <div className={`text-sm ${isDark ? 'text-zinc-500' : 'text-zinc-600'}`}>@{profileUser.username}</div>
          {profileUser.bio && <p className="text-sm whitespace-pre-line mt-2">{profileUser.bio}</p>}
          {profileUser.website && (
            <a href={profileUser.website} target="_blank" rel="noopener noreferrer" className="text-[#4CAF50] text-sm flex items-center gap-1 mt-1 hover:underline">
              <svg viewBox="0 0 24 24" fill="none" className="w-4 h-4">
                <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              {profileUser.website}
            </a>
          )}
        </div>

        {/* Stats - X style */}
        <div className="flex gap-4 mt-3 text-sm">
          <button onClick={() => setShowFollowing(true)} className="hover:underline">
            <span className="font-semibold">{stats.followingCount}</span>
            <span className={isDark ? 'text-zinc-500' : 'text-zinc-600'}> following</span>
          </button>
          <button onClick={() => setShowFollowers(true)} className="hover:underline">
            <span className="font-semibold">{stats.followersCount}</span>
            <span className={isDark ? 'text-zinc-500' : 'text-zinc-600'}> followers</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className={`flex border-b ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
        <button 
          onClick={() => setActiveTab('posts')}
          className={`flex-1 py-3 flex justify-center border-b-2 transition-colors ${activeTab === 'posts' ? (isDark ? 'border-white' : 'border-black') : 'border-transparent opacity-50'}`}
        >
          <Icons.Grid />
        </button>
        <button 
          onClick={() => setActiveTab('reels')}
          className={`flex-1 py-3 flex justify-center border-b-2 transition-colors ${activeTab === 'reels' ? (isDark ? 'border-white' : 'border-black') : 'border-transparent opacity-50'}`}
        >
          <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
            <rect x="2" y="2" width="20" height="20" rx="5" stroke="currentColor" strokeWidth="1.5"/>
            <path d="M9.5 7.5V16.5L16.5 12L9.5 7.5Z" fill="currentColor"/>
          </svg>
        </button>
        <button 
          onClick={() => setActiveTab('saved')}
          className={`flex-1 py-3 flex justify-center border-b-2 transition-colors ${activeTab === 'saved' ? (isDark ? 'border-white' : 'border-black') : 'border-transparent opacity-50'}`}
        >
          <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
            <path d="M19 21L12 16L5 21V5C5 4.46957 5.21071 3.96086 5.58579 3.58579C5.96086 3.21071 6.46957 3 7 3H17C17.5304 3 18.0391 3.21071 18.4142 3.58579C18.7893 3.96086 19 4.46957 19 5V21Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
      </div>

      {/* Posts List View */}
      {activeTab === 'posts' && (
        isProfilePrivate && !isFollowing ? (
          <div className="py-16 text-center px-8">
            <div className={`w-20 h-20 rounded-full mx-auto flex items-center justify-center ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`}>
              <svg viewBox="0 0 24 24" fill="none" className={`w-10 h-10 ${isDark ? 'text-zinc-600' : 'text-zinc-400'}`}>
                <rect x="5" y="11" width="14" height="10" rx="2" stroke="currentColor" strokeWidth="1.5"/>
                <path d="M8 11V7a4 4 0 118 0v4" stroke="currentColor" strokeWidth="1.5"/>
              </svg>
            </div>
            <h3 className="mt-4 font-semibold text-lg">This Account is Private</h3>
            <p className={`text-sm mt-2 ${isDark ? 'text-zinc-500' : 'text-zinc-600'}`}>
              {isRequested 
                ? `Follow request sent to @${profileUser.username}`
                : `Follow @${profileUser.username} to see their photos and videos.`
              }
            </p>
            {!isRequested && (
              <button
                onClick={handleFollow}
                disabled={followLoading}
                className="mt-4 px-8 py-2 rounded-lg bg-[#4CAF50] text-white font-semibold hover:bg-[#43A047] disabled:opacity-50"
              >
                {followLoading ? '...' : isFollowedBy ? 'Follow Back' : 'Follow'}
              </button>
            )}
          </div>
        ) : posts.length > 0 ? (
          <div className="divide-y">
            {posts.map((post) => (
              post.images && post.images.length > 0 ? (
                <PostCard
                  key={post.id}
                  post={post}
                  currentUserId={currentUserId}
                  onLike={async () => {
                    try {
                      await fetch(`/api/posts/${post.id}/like`, { method: 'POST' })
                    } catch (error) {
                      console.error('Like error:', error)
                    }
                  }}
                  onComment={() => {}}
                  onSave={async () => {
                    try {
                      await fetch(`/api/posts/${post.id}/save`, { method: 'POST' })
                    } catch (error) {
                      console.error('Save error:', error)
                    }
                  }}
                  onUserClick={() => onUserClick(post.author)}
                  onDeleted={() => {
                    setPosts(prev => prev.filter(p => p.id !== post.id))
                    setStats(prev => ({ ...prev, postsCount: prev.postsCount - 1 }))
                  }}
                />
              ) : (
                <TextPostCard
                  key={post.id}
                  post={post}
                  currentUserId={currentUserId}
                  onLike={async () => {
                    try {
                      await fetch(`/api/posts/${post.id}/like`, { method: 'POST' })
                    } catch (error) {
                      console.error('Like error:', error)
                    }
                  }}
                  onComment={() => {}}
                  onUserClick={() => onUserClick(post.author)}
                  onDeleted={() => {
                    setPosts(prev => prev.filter(p => p.id !== post.id))
                    setStats(prev => ({ ...prev, postsCount: prev.postsCount - 1 }))
                  }}
                />
              )
            ))}
          </div>
        ) : (
          <div className="py-16 text-center">
            <div className={`w-16 h-16 rounded-full mx-auto flex items-center justify-center ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`}>
              <Icons.Camera />
            </div>
            <h3 className="mt-4 font-semibold">No posts yet</h3>
            {isOwnProfile && (
              <p className="text-zinc-500 text-sm mt-1">When you share photos, they will appear on your profile.</p>
            )}
          </div>
        )
      )}

      {/* Reels Tab */}
      {activeTab === 'reels' && (
        <div className="py-16 text-center">
          <div className={`w-16 h-16 rounded-full mx-auto flex items-center justify-center ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`}>
            <svg viewBox="0 0 24 24" fill="none" className="w-8 h-8">
              <rect x="2" y="2" width="20" height="20" rx="5" stroke="currentColor" strokeWidth="1.5"/>
              <path d="M9.5 7.5V16.5L16.5 12L9.5 7.5Z" fill="currentColor"/>
            </svg>
          </div>
          <h3 className="mt-4 font-semibold">No reels yet</h3>
          <p className="text-zinc-500 text-sm mt-1">Share reels to see them here.</p>
        </div>
      )}

      {/* Saved Tab (only for own profile) */}
      {activeTab === 'saved' && isOwnProfile && (
        <SavedPostsTab currentUserId={currentUserId} onUserClick={onUserClick} />
      )}

      {/* Followers Modal */}
      {showFollowers && (
        <div className={`fixed inset-0 z-50 ${isDark ? 'bg-black' : 'bg-white'}`}>
          <div className={`flex items-center justify-between p-4 border-b ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
            <button onClick={() => setShowFollowers(false)}><Icons.Back /></button>
            <span className="font-semibold">Followers</span>
            <div className="w-6" />
          </div>
          <div className="max-h-[calc(100vh-60px)] overflow-y-auto">
            {followers.length > 0 ? (
              <div className={`divide-y ${isDark ? 'divide-zinc-800' : 'divide-zinc-200'}`}>
                {followers.map(f => (
                  <div 
                    key={f.id} 
                    className={`flex items-center gap-3 p-4 ${isDark ? 'hover:bg-zinc-900' : 'hover:bg-zinc-100'}`}
                  >
                    <button 
                      onClick={() => { setShowFollowers(false); onUserClick(f); }}
                      className="flex items-center gap-3 flex-1 min-w-0"
                    >
                      <Avatar src={f.avatar} name={f.fullName} username={f.username} size="md" className="w-10 h-10 rounded-xl flex-shrink-0" />
                      <div className="text-left min-w-0">
                        <div className="font-semibold text-sm truncate">{f.username}</div>
                        <div className="text-zinc-500 text-xs truncate">{f.fullName}</div>
                      </div>
                    </button>
                    {f.id !== currentUser?.id && (
                      <button 
                        onClick={(e) => { e.stopPropagation(); handleUserFollow(f.id); }}
                        disabled={userFollowLoading === f.id}
                        className={`flex-shrink-0 px-4 py-1.5 rounded-lg text-sm font-semibold transition-all ${
                          userFollowStates[f.id]
                            ? isDark 
                              ? 'bg-zinc-800 text-white hover:bg-zinc-700' 
                              : 'bg-zinc-200 text-black hover:bg-zinc-300'
                            : 'bg-[#4CAF50] text-white hover:bg-[#43A047]'
                        } ${userFollowLoading === f.id ? 'opacity-50' : ''}`}
                      >
                        {userFollowLoading === f.id ? '...' : userFollowStates[f.id] ? 'Following' : 'Follow'}
                      </button>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center text-zinc-500">
                <p>No followers yet</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Following Modal */}
      {showFollowing && (
        <div className={`fixed inset-0 z-50 ${isDark ? 'bg-black' : 'bg-white'}`}>
          <div className={`flex items-center justify-between p-4 border-b ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
            <button onClick={() => setShowFollowing(false)}><Icons.Back /></button>
            <span className="font-semibold">Following</span>
            <div className="w-6" />
          </div>
          <div className="max-h-[calc(100vh-60px)] overflow-y-auto">
            {following.length > 0 ? (
              <div className={`divide-y ${isDark ? 'divide-zinc-800' : 'divide-zinc-200'}`}>
                {following.map(f => (
                  <div 
                    key={f.id} 
                    className={`flex items-center gap-3 p-4 ${isDark ? 'hover:bg-zinc-900' : 'hover:bg-zinc-100'}`}
                  >
                    <button 
                      onClick={() => { setShowFollowing(false); onUserClick(f); }}
                      className="flex items-center gap-3 flex-1 min-w-0"
                    >
                      <Avatar src={f.avatar} name={f.fullName} username={f.username} size="md" className="w-10 h-10 rounded-xl flex-shrink-0" />
                      <div className="text-left min-w-0">
                        <div className="font-semibold text-sm truncate">{f.username}</div>
                        <div className="text-zinc-500 text-xs truncate">{f.fullName}</div>
                      </div>
                    </button>
                    {f.id !== currentUser?.id && (
                      <button 
                        onClick={(e) => { e.stopPropagation(); handleUserFollow(f.id); }}
                        disabled={userFollowLoading === f.id}
                        className={`flex-shrink-0 px-4 py-1.5 rounded-lg text-sm font-semibold transition-all ${
                          userFollowStates[f.id]
                            ? isDark 
                              ? 'bg-zinc-800 text-white hover:bg-zinc-700' 
                              : 'bg-zinc-200 text-black hover:bg-zinc-300'
                            : 'bg-[#4CAF50] text-white hover:bg-[#43A047]'
                        } ${userFollowLoading === f.id ? 'opacity-50' : ''}`}
                      >
                        {userFollowLoading === f.id ? '...' : userFollowStates[f.id] ? 'Following' : 'Follow'}
                      </button>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center text-zinc-500">
                <p>Not following anyone yet</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Edit Profile Modal */}
      {showEditProfile && (
        <EditProfileModal 
          user={profileUser}
          onClose={() => setShowEditProfile(false)}
          onUpdated={handleProfileUpdate}
        />
      )}

      {/* Share Profile Modal */}
      {showShareModal && (
        <ShareProfileModal
          user={profileUser}
          onClose={() => setShowShareModal(false)}
        />
      )}

      {/* Profile Options Modal */}
      {showProfileOptions && (
        <div className="fixed inset-0 z-50 flex items-end justify-center">
          <div className="absolute inset-0 bg-black/50" onClick={() => setShowProfileOptions(false)} />
          <div className={`relative w-full max-w-lg rounded-t-3xl ${isDark ? 'bg-zinc-900' : 'bg-white'} animate-slide-up`}>
            {/* Handle */}
            <div className="flex justify-center pt-3 pb-2">
              <div className={`w-10 h-1 rounded-full ${isDark ? 'bg-zinc-700' : 'bg-zinc-300'}`} />
            </div>
            
            {/* User Info */}
            <div className="flex items-center gap-3 px-4 pb-4">
              <Avatar src={profileUser.avatar} name={profileUser.fullName} username={profileUser.username} size="md" className="w-12 h-12 rounded-xl" />
              <div>
                <div className="font-semibold flex items-center gap-1">
                  {profileUser.username}
                  {profileUser.isVerified && <Icons.Verified />}
                </div>
                <div className={`text-sm ${isDark ? 'text-zinc-500' : 'text-zinc-600'}`}>{profileUser.fullName}</div>
              </div>
            </div>

            {/* Options List */}
            <div className={`border-t ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
              <button 
                onClick={() => { setShowProfileOptions(false); setShowReportModal(true); }}
                className={`w-full flex items-center gap-4 px-4 py-3.5 ${isDark ? 'hover:bg-zinc-800' : 'hover:bg-zinc-100'}`}
              >
                <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
                  <path d="M4 4h16v16H4V4z" stroke="currentColor" strokeWidth="1.5"/>
                  <path d="M4 9h16M9 4v16" stroke="currentColor" strokeWidth="1.5"/>
                </svg>
                <span className="text-sm">Report</span>
              </button>
              
              <button 
                onClick={handleCopyProfileLink}
                className={`w-full flex items-center gap-4 px-4 py-3.5 ${isDark ? 'hover:bg-zinc-800' : 'hover:bg-zinc-100'}`}
              >
                <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
                  <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                <span className="text-sm">{copiedLink ? '✓ Link copied!' : 'Copy link'}</span>
              </button>
              
              <button 
                onClick={() => { setShowProfileOptions(false); setShowShareModal(true); }}
                className={`w-full flex items-center gap-4 px-4 py-3.5 ${isDark ? 'hover:bg-zinc-800' : 'hover:bg-zinc-100'}`}
              >
                <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
                  <path d="M22 2L11 13" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M22 2L15 22L11 13L2 9L22 2Z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                <span className="text-sm">Share this profile</span>
              </button>

              <button 
                onClick={() => { setShowProfileOptions(false); onMessage(profileUser); }}
                className={`w-full flex items-center gap-4 px-4 py-3.5 ${isDark ? 'hover:bg-zinc-800' : 'hover:bg-zinc-100'}`}
              >
                <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
                  <path d="M4 4h16v12H4V4z" stroke="currentColor" strokeWidth="1.5"/>
                  <path d="M4 8l8 5 8-5" stroke="currentColor" strokeWidth="1.5"/>
                </svg>
                <span className="text-sm">Send message</span>
              </button>
            </div>

            {/* Cancel Button */}
            <div className={`border-t p-3 ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
              <button 
                onClick={() => setShowProfileOptions(false)}
                className={`w-full py-3 rounded-lg font-semibold text-sm ${isDark ? 'bg-zinc-800 hover:bg-zinc-700' : 'bg-zinc-200 hover:bg-zinc-300'}`}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Report Modal */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/80" onClick={() => setShowReportModal(false)} />
          <div className={`relative w-full max-w-sm mx-4 rounded-2xl ${isDark ? 'bg-zinc-900' : 'bg-white'} p-6`}>
            {!reportSubmitted ? (
              <>
                <h2 className="text-lg font-semibold mb-2">Report {profileUser.username}</h2>
                <p className={`text-sm mb-4 ${isDark ? 'text-zinc-400' : 'text-zinc-600'}`}>
                  Why are you reporting this account?
                </p>
                
                <div className="space-y-2 mb-4">
                  {[
                    "It's spam or a scam",
                    "It's pretending to be someone else",
                    "It's posting inappropriate content",
                    "It's harassing or bullying",
                    "It's violating community guidelines"
                  ].map((reason) => (
                    <button
                      key={reason}
                      onClick={() => setReportReason(reason)}
                      className={`w-full text-left px-4 py-3 rounded-lg text-sm transition-colors ${
                        reportReason === reason
                          ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                          : isDark ? 'bg-zinc-800 hover:bg-zinc-700' : 'bg-zinc-100 hover:bg-zinc-200'
                      }`}
                    >
                      {reason}
                    </button>
                  ))}
                </div>

                <div className="flex gap-3">
                  <button 
                    onClick={() => setShowReportModal(false)}
                    className={`flex-1 py-2.5 rounded-lg text-sm font-medium ${isDark ? 'bg-zinc-800 hover:bg-zinc-700' : 'bg-zinc-200 hover:bg-zinc-300'}`}
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={handleReportSubmit}
                    disabled={!reportReason.trim()}
                    className="flex-1 py-2.5 rounded-lg text-sm font-medium bg-red-500 text-white hover:bg-red-600 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Report
                  </button>
                </div>
              </>
            ) : (
              <div className="text-center py-4">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-green-500/20 flex items-center justify-center">
                  <svg viewBox="0 0 24 24" fill="none" className="w-8 h-8 text-green-500">
                    <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <h2 className="text-lg font-semibold mb-2">Thanks for your report</h2>
                <p className={`text-sm ${isDark ? 'text-zinc-400' : 'text-zinc-600'}`}>
                  We'll review your report and take appropriate action.
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

// ============ SETTINGS PAGE ============
// Settings icon components - defined outside to avoid recreation
const SettingsIcons = {
  User: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <circle cx="12" cy="8" r="4" stroke="currentColor" strokeWidth="1.5"/>
      <path d="M4 20c0-4 4-6 8-6s8 2 8 6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    </svg>
  ),
  Lock: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <rect x="5" y="11" width="14" height="10" rx="2" stroke="currentColor" strokeWidth="1.5"/>
      <path d="M8 11V7a4 4 0 118 0v4" stroke="currentColor" strokeWidth="1.5"/>
    </svg>
  ),
  Apps: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <rect x="3" y="3" width="8" height="8" rx="2" stroke="currentColor" strokeWidth="1.5"/>
      <rect x="13" y="3" width="8" height="8" rx="2" stroke="currentColor" strokeWidth="1.5"/>
      <rect x="3" y="13" width="8" height="8" rx="2" stroke="currentColor" strokeWidth="1.5"/>
      <rect x="13" y="13" width="8" height="8" rx="2" stroke="currentColor" strokeWidth="1.5"/>
    </svg>
  ),
  Eye: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7z" stroke="currentColor" strokeWidth="1.5"/>
      <circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.5"/>
    </svg>
  ),
  Heart: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" stroke="currentColor" strokeWidth="1.5" fill="none"/>
    </svg>
  ),
  Block: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="1.5"/>
      <path d="M4.93 4.93l14.14 14.14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
    </svg>
  ),
  Bell: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M13.73 21a2 2 0 01-3.46 0" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Shield: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Help: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="1.5"/>
      <path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx="12" cy="17" r="0.5" fill="currentColor"/>
    </svg>
  ),
  Info: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="1.5"/>
      <path d="M12 16v-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
      <circle cx="12" cy="8" r="0.5" fill="currentColor"/>
    </svg>
  ),
  Document: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M14 2v6h6M16 13H8M16 17H8M10 9H8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  Moon: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
      <path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  ChevronRight: () => (
    <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5">
      <path d="M9 18l6-6-6-6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
}

function SettingsMenuItem({ icon, label, value, onClick, valueColor, isDark }: {
  icon: React.ReactNode
  label: string
  value?: string
  onClick?: () => void
  valueColor?: string
  isDark: boolean
}) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-4 px-4 py-3.5 ${isDark ? 'hover:bg-zinc-900 active:bg-zinc-800' : 'hover:bg-zinc-50 active:bg-zinc-100'}`}
    >
      <span className={`${isDark ? 'text-white' : 'text-black'}`}>{icon}</span>
      <span className={`flex-1 text-left text-[15px] ${isDark ? 'text-white' : 'text-black'}`}>{label}</span>
      {value && (
        <span className={`text-sm ${valueColor || (isDark ? 'text-zinc-400' : 'text-zinc-500')}`}>{value}</span>
      )}
      <SettingsIcons.ChevronRight />
    </button>
  )
}

function SettingsSectionHeader({ title, isDark }: { title: string; isDark: boolean }) {
  return (
    <div className={`px-4 pt-6 pb-2`}>
      <span className={`text-xs font-semibold uppercase tracking-wider ${isDark ? 'text-zinc-500' : 'text-zinc-400'}`}>{title}</span>
    </div>
  )
}

// Password Change Modal
function PasswordChangeModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [showCurrentPassword, setShowCurrentPassword] = useState(false)
  const [showNewPassword, setShowNewPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'

  const handleSubmit = async () => {
    setError('')
    setSuccess(false)

    if (!currentPassword || !newPassword || !confirmPassword) {
      setError('Please fill in all fields')
      return
    }

    if (newPassword.length < 6) {
      setError('New password must be at least 6 characters')
      return
    }

    if (newPassword !== confirmPassword) {
      setError('New passwords do not match')
      return
    }

    if (currentPassword === newPassword) {
      setError('New password must be different from current password')
      return
    }

    setLoading(true)
    try {
      const res = await fetch('/api/users/password', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentPassword, newPassword })
      })
      const data = await res.json()

      if (!res.ok) {
        setError(data.error || 'Failed to update password')
      } else {
        setSuccess(true)
        setCurrentPassword('')
        setNewPassword('')
        setConfirmPassword('')
        setTimeout(() => {
          onClose()
        }, 1500)
      }
    } catch (err) {
      setError('Failed to update password')
    } finally {
      setLoading(false)
    }
  }

  const handleClose = () => {
    setCurrentPassword('')
    setNewPassword('')
    setConfirmPassword('')
    setError('')
    setSuccess(false)
    onClose()
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80" onClick={handleClose} />
      <div className={`relative w-full max-w-md rounded-2xl ${isDark ? 'bg-zinc-900' : 'bg-white'} p-6`}>
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold">Change Password</h2>
          <button onClick={handleClose} className={`p-1 rounded-full ${isDark ? 'hover:bg-zinc-800' : 'hover:bg-zinc-100'}`}>
            <Icons.Close />
          </button>
        </div>

        {success ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-green-500/20 flex items-center justify-center">
              <svg viewBox="0 0 24 24" fill="none" className="w-8 h-8 text-green-500">
                <path d="M5 13l4 4L19 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <h3 className="text-lg font-semibold mb-2">Password Updated</h3>
            <p className={`text-sm ${isDark ? 'text-zinc-400' : 'text-zinc-600'}`}>Your password has been changed successfully.</p>
          </div>
        ) : (
          <>
            {/* Current Password */}
            <div className="mb-4">
              <label className={`text-sm font-medium ${isDark ? 'text-zinc-300' : 'text-zinc-700'}`}>Current Password</label>
              <div className="relative mt-1">
                <input
                  type={showCurrentPassword ? 'text' : 'password'}
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className={`w-full border rounded-xl px-4 py-3 pr-12 text-sm ${isDark ? 'bg-zinc-800 border-zinc-700 text-white' : 'bg-zinc-50 border-zinc-200 text-black'}`}
                  placeholder="Enter current password"
                />
                <button
                  type="button"
                  onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500"
                >
                  {showCurrentPassword ? (
                    <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5">
                      <path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                      <line x1="1" y1="1" x2="23" y2="23" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                    </svg>
                  ) : (
                    <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5">
                      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke="currentColor" strokeWidth="1.5"/>
                      <circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.5"/>
                    </svg>
                  )}
                </button>
              </div>
            </div>

            {/* New Password */}
            <div className="mb-4">
              <label className={`text-sm font-medium ${isDark ? 'text-zinc-300' : 'text-zinc-700'}`}>New Password</label>
              <div className="relative mt-1">
                <input
                  type={showNewPassword ? 'text' : 'password'}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className={`w-full border rounded-xl px-4 py-3 pr-12 text-sm ${isDark ? 'bg-zinc-800 border-zinc-700 text-white' : 'bg-zinc-50 border-zinc-200 text-black'}`}
                  placeholder="Enter new password"
                />
                <button
                  type="button"
                  onClick={() => setShowNewPassword(!showNewPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500"
                >
                  {showNewPassword ? (
                    <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5">
                      <path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                      <line x1="1" y1="1" x2="23" y2="23" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                    </svg>
                  ) : (
                    <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5">
                      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke="currentColor" strokeWidth="1.5"/>
                      <circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.5"/>
                    </svg>
                  )}
                </button>
              </div>
              <p className={`text-xs mt-1 ${isDark ? 'text-zinc-500' : 'text-zinc-500'}`}>Must be at least 6 characters</p>
            </div>

            {/* Confirm New Password */}
            <div className="mb-4">
              <label className={`text-sm font-medium ${isDark ? 'text-zinc-300' : 'text-zinc-700'}`}>Confirm New Password</label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className={`w-full border rounded-xl px-4 py-3 mt-1 text-sm ${isDark ? 'bg-zinc-800 border-zinc-700 text-white' : 'bg-zinc-50 border-zinc-200 text-black'}`}
                placeholder="Confirm new password"
              />
            </div>

            {/* Error Message */}
            {error && (
              <div className="mb-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20">
                <p className="text-sm text-red-500">{error}</p>
              </div>
            )}

            {/* Buttons */}
            <div className="flex gap-3 pt-2">
              <button
                onClick={handleClose}
                className={`flex-1 py-3 rounded-xl font-medium ${isDark ? 'bg-zinc-800 text-white hover:bg-zinc-700' : 'bg-zinc-200 text-black hover:bg-zinc-300'}`}
              >
                Cancel
              </button>
              <button
                onClick={handleSubmit}
                disabled={loading || !currentPassword || !newPassword || !confirmPassword}
                className="flex-1 py-3 rounded-xl font-medium bg-[#4CAF50] text-white hover:bg-[#43A047] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? 'Updating...' : 'Update Password'}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  )
}

function SettingsPage({ user, onBack, onLogout, onUpdated, onAdminClick }: {
  user: User
  onBack: () => void
  onLogout: () => void
  onUpdated: (user: User) => void
  onAdminClick?: () => void
}) {
  const [editing, setEditing] = useState(false)
  const [fullName, setFullName] = useState(user.fullName || '')
  const [bio, setBio] = useState(user.bio || '')
  const [website, setWebsite] = useState(user.website || '')
  const [isPrivate, setIsPrivate] = useState(user.isPrivate)
  const [showVerification, setShowVerification] = useState(false)
  const [showPasswordModal, setShowPasswordModal] = useState(false)
  const [blockedCount, setBlockedCount] = useState(0)
  const { theme, setTheme } = useInstagramStore()
  const isDark = theme === 'dark'

  // Fetch blocked count
  useEffect(() => {
    fetch('/api/users/blocked')
      .then(r => r.json())
      .then(data => setBlockedCount(data.count || 0))
      .catch(() => {})
  }, [])

  const handleSave = async () => {
    const res = await fetch('/api/users/me', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fullName, bio, website, isPrivate })
    })
    const data = await res.json()
    if (data.user) {
      onUpdated(data.user)
      setEditing(false)
    }
  }

  const handlePrivacyChange = async () => {
    const newValue = !isPrivate
    setIsPrivate(newValue)
    await fetch('/api/users/me', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isPrivate: newValue })
    })
  }

  return (
    <div className={`pb-16 min-h-screen ${isDark ? 'bg-black text-white' : 'bg-white text-black'}`}>
      {/* Header */}
      <div className={`sticky top-0 z-10 flex items-center px-4 py-3 border-b ${isDark ? 'bg-black border-zinc-800' : 'bg-white border-zinc-200'}`}>
        <button onClick={onBack} className="p-1 -ml-1">
          <Icons.Back />
        </button>
        <span className="flex-1 text-center font-semibold text-lg mr-6">Settings</span>
      </div>

      {editing ? (
        <div className="p-4 space-y-4">
          <div className="flex items-center gap-4 mb-6">
            <Avatar src={user.avatar} name={user.fullName} username={user.username} size="lg" />
            <div>
              <div className="font-semibold text-lg">{user.username}</div>
              <button className="text-[#4CAF50] text-sm font-medium">Change profile photo</button>
            </div>
          </div>

          <div>
            <label className={`text-xs font-medium ${isDark ? 'text-zinc-500' : 'text-zinc-600'}`}>Name</label>
            <input
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className={`w-full border rounded-xl px-3 py-2.5 mt-1 text-sm ${isDark ? 'bg-zinc-900 border-zinc-700 text-white' : 'bg-zinc-50 border-zinc-200 text-black'}`}
            />
          </div>

          <div>
            <label className={`text-xs font-medium ${isDark ? 'text-zinc-500' : 'text-zinc-600'}`}>Bio</label>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className={`w-full border rounded-xl px-3 py-2.5 mt-1 h-24 resize-none text-sm ${isDark ? 'bg-zinc-900 border-zinc-700 text-white' : 'bg-zinc-50 border-zinc-200 text-black'}`}
            />
          </div>

          <div>
            <label className={`text-xs font-medium ${isDark ? 'text-zinc-500' : 'text-zinc-600'}`}>Website</label>
            <input
              type="text"
              value={website}
              onChange={(e) => setWebsite(e.target.value)}
              className={`w-full border rounded-xl px-3 py-2.5 mt-1 text-sm ${isDark ? 'bg-zinc-900 border-zinc-700 text-white' : 'bg-zinc-50 border-zinc-200 text-black'}`}
            />
          </div>

          <div className="flex gap-3 pt-4">
            <button onClick={() => setEditing(false)} className={`flex-1 py-2.5 rounded-lg font-medium ${isDark ? 'bg-zinc-800 text-white' : 'bg-zinc-200 text-black'}`}>Cancel</button>
            <button onClick={handleSave} className="flex-1 bg-[#4CAF50] text-white py-2.5 rounded-lg font-medium">Save</button>
          </div>
        </div>
      ) : (
        <div>
          {/* Profile Section */}
          <button
            onClick={() => setEditing(true)}
            className={`w-full flex items-center gap-4 p-4 ${isDark ? 'hover:bg-zinc-900' : 'hover:bg-zinc-50'}`}
          >
            <Avatar src={user.avatar} name={user.fullName} username={user.username} size="lg" />
            <div className="flex-1 text-left">
              <div className="font-semibold text-lg flex items-center gap-1">
                {user.fullName || user.username}
                {user.isVerified && <Icons.Verified />}
              </div>
              <div className={`text-sm ${isDark ? 'text-zinc-400' : 'text-zinc-500'}`}>@{user.username}</div>
            </div>
            <SettingsIcons.ChevronRight />
          </button>

          {/* Search Bar */}
          <div className={`px-4 py-2 border-t ${isDark ? 'border-zinc-800' : 'border-zinc-100'}`}>
            <div className={`flex items-center gap-3 px-4 py-2.5 rounded-lg ${isDark ? 'bg-zinc-900' : 'bg-zinc-100'}`}>
              <svg viewBox="0 0 24 24" fill="none" className={`w-5 h-5 ${isDark ? 'text-zinc-500' : 'text-zinc-400'}`}>
                <circle cx="11" cy="11" r="8" stroke="currentColor" strokeWidth="1.5"/>
                <path d="M21 21l-4.35-4.35" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
              <input
                type="text"
                placeholder="Search settings"
                className={`flex-1 bg-transparent text-sm outline-none ${isDark ? 'text-white placeholder-zinc-500' : 'text-black placeholder-zinc-400'}`}
              />
            </div>
          </div>

          {/* Account Section */}
          <SettingsSectionHeader title="Account" isDark={isDark} />
          <div className={`border-t ${isDark ? 'border-zinc-800' : 'border-zinc-100'}`}>
            <SettingsMenuItem
              icon={<SettingsIcons.User />}
              label="Personal details"
              onClick={() => setEditing(true)}
              isDark={isDark}
            />
            <SettingsMenuItem
              icon={<SettingsIcons.Lock />}
              label="Password"
              onClick={() => setShowPasswordModal(true)}
              isDark={isDark}
            />
            <SettingsMenuItem
              icon={<SettingsIcons.Apps />}
              label="Apps and websites"
              isDark={isDark}
            />
          </div>

          {/* Privacy Section */}
          <SettingsSectionHeader title="Privacy" isDark={isDark} />
          <div className={`border-t ${isDark ? 'border-zinc-800' : 'border-zinc-100'}`}>
            <SettingsMenuItem
              icon={<SettingsIcons.Eye />}
              label="Account privacy"
              value={isPrivate ? 'Private' : 'Public'}
              onClick={handlePrivacyChange}
              valueColor={isPrivate ? '#4CAF50' : undefined}
              isDark={isDark}
            />
            <SettingsMenuItem
              icon={<SettingsIcons.Heart />}
              label="Close friends"
              isDark={isDark}
            />
            <SettingsMenuItem
              icon={<SettingsIcons.Block />}
              label="Blocked"
              value={blockedCount > 0 ? blockedCount.toString() : undefined}
              isDark={isDark}
            />
          </div>

          {/* Notifications Section */}
          <SettingsSectionHeader title="Notifications" isDark={isDark} />
          <div className={`border-t ${isDark ? 'border-zinc-800' : 'border-zinc-100'}`}>
            <SettingsMenuItem
              icon={<SettingsIcons.Bell />}
              label="Notifications"
              isDark={isDark}
            />
          </div>

          {/* Appearance Section */}
          <SettingsSectionHeader title="Appearance" isDark={isDark} />
          <div className={`border-t ${isDark ? 'border-zinc-800' : 'border-zinc-100'}`}>
            <SettingsMenuItem
              icon={<SettingsIcons.Moon />}
              label="Theme"
              value={theme === 'dark' ? 'Dark' : 'Light'}
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              isDark={isDark}
            />
          </div>

          {/* Support Section */}
          <SettingsSectionHeader title="Support" isDark={isDark} />
          <div className={`border-t ${isDark ? 'border-zinc-800' : 'border-zinc-100'}`}>
            <SettingsMenuItem
              icon={<SettingsIcons.Help />}
              label="Help"
              isDark={isDark}
            />
            <SettingsMenuItem
              icon={<SettingsIcons.Info />}
              label="Report a problem"
              isDark={isDark}
            />
          </div>

          {/* About Section */}
          <SettingsSectionHeader title="About" isDark={isDark} />
          <div className={`border-t ${isDark ? 'border-zinc-800' : 'border-zinc-100'}`}>
            <SettingsMenuItem
              icon={<SettingsIcons.Document />}
              label="Terms"
              isDark={isDark}
            />
            <SettingsMenuItem
              icon={<SettingsIcons.Shield />}
              label="Privacy policy"
              isDark={isDark}
            />
          </div>

          {/* Admin Panel (if admin) */}
          {user.isAdmin && onAdminClick && (
            <>
              <SettingsSectionHeader title="Admin" isDark={isDark} />
              <div className={`border-t ${isDark ? 'border-zinc-800' : 'border-zinc-100'}`}>
                <SettingsMenuItem
                  icon={<svg viewBox="0 0 24 24" fill="none" className="w-6 h-6"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>}
                  label="Admin Panel"
                  onClick={onAdminClick}
                  valueColor="#4CAF50"
                  isDark={isDark}
                />
              </div>
            </>
          )}

          {/* Request Verification */}
          {!user.isVerified && (
            <div className={`border-t ${isDark ? 'border-zinc-800' : 'border-zinc-100'}`}>
              <SettingsMenuItem
                icon={<svg viewBox="0 0 24 24" fill="none" className="w-6 h-6"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>}
                label="Request verification"
                onClick={() => setShowVerification(true)}
                valueColor="#4CAF50"
                isDark={isDark}
              />
            </div>
          )}

          {/* Logout */}
          <div className={`mt-4 border-t ${isDark ? 'border-zinc-800' : 'border-zinc-100'}`}>
            <button
              onClick={onLogout}
              className={`w-full flex items-center gap-4 px-4 py-3.5 ${isDark ? 'hover:bg-zinc-900 active:bg-zinc-800' : 'hover:bg-zinc-50 active:bg-zinc-100'}`}
            >
              <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
                <path d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <span className="text-[15px] text-red-500 font-medium">Log out</span>
            </button>
          </div>

          {/* Add account */}
          <button
            className={`w-full flex items-center gap-4 px-4 py-3.5 border-t ${isDark ? 'border-zinc-800 hover:bg-zinc-900' : 'border-zinc-100 hover:bg-zinc-50'}`}
          >
            <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
              <path d="M16 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="8.5" cy="7" r="4" stroke="currentColor" strokeWidth="1.5"/>
              <path d="M20 8v6m3-3h-6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <span className="text-[15px] text-[#4CAF50] font-medium">Add account</span>
          </button>

          {/* Version */}
          <div className={`text-center text-xs py-6 ${isDark ? 'text-zinc-600' : 'text-zinc-400'}`}>
            hey v1.0.0
          </div>
        </div>
      )}

      {/* Verification Modal */}
      {showVerification && (
        <VerificationModal
          onClose={() => setShowVerification(false)}
          onVerified={() => {
            onUpdated({ ...user, isVerified: true })
            setShowVerification(false)
          }}
        />
      )}

      {/* Password Change Modal */}
      <PasswordChangeModal
        isOpen={showPasswordModal}
        onClose={() => setShowPasswordModal(false)}
      />
    </div>
  )
}

// ============ ADMIN PANEL ============
function AdminPanel({ onBack }: { onBack: () => void }) {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'users' | 'posts' | 'verifications'>('dashboard')
  const [stats, setStats] = useState<any>(null)
  const [users, setUsers] = useState<any[]>([])
  const [posts, setPosts] = useState<any[]>([])
  const [verifications, setVerifications] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [userPage, setUserPage] = useState(1)
  const [postPage, setPostPage] = useState(1)
  const [totalUsers, setTotalUsers] = useState(0)
  const [totalPosts, setTotalPosts] = useState(0)
  const [selectedUser, setSelectedUser] = useState<any>(null)
  const [selectedPost, setSelectedPost] = useState<any>(null)
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'

  // Fetch data based on active tab
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      try {
        if (activeTab === 'dashboard') {
          const res = await fetch('/api/admin/stats')
          const data = await res.json()
          setStats(data)
        } else if (activeTab === 'users') {
          const res = await fetch(`/api/admin/users?search=${encodeURIComponent(searchQuery)}&page=${userPage}`)
          const data = await res.json()
          setUsers(data.users || [])
          setTotalUsers(data.total || 0)
        } else if (activeTab === 'posts') {
          const res = await fetch(`/api/admin/posts?page=${postPage}`)
          const data = await res.json()
          setPosts(data.posts || [])
          setTotalPosts(data.total || 0)
        } else if (activeTab === 'verifications') {
          const res = await fetch('/api/admin/verification')
          const data = await res.json()
          setVerifications(data.requests || [])
        }
      } catch (error) {
        console.error('Fetch error:', error)
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [activeTab, searchQuery, userPage, postPage])

  const handleUserAction = async (userId: string, action: string) => {
    try {
      const res = await fetch('/api/admin/users', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, action })
      })
      if (res.ok) {
        const data = await res.json()
        setUsers(prev => prev.map(u => u.id === userId ? data.user : u))
        if (selectedUser?.id === userId) {
          setSelectedUser(data.user)
        }
      }
    } catch (error) {
      console.error('Action error:', error)
    }
  }

  const handleDeleteUser = async (userId: string) => {
    if (!confirm('Are you sure you want to delete this user? This cannot be undone.')) return
    try {
      const res = await fetch(`/api/admin/users?userId=${userId}`, { method: 'DELETE' })
      if (res.ok) {
        setUsers(prev => prev.filter(u => u.id !== userId))
        setSelectedUser(null)
      }
    } catch (error) {
      console.error('Delete error:', error)
    }
  }

  const handleDeletePost = async (postId: string) => {
    if (!confirm('Are you sure you want to delete this post?')) return
    try {
      const res = await fetch(`/api/admin/posts?postId=${postId}`, { method: 'DELETE' })
      if (res.ok) {
        setPosts(prev => prev.filter(p => p.id !== postId))
        setSelectedPost(null)
      }
    } catch (error) {
      console.error('Delete error:', error)
    }
  }

  const handleVerificationAction = async (requestId: string, action: 'approve' | 'reject', reason?: string) => {
    try {
      const res = await fetch('/api/admin/verification', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requestId, action, reason })
      })
      if (res.ok) {
        setVerifications(prev => prev.filter(v => v.id !== requestId))
      }
    } catch (error) {
      console.error('Verification action error:', error)
    }
  }

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: '📊' },
    { id: 'users', label: 'Users', icon: '👥' },
    { id: 'posts', label: 'Posts', icon: '📷' },
    { id: 'verifications', label: 'Verifications', icon: '✅' },
  ]

  return (
    <div className={`pb-16 min-h-screen ${isDark ? 'bg-black text-white' : 'bg-white text-black'}`}>
      {/* Header */}
      <div className={`sticky top-0 z-10 flex items-center px-4 py-3 border-b ${isDark ? 'bg-black border-zinc-800' : 'bg-white border-zinc-200'}`}>
        <button onClick={onBack} className="p-1 -ml-1">
          <Icons.Back />
        </button>
        <span className="flex-1 text-center font-semibold text-lg mr-6">Admin Panel</span>
      </div>

      {/* Tabs */}
      <div className={`flex border-b ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex-1 py-3 text-sm font-medium flex flex-col items-center gap-1 ${
              activeTab === tab.id
                ? 'text-[#4CAF50] border-b-2 border-[#4CAF50]'
                : isDark ? 'text-zinc-400' : 'text-zinc-600'
            }`}
          >
            <span>{tab.icon}</span>
            <span className="text-xs">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="p-4">
        {loading ? (
          <div className="flex justify-center py-8">
            <div className="w-8 h-8 border-2 border-zinc-500 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <>
            {/* Dashboard Tab */}
            {activeTab === 'dashboard' && stats && (
              <div className="space-y-4">
                <h2 className="text-lg font-semibold">Overview</h2>
                <div className="grid grid-cols-2 gap-3">
                  <div className={`p-4 rounded-xl ${isDark ? 'bg-zinc-900' : 'bg-zinc-100'}`}>
                    <p className="text-2xl font-bold">{stats.totalUsers}</p>
                    <p className="text-sm text-zinc-500">Total Users</p>
                  </div>
                  <div className={`p-4 rounded-xl ${isDark ? 'bg-zinc-900' : 'bg-zinc-100'}`}>
                    <p className="text-2xl font-bold">{stats.totalPosts}</p>
                    <p className="text-sm text-zinc-500">Total Posts</p>
                  </div>
                  <div className={`p-4 rounded-xl ${isDark ? 'bg-zinc-900' : 'bg-zinc-100'}`}>
                    <p className="text-2xl font-bold">{stats.totalStories}</p>
                    <p className="text-sm text-zinc-500">Active Stories</p>
                  </div>
                  <div className={`p-4 rounded-xl ${isDark ? 'bg-zinc-900' : 'bg-zinc-100'}`}>
                    <p className="text-2xl font-bold">{stats.totalComments}</p>
                    <p className="text-sm text-zinc-500">Comments</p>
                  </div>
                  <div className={`p-4 rounded-xl ${isDark ? 'bg-zinc-900' : 'bg-zinc-100'}`}>
                    <p className="text-2xl font-bold">{stats.totalLikes}</p>
                    <p className="text-sm text-zinc-500">Total Likes</p>
                  </div>
                  <div className={`p-4 rounded-xl ${isDark ? 'bg-zinc-900' : 'bg-zinc-100'}`}>
                    <p className="text-2xl font-bold">{stats.verifiedUsers}</p>
                    <p className="text-sm text-zinc-500">Verified Users</p>
                  </div>
                </div>
                
                <h3 className="text-lg font-semibold mt-6">Today's Activity</h3>
                <div className="grid grid-cols-2 gap-3">
                  <div className={`p-4 rounded-xl ${isDark ? 'bg-zinc-900' : 'bg-zinc-100'}`}>
                    <p className="text-2xl font-bold text-green-500">{stats.newUsersToday}</p>
                    <p className="text-sm text-zinc-500">New Users</p>
                  </div>
                  <div className={`p-4 rounded-xl ${isDark ? 'bg-zinc-900' : 'bg-zinc-100'}`}>
                    <p className="text-2xl font-bold text-green-500">{stats.newPostsToday}</p>
                    <p className="text-sm text-zinc-500">New Posts</p>
                  </div>
                </div>

                {stats.bannedUsers > 0 && (
                  <div className={`p-4 rounded-xl ${isDark ? 'bg-red-900/20 border border-red-800' : 'bg-red-50 border border-red-200'}`}>
                    <p className="text-lg font-bold text-red-500">{stats.bannedUsers}</p>
                    <p className="text-sm text-red-400">Banned Users</p>
                  </div>
                )}
              </div>
            )}

            {/* Users Tab */}
            {activeTab === 'users' && (
              <div className="space-y-4">
                <input
                  type="text"
                  placeholder="Search users..."
                  value={searchQuery}
                  onChange={(e) => { setSearchQuery(e.target.value); setUserPage(1) }}
                  className={`w-full px-4 py-2 rounded-lg border ${isDark ? 'bg-zinc-900 border-zinc-700' : 'bg-zinc-50 border-zinc-200'}`}
                />
                
                <div className={`divide-y ${isDark ? 'divide-zinc-800' : 'divide-zinc-200'}`}>
                  {users.map(user => (
                    <div key={user.id} className="py-3">
                      <div className="flex items-center gap-3">
                        <Avatar src={user.avatar} name={user.fullName} username={user.username} size="md" className="w-10 h-10" />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1">
                            <span className="font-medium truncate">{user.username}</span>
                            {user.isVerified && <Icons.Verified />}
                            {user.isAdmin && <span className="text-xs bg-yellow-500/20 text-yellow-500 px-1.5 py-0.5 rounded">Admin</span>}
                            {user.isBanned && <span className="text-xs bg-red-500/20 text-red-500 px-1.5 py-0.5 rounded">Banned</span>}
                          </div>
                          <p className="text-sm text-zinc-500 truncate">{user.email}</p>
                        </div>
                        <button
                          onClick={() => setSelectedUser(selectedUser?.id === user.id ? null : user)}
                          className="text-sm text-[#4CAF50]"
                        >
                          {selectedUser?.id === user.id ? 'Close' : 'Manage'}
                        </button>
                      </div>
                      
                      {selectedUser?.id === user.id && (
                        <div className={`mt-3 p-3 rounded-lg ${isDark ? 'bg-zinc-900' : 'bg-zinc-100'}`}>
                          <div className="grid grid-cols-3 gap-2 text-center text-sm mb-3">
                            <div>
                              <p className="font-bold">{user._count?.posts || 0}</p>
                              <p className="text-zinc-500 text-xs">Posts</p>
                            </div>
                            <div>
                              <p className="font-bold">{user._count?.followers || 0}</p>
                              <p className="text-zinc-500 text-xs">Followers</p>
                            </div>
                            <div>
                              <p className="font-bold">{user._count?.following || 0}</p>
                              <p className="text-zinc-500 text-xs">Following</p>
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {user.isBanned ? (
                              <button onClick={() => handleUserAction(user.id, 'unban')} className="px-3 py-1.5 bg-green-500 text-white text-sm rounded-lg">Unban</button>
                            ) : (
                              <button onClick={() => handleUserAction(user.id, 'ban')} className="px-3 py-1.5 bg-red-500 text-white text-sm rounded-lg">Ban</button>
                            )}
                            {user.isVerified ? (
                              <button onClick={() => handleUserAction(user.id, 'unverify')} className="px-3 py-1.5 bg-zinc-500 text-white text-sm rounded-lg">Unverify</button>
                            ) : (
                              <button onClick={() => handleUserAction(user.id, 'verify')} className="px-3 py-1.5 bg-[#4CAF50] text-white text-sm rounded-lg">Verify</button>
                            )}
                            {user.isAdmin ? (
                              <button onClick={() => handleUserAction(user.id, 'removeAdmin')} className="px-3 py-1.5 bg-orange-500 text-white text-sm rounded-lg">Remove Admin</button>
                            ) : (
                              <button onClick={() => handleUserAction(user.id, 'makeAdmin')} className="px-3 py-1.5 bg-purple-500 text-white text-sm rounded-lg">Make Admin</button>
                            )}
                            <button onClick={() => handleDeleteUser(user.id)} className="px-3 py-1.5 bg-red-700 text-white text-sm rounded-lg">Delete</button>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
                
                {totalUsers > 20 && (
                  <div className="flex justify-center gap-2 pt-4">
                    <button
                      onClick={() => setUserPage(p => Math.max(1, p - 1))}
                      disabled={userPage === 1}
                      className="px-4 py-2 rounded-lg bg-zinc-700 disabled:opacity-50"
                    >
                      Previous
                    </button>
                    <span className="px-4 py-2">Page {userPage}</span>
                    <button
                      onClick={() => setUserPage(p => p + 1)}
                      disabled={userPage * 20 >= totalUsers}
                      className="px-4 py-2 rounded-lg bg-zinc-700 disabled:opacity-50"
                    >
                      Next
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Posts Tab */}
            {activeTab === 'posts' && (
              <div className="space-y-4">
                <div className={`divide-y ${isDark ? 'divide-zinc-800' : 'divide-zinc-200'}`}>
                  {posts.map(post => (
                    <div key={post.id} className="py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-16 h-16 rounded-lg overflow-hidden bg-zinc-800 flex-shrink-0">
                          {post.images?.[0]?.url ? (
                            <img src={post.images[0].url} alt="" className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <Icons.Image />
                            </div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{post.author?.username}</span>
                            {post.author?.isVerified && <Icons.Verified />}
                          </div>
                          <p className="text-sm text-zinc-500 truncate">{post.caption || 'No caption'}</p>
                          <div className="flex items-center gap-3 text-xs text-zinc-500 mt-1">
                            <span>❤️ {post._count?.likes || 0}</span>
                            <span>💬 {post._count?.comments || 0}</span>
                            <span>{new Date(post.createdAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                        <button
                          onClick={() => setSelectedPost(selectedPost?.id === post.id ? null : post)}
                          className="text-sm text-[#4CAF50]"
                        >
                          {selectedPost?.id === post.id ? 'Close' : 'View'}
                        </button>
                      </div>
                      
                      {selectedPost?.id === post.id && (
                        <div className={`mt-3 p-3 rounded-lg ${isDark ? 'bg-zinc-900' : 'bg-zinc-100'}`}>
                          {post.caption && (
                            <p className="text-sm mb-3">{post.caption}</p>
                          )}
                          {post.location && (
                            <p className="text-sm text-zinc-500 mb-3">📍 {post.location}</p>
                          )}
                          <div className="flex gap-2">
                            <button onClick={() => handleDeletePost(post.id)} className="px-4 py-2 bg-red-500 text-white text-sm rounded-lg">
                              Delete Post
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
                
                {totalPosts > 20 && (
                  <div className="flex justify-center gap-2 pt-4">
                    <button
                      onClick={() => setPostPage(p => Math.max(1, p - 1))}
                      disabled={postPage === 1}
                      className="px-4 py-2 rounded-lg bg-zinc-700 disabled:opacity-50"
                    >
                      Previous
                    </button>
                    <span className="px-4 py-2">Page {postPage}</span>
                    <button
                      onClick={() => setPostPage(p => p + 1)}
                      disabled={postPage * 20 >= totalPosts}
                      className="px-4 py-2 rounded-lg bg-zinc-700 disabled:opacity-50"
                    >
                      Next
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Verifications Tab */}
            {activeTab === 'verifications' && (
              <div className="space-y-4">
                {verifications.length === 0 ? (
                  <div className="text-center py-8 text-zinc-500">
                    No pending verification requests
                  </div>
                ) : (
                  <div className={`divide-y ${isDark ? 'divide-zinc-800' : 'divide-zinc-200'}`}>
                    {verifications.map(request => (
                      <div key={request.id} className="py-4">
                        <div className="flex items-center gap-3">
                          <Avatar src={request.user?.avatar} name={request.user?.fullName} username={request.user?.username} size="md" className="w-10 h-10" />
                          <div className="flex-1">
                            <div className="flex items-center gap-1">
                              <span className="font-medium">{request.user?.username}</span>
                              {request.user?.isVerified && <Icons.Verified />}
                            </div>
                            <p className="text-sm text-zinc-500">{request.category} • {request.fullName}</p>
                            <p className="text-xs text-zinc-500">{new Date(request.createdAt).toLocaleDateString()}</p>
                          </div>
                          <span className="text-xs bg-yellow-500/20 text-yellow-500 px-2 py-1 rounded">
                            Pending
                          </span>
                        </div>
                        
                        <div className={`mt-3 p-3 rounded-lg ${isDark ? 'bg-zinc-900' : 'bg-zinc-100'}`}>
                          <div className="grid grid-cols-2 gap-2 mb-3">
                            <div>
                              <p className="text-xs text-zinc-500 mb-1">ID Type</p>
                              <p className="text-sm capitalize">{request.idType?.replace('_', ' ')}</p>
                            </div>
                            <div>
                              <p className="text-xs text-zinc-500 mb-1">ID Number</p>
                              <p className="text-sm">****{request.idNumber?.slice(-4)}</p>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-2 mb-3">
                            <div>
                              <p className="text-xs text-zinc-500 mb-1">ID Document</p>
                              <a href={request.idImageUrl} target="_blank" rel="noopener noreferrer" className="text-sm text-[#4CAF50] underline">
                                View Document
                              </a>
                            </div>
                            {request.selfieUrl && (
                              <div>
                                <p className="text-xs text-zinc-500 mb-1">Selfie</p>
                                <a href={request.selfieUrl} target="_blank" rel="noopener noreferrer" className="text-sm text-[#4CAF50] underline">
                                  View Selfie
                                </a>
                              </div>
                            )}
                          </div>
                          
                          <div className="flex gap-2">
                            <button
                              onClick={() => handleVerificationAction(request.id, 'approve')}
                              className="flex-1 py-2 bg-green-500 text-white text-sm rounded-lg font-medium"
                            >
                              Approve
                            </button>
                            <button
                              onClick={() => {
                                const reason = prompt('Enter rejection reason:')
                                if (reason) handleVerificationAction(request.id, 'reject', reason)
                              }}
                              className="flex-1 py-2 bg-red-500 text-white text-sm rounded-lg font-medium"
                            >
                              Reject
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}

// ============ SEARCH PAGE ============
function SearchPage({ onUserClick }: { onUserClick: (user: User) => void }) {
  const [query, setQuery] = useState('')
  const [users, setUsers] = useState<User[]>([])
  const [searching, setSearching] = useState(false)
  const [followingStates, setFollowingStates] = useState<Record<string, boolean>>({})
  const [followLoading, setFollowLoading] = useState<string | null>(null)
  const { theme, currentUser } = useInstagramStore()
  const isDark = theme === 'dark'

  useEffect(() => {
    const search = async () => {
      if (!query.trim()) {
        setUsers([])
        return
      }
      setSearching(true)
      try {
        const res = await fetch(`/api/users/search?q=${encodeURIComponent(query)}`)
        const data = await res.json()
        setUsers(data.users || [])
        // Initialize following states
        const states: Record<string, boolean> = {}
        ;(data.users || []).forEach((u: User) => {
          states[u.id] = u.isFollowing || false
        })
        setFollowingStates(states)
      } catch (error) {
        console.error('Search error:', error)
      } finally {
        setSearching(false)
      }
    }

    const timeout = setTimeout(search, 300)
    return () => clearTimeout(timeout)
  }, [query])

  const handleFollow = async (e: React.MouseEvent, userId: string) => {
    e.stopPropagation()
    if (followLoading === userId || userId === currentUser?.id) return
    setFollowLoading(userId)
    try {
      const res = await fetch(`/api/users/${userId}/follow`, { method: 'POST' })
      const data = await res.json()
      setFollowingStates(prev => ({ ...prev, [userId]: data.isFollowing }))
    } catch (error) {
      console.error('Follow error:', error)
    } finally {
      setFollowLoading(null)
    }
  }

  return (
    <div className={`pb-16 min-h-screen ${isDark ? 'bg-black text-white' : 'bg-white text-black'}`}>
      <div className="p-4">
        <div className={`flex items-center rounded-lg px-3 py-2 gap-2 ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`}>
          <Icons.Search />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search users..."
            className={`flex-1 bg-transparent outline-none text-sm ${isDark ? 'text-white placeholder-zinc-500' : 'text-black placeholder-zinc-500'}`}
          />
          {query && (
            <button onClick={() => setQuery('')}><Icons.Close /></button>
          )}
        </div>
      </div>

      <div className={`divide-y ${isDark ? 'divide-zinc-800' : 'divide-zinc-200'}`}>
        {users.map(user => (
          <div
            key={user.id}
            onClick={() => onUserClick(user)}
            className={`w-full flex items-center gap-3 p-4 cursor-pointer ${isDark ? 'hover:bg-zinc-900' : 'hover:bg-zinc-100'}`}
          >
            <Avatar src={user.avatar} name={user.fullName} username={user.username} size="md" className="w-10 h-10 rounded-xl" />
            <div className="flex-1 min-w-0">
              <div className="font-semibold text-sm flex items-center gap-1">
                {user.username}
                {user.isVerified && <Icons.Verified />}
              </div>
              <div className="text-zinc-500 text-xs truncate">{user.fullName}</div>
            </div>
            {/* Follow/Following button */}
            {user.id !== currentUser?.id && (
              <button 
                onClick={(e) => handleFollow(e, user.id)}
                disabled={followLoading === user.id}
                className={`px-4 py-1.5 rounded-lg text-sm font-semibold transition-all ${
                  followingStates[user.id]
                    ? isDark 
                      ? 'bg-zinc-800 text-white hover:bg-zinc-700' 
                      : 'bg-zinc-200 text-black hover:bg-zinc-300'
                    : 'bg-[#4CAF50] text-white hover:bg-[#43A047]'
                } ${followLoading === user.id ? 'opacity-50' : ''}`}
              >
                {followLoading === user.id ? '...' : followingStates[user.id] ? 'Following' : 'Follow'}
              </button>
            )}
          </div>
        ))}
        {searching && (
          <div className="p-4 text-center text-zinc-500">Searching...</div>
        )}
        {query && !searching && users.length === 0 && (
          <div className="p-4 text-center text-zinc-500">No users found</div>
        )}
      </div>
    </div>
  )
}

// ============ NOTIFICATIONS PAGE ============
interface NotificationType {
  id: string
  type: string
  content: string
  isRead: boolean
  createdAt: Date
  fromUser?: {
    id: string
    username: string
    fullName?: string
    avatar?: string
    isVerified?: boolean
  }
  post?: {
    id: string
    images: { url: string }[]
  }
  isFollowing?: boolean
}

function NotificationsPage({ onUserClick }: { onUserClick: (user: any) => void }) {
  const [notifications, setNotifications] = useState<NotificationType[]>([])
  const [following, setFollowing] = useState<Set<string>>(new Set())
  const [activeTab, setActiveTab] = useState<'activity' | 'you'>('you')
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'

  useEffect(() => {
    fetch('/api/notifications')
      .then(r => r.json())
      .then(data => {
        setNotifications(data.notifications || [])
        // Mark all as read
        fetch('/api/notifications', { method: 'PUT' }).catch(console.error)
      })
      .catch(console.error)
  }, [])

  const handleFollow = async (userId: string) => {
    try {
      const res = await fetch('/api/follow', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetUserId: userId })
      })
      if (res.ok) {
        const data = await res.json()
        if (data.following) {
          setFollowing(prev => new Set([...prev, userId]))
        }
      }
    } catch (error) {
      console.error('Follow error:', error)
    }
  }

  // Group notifications by time
  const now = new Date()
  const today: NotificationType[] = []
  const thisWeek: NotificationType[] = []
  const earlier: NotificationType[] = []

  notifications.forEach(n => {
    const diff = now.getTime() - new Date(n.createdAt).getTime()
    const days = diff / (1000 * 60 * 60 * 24)
    
    if (days < 1) {
      today.push(n)
    } else if (days < 7) {
      thisWeek.push(n)
    } else {
      earlier.push(n)
    }
  })

  const renderNotification = (n: NotificationType) => {
    const isFollowingUser = following.has(n.fromUser?.id || '') || n.isFollowing
    
    return (
      <div key={n.id} className={`flex items-center gap-3 p-4 ${n.isRead ? '' : isDark ? 'bg-zinc-900/50' : 'bg-zinc-50'}`}>
        <button 
          onClick={() => n.fromUser && onUserClick(n.fromUser)}
          className="flex-shrink-0"
        >
          <Avatar src={n.fromUser?.avatar} name={n.fromUser?.fullName} username={n.fromUser?.username} size="md" className="w-11 h-11 rounded-xl" />
        </button>
        
        <div className="flex-1 min-w-0">
          <p className="text-sm">
            <button 
              onClick={() => n.fromUser && onUserClick(n.fromUser)}
              className="font-semibold hover:underline"
            >
              {n.fromUser?.username}
            </button>
            {n.fromUser?.isVerified && <Icons.Verified />}
            <span className={isDark ? 'text-zinc-300' : 'text-zinc-600'}> {n.content}</span>
          </p>
          <span className="text-xs text-zinc-500">{timeAgo(n.createdAt)}</span>
        </div>
        
        {/* Right side - follow button or post thumbnail */}
        {n.type === 'follow' && n.fromUser && (
          <button
            onClick={() => isFollowingUser ? null : handleFollow(n.fromUser!.id)}
            className={`px-4 py-1.5 rounded-lg text-sm font-semibold ${
              isFollowingUser 
                ? isDark ? 'bg-zinc-800 text-white' : 'bg-zinc-200 text-black'
                : 'bg-[#4CAF50] text-white hover:bg-[#4CAF50]'
            }`}
          >
            {isFollowingUser ? 'Following' : 'Follow Back'}
          </button>
        )}
        
        {n.type === 'like' && n.post?.images?.[0] && (
          <img 
            src={n.post.images[0].url}
            alt=""
            className="w-11 h-11 object-cover rounded"
          />
        )}
        
        {n.type === 'comment' && n.post?.images?.[0] && (
          <img 
            src={n.post.images[0].url}
            alt=""
            className="w-11 h-11 object-cover rounded"
          />
        )}
      </div>
    )
  }

  return (
    <div className={`pb-16 min-h-screen ${isDark ? 'bg-black text-white' : 'bg-white text-black'}`}>
      {/* Header */}
      <div className={`sticky top-0 z-20 border-b ${isDark ? 'bg-black border-zinc-800' : 'bg-white border-zinc-200'}`}>
        <h1 className="text-lg font-semibold p-4">Notifications</h1>
      </div>

      {/* Tabs */}
      <div className={`flex border-b ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
        <button 
          onClick={() => setActiveTab('you')}
          className={`flex-1 py-3 text-sm font-semibold relative ${
            activeTab === 'you' 
              ? isDark ? 'text-white' : 'text-black' 
              : 'text-zinc-500'
          }`}
        >
          You
          {activeTab === 'you' && (
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-10 h-0.5 bg-white rounded-full" />
          )}
        </button>
        <button 
          onClick={() => setActiveTab('activity')}
          className={`flex-1 py-3 text-sm font-semibold relative ${
            activeTab === 'activity' 
              ? isDark ? 'text-white' : 'text-black' 
              : 'text-zinc-500'
          }`}
        >
          Following
          {activeTab === 'activity' && (
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-10 h-0.5 bg-white rounded-full" />
          )}
        </button>
      </div>
      
      {/* Notifications List */}
      {activeTab === 'you' && (
        <>
          {today.length > 0 && (
            <div>
              <h2 className="px-4 py-2 text-sm font-semibold text-zinc-500">Today</h2>
              <div className={`divide-y ${isDark ? 'divide-zinc-800' : 'divide-zinc-200'}`}>
                {today.map(renderNotification)}
              </div>
            </div>
          )}
          
          {thisWeek.length > 0 && (
            <div>
              <h2 className="px-4 py-2 text-sm font-semibold text-zinc-500">This Week</h2>
              <div className={`divide-y ${isDark ? 'divide-zinc-800' : 'divide-zinc-200'}`}>
                {thisWeek.map(renderNotification)}
              </div>
            </div>
          )}
          
          {earlier.length > 0 && (
            <div>
              <h2 className="px-4 py-2 text-sm font-semibold text-zinc-500">Earlier</h2>
              <div className={`divide-y ${isDark ? 'divide-zinc-800' : 'divide-zinc-200'}`}>
                {earlier.map(renderNotification)}
              </div>
            </div>
          )}
          
          {notifications.length === 0 && (
            <div className="p-8 text-center text-zinc-500">
              <div className={`w-16 h-16 rounded-full mx-auto flex items-center justify-center mb-4 ${isDark ? 'bg-zinc-800' : 'bg-zinc-200'}`}>
                <Icons.Heart filled />
              </div>
              <p className="text-lg">No notifications yet</p>
              <p className="text-sm mt-1">When someone likes or comments on your posts, you'll see it here.</p>
            </div>
          )}
        </>
      )}

      {activeTab === 'activity' && (
        <div className="p-8 text-center text-zinc-500">
          <p>Activity from people you follow will appear here</p>
        </div>
      )}
    </div>
  )
}

// ============ TIME AGO UTILITY ============
function timeAgo(date: Date): string {
  const seconds = Math.floor((new Date().getTime() - new Date(date).getTime()) / 1000)
  
  if (seconds < 60) return 'now'
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m`
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`
  if (seconds < 604800) return `${Math.floor(seconds / 86400)}d`
  return new Date(date).toLocaleDateString()
}

// ============ MESSAGES PAGE ============
interface ConversationType {
  id: string
  user?: {
    id: string
    username: string
    fullName?: string
    avatar?: string
    isVerified?: boolean
  }
  lastMessage?: {
    id: string
    content: string
    imageUrl?: string
    senderId: string
    sender?: { id: string; username: string }
    createdAt: Date
    isRead: boolean
  }
  unreadCount: number
  updatedAt: Date
}

interface MessageType {
  id: string
  content: string
  imageUrl?: string
  isRead: boolean
  createdAt: Date
  senderId: string
  sender: {
    id: string
    username: string
    avatar?: string
  }
}

function MessagesPage({ onUserClick, initialConversationId, initialUser, onConversationOpened }: { 
  onUserClick: (user: any) => void
  initialConversationId?: string | null
  initialUser?: any
  onConversationOpened?: () => void
}) {
  const { currentUser, theme } = useInstagramStore()
  const isDark = theme === 'dark'
  const [conversations, setConversations] = useState<ConversationType[]>([])
  const [selectedConversation, setSelectedConversation] = useState<string | null>(initialConversationId || null)
  const [selectedUser, setSelectedUser] = useState<any>(initialUser || null)
  const [messages, setMessages] = useState<MessageType[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState<any[]>([])
  const [showNewMessage, setShowNewMessage] = useState(false)
  const [messageImage, setMessageImage] = useState<string | null>(null)
  const [seenMessageIds, setSeenMessageIds] = useState<Set<string>>(new Set())
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  
  // Clear initial props after they're used
  useEffect(() => {
    if (initialConversationId && onConversationOpened) {
      onConversationOpened()
    }
  }, [initialConversationId, onConversationOpened])

  // Format time helper
  const formatMessageTime = (date: string | Date) => {
    const d = typeof date === 'string' ? new Date(date) : date
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  }

  // Load conversations
  useEffect(() => {
    fetch('/api/messages')
      .then(r => r.json())
      .then(data => setConversations(data.conversations || []))
      .catch(console.error)
  }, [])

  // Search users for new message
  useEffect(() => {
    if (!searchQuery.trim()) return
    const timeout = setTimeout(async () => {
      const res = await fetch(`/api/users/search?q=${encodeURIComponent(searchQuery)}`)
      const data = await res.json()
      setSearchResults(data.users || [])
    }, 300)
    return () => clearTimeout(timeout)
  }, [searchQuery])

  // Load messages when conversation selected
  useEffect(() => {
    if (!selectedConversation) return
    fetch(`/api/messages/${selectedConversation}`)
      .then(r => r.json())
      .then(data => {
        setMessages(data.messages || [])
        setSelectedUser(data.otherUser)
        // Mark as seen
        const unreadIds = (data.messages || [])
          .filter((m: MessageType) => m && m.senderId !== currentUser?.id && !m.isRead)
          .map((m: MessageType) => m.id)
        setSeenMessageIds(prev => new Set([...prev, ...unreadIds]))
      })
      .catch(console.error)
  }, [selectedConversation, currentUser])

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  // Poll for new messages
  useEffect(() => {
    if (!selectedConversation) return
    const interval = setInterval(() => {
      fetch(`/api/messages/${selectedConversation}`)
        .then(r => r.json())
        .then(data => setMessages(data.messages || []))
        .catch(console.error)
    }, 5000)
    return () => clearInterval(interval)
  }, [selectedConversation])

  const handleStartConversation = async (user: any) => {
    const res = await fetch('/api/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: user.id })
    })
    const data = await res.json()
    setSelectedConversation(data.conversationId)
    setSelectedUser(user)
    setShowNewMessage(false)
    setSearchQuery('')
    setSearchResults([])
    const convRes = await fetch('/api/messages')
    const convData = await convRes.json()
    setConversations(convData.conversations || [])
  }

  const handleSendMessage = async () => {
    if ((!newMessage.trim() && !messageImage) || !selectedConversation) return
    const content = newMessage
    setNewMessage('')
    setMessageImage(null)
    try {
      const res = await fetch(`/api/messages/${selectedConversation}/send`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content, imageUrl: messageImage })
      })
      const data = await res.json()
      if (data.message) {
        setMessages(prev => [...prev, data.message])
        setConversations(prev => 
          prev.map(c => 
            c.id === selectedConversation 
              ? { ...c, lastMessage: data.message, updatedAt: new Date() }
              : c
          ).sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
        )
      }
    } catch (error) {
      console.error('Send message error:', error)
    }
  }

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const formData = new FormData()
    formData.append('file', file)
    try {
      const res = await fetch('/api/upload/image', { method: 'POST', body: formData })
      const data = await res.json()
      if (data.url) setMessageImage(data.url)
    } catch (error) {
      console.error('Upload error:', error)
    }
  }

  // Chat view - Modern Expressive Style
  if (selectedConversation && selectedUser) {
    return (
      <div className={`fixed inset-0 z-40 flex flex-col ${isDark ? 'bg-black' : 'bg-white'}`}>
        {/* Chat Header */}
        <div className={`flex items-center px-4 py-3 ${isDark ? 'bg-black' : 'bg-white'} border-b ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
          <button onClick={() => { setSelectedConversation(null); setSelectedUser(null); setMessages([]) }} className="p-1">
            <svg viewBox="0 0 24 24" fill="none" className={`w-6 h-6 ${isDark ? 'text-white' : 'text-black'}`}>
              <path d="M15 19l-7-7 7-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
          <div className="flex items-center gap-3 flex-1 ml-2">
            <div className="relative">
              <Avatar src={selectedUser.avatar} name={selectedUser.fullName} username={selectedUser.username} size="sm" className="w-10 h-10 rounded-xl" />
              <div className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-green-500 rounded-full border-2 ${isDark ? 'border-black' : 'border-white'}`} />
            </div>
            <div>
              <div className={`font-semibold flex items-center gap-1 ${isDark ? 'text-white' : 'text-black'}`}>
                {selectedUser.username}
                {selectedUser.isVerified && <Icons.Verified />}
              </div>
              <div className="text-xs text-green-500">Online</div>
            </div>
          </div>
          <button className="p-2">
            <svg viewBox="0 0 24 24" fill="none" className={`w-6 h-6 ${isDark ? 'text-white' : 'text-black'}`}>
              <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
          <button className="p-2">
            <svg viewBox="0 0 24 24" fill="none" className={`w-6 h-6 ${isDark ? 'text-white' : 'text-black'}`}>
              <path d="M23 7l-7 5 7 5V7z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              <rect x="1" y="5" width="15" height="14" rx="2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        </div>

        {/* Messages Area */}
        <div className={`flex-1 overflow-y-auto px-4 py-4 ${isDark ? 'bg-black' : 'bg-white'}`}>
          {messages.filter(msg => msg && msg.senderId).map((msg, index) => {
            const isOwn = msg.senderId === currentUser?.id
            const showTime = index === 0 || new Date(msg.createdAt).getTime() - new Date(messages[index - 1]?.createdAt).getTime() > 300000
            const isSeen = isOwn && (seenMessageIds.has(msg.id) || msg.isRead)

            return (
              <div key={msg.id} className="relative">
                {showTime && (
                  <div className="flex justify-center my-4">
                    <span className={`text-xs ${isDark ? 'text-zinc-500' : 'text-zinc-400'}`}>{formatMessageTime(msg.createdAt)}</span>
                  </div>
                )}

                <div className={`flex mb-2 ${isOwn ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[75%] ${isOwn ? 'bg-[#4CAF50]' : isDark ? 'bg-zinc-800' : 'bg-zinc-200'} rounded-2xl px-4 py-2.5 ${isOwn ? 'rounded-br-md' : 'rounded-bl-md'}`}>
                    {msg.imageUrl && (
                      <img src={msg.imageUrl} alt="" className="rounded-xl mb-2 max-w-[200px] max-h-[200px] object-cover" />
                    )}
                    {msg.content && (
                      <p className={`text-[15px] leading-relaxed ${isOwn ? 'text-white' : isDark ? 'text-white' : 'text-black'}`}>{msg.content}</p>
                    )}
                    <div className="flex items-center justify-end gap-1 mt-1">
                      <span className={`text-[10px] ${isOwn ? 'text-white/60' : isDark ? 'text-white/60' : 'text-black/60'}`}>{formatMessageTime(msg.createdAt)}</span>
                      {isOwn && (
                        isSeen ? (
                          <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 text-[#4CAF50]" fill="currentColor">
                            <path d="M18 7l-1.41-1.41-6.34 6.34 1.41 1.41L18 7zm4.24-1.41L11.66 16.17 7.48 12l-1.41 1.41L11.66 19l12-12-1.42-1.41zM.41 13.41L6 19l1.41-1.41L1.83 12 .41 13.41z"/>
                          </svg>
                        ) : (
                          <svg viewBox="0 0 24 24" className={`w-3.5 h-3.5 ${isOwn ? 'text-white/60' : isDark ? 'text-white/60' : 'text-black/60'}`} fill="currentColor">
                            <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/>
                          </svg>
                        )
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Image preview */}
        {messageImage && (
          <div className={`px-4 py-2 border-t ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
            <div className="relative inline-block">
              <img src={messageImage} alt="Preview" className="w-20 h-20 object-cover rounded-lg" />
              <button onClick={() => setMessageImage(null)} className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center">
                <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>
        )}

        {/* Message Input */}
        <div className={`px-4 py-3 ${isDark ? 'bg-black border-zinc-900' : 'bg-white border-zinc-100'} border-t`}>
          <div className="flex items-end gap-2">
            <button onClick={() => fileInputRef.current?.click()} className={`p-2 ${isDark ? 'text-zinc-400 hover:text-white' : 'text-zinc-500 hover:text-black'}`}>
              <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
                <rect x="3" y="3" width="18" height="18" rx="2" stroke="currentColor" strokeWidth="1.5"/>
                <circle cx="8.5" cy="8.5" r="1.5" fill="currentColor"/>
                <path d="M21 15L16 10L5 21" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
            <input ref={fileInputRef} type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
            <div className={`flex-1 rounded-full px-4 py-2.5 ${isDark ? 'bg-zinc-800' : 'bg-zinc-100'}`}>
              <input
                type="text"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Message..."
                className={`w-full bg-transparent outline-none placeholder-zinc-500 text-[15px] ${isDark ? 'text-white' : 'text-black'}`}
                onKeyPress={(e) => { if (e.key === 'Enter') handleSendMessage() }}
              />
            </div>
            {newMessage.trim() || messageImage ? (
              <button onClick={handleSendMessage} className="p-2 text-[#4CAF50]">
                <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
                  <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
            ) : (
              <button className={`p-2 ${isDark ? 'text-zinc-400' : 'text-zinc-500'}`}>
                <svg viewBox="0 0 24 24" fill="none" className="w-6 h-6">
                  <path d="M12 1a3 3 0 00-3 3v8a3 3 0 006 0V4a3 3 0 00-3-3z" stroke="currentColor" strokeWidth="1.5"/>
                  <path d="M19 10v2a7 7 0 01-14 0v-2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <line x1="12" y1="19" x2="12" y2="23" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                  <line x1="8" y1="23" x2="16" y2="23" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
                </svg>
              </button>
            )}
          </div>
        </div>
      </div>
    )
  }

  // New message view
  if (showNewMessage) {
    return (
      <div className={`fixed inset-0 z-40 ${isDark ? 'bg-black' : 'bg-white'}`}>
        <div className={`flex items-center gap-4 p-4 border-b ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
          <button onClick={() => { setShowNewMessage(false); setSearchQuery(''); setSearchResults([]) }}>
            <Icons.Close />
          </button>
          <h1 className={`font-semibold ${isDark ? 'text-white' : 'text-black'}`}>New message</h1>
        </div>
        <div className="p-4">
          <div className={`flex items-center rounded-lg px-3 py-2 gap-2 ${isDark ? 'bg-zinc-800' : 'bg-zinc-100'}`}>
            <span className="text-zinc-500 text-sm">To:</span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search..."
              className={`flex-1 bg-transparent outline-none text-sm placeholder-zinc-500 ${isDark ? 'text-white' : 'text-black'}`}
              autoFocus
            />
          </div>
          <div className={`mt-4 divide-y ${isDark ? 'divide-zinc-800' : 'divide-zinc-200'}`}>
            {searchResults.map(user => (
              <button key={user.id} onClick={() => handleStartConversation(user)} className="w-full flex items-center gap-3 p-4">
                <Avatar src={user.avatar} name={user.fullName} username={user.username} size="md" className="w-11 h-11 rounded-xl" />
                <div className="text-left">
                  <div className={`font-semibold text-sm flex items-center gap-1 ${isDark ? 'text-white' : 'text-black'}`}>
                    {user.username}
                    {user.isVerified && <Icons.Verified />}
                  </div>
                  <div className="text-zinc-500 text-xs">{user.fullName}</div>
                </div>
              </button>
            ))}
            {searchQuery && searchResults.length === 0 && (
              <div className="p-8 text-center text-zinc-500">No users found</div>
            )}
          </div>
        </div>
      </div>
    )
  }

  // Conversation list view
  return (
    <div className={`pb-16 min-h-screen ${isDark ? 'bg-black text-white' : 'bg-white text-black'}`}>
      <div className={`sticky top-0 z-20 border-b ${isDark ? 'border-zinc-800 bg-black' : 'border-zinc-200 bg-white'}`}>
        <div className="flex items-center justify-between p-4">
          <h1 className="text-lg font-semibold">{currentUser?.username}</h1>
          <button onClick={() => setShowNewMessage(true)}>
            <svg viewBox="0 0 24 24" fill="none" className={`w-6 h-6 ${isDark ? 'text-white' : 'text-black'}`}>
              <path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
        </div>
      </div>
      <div className={`p-4 border-b ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
        <div className="flex items-center justify-between mb-4">
          <span className="font-semibold">Messages</span>
          <span className="text-sm text-zinc-500">Requests</span>
        </div>
      </div>
      <div className={`divide-y ${isDark ? 'divide-zinc-800' : 'divide-zinc-200'}`}>
        {conversations.map(conv => (
          <button
            key={conv.id}
            onClick={() => { setSelectedConversation(conv.id); setSelectedUser(conv.user) }}
            className={`w-full flex items-center gap-3 p-4 ${isDark ? 'hover:bg-zinc-900' : 'hover:bg-zinc-50'}`}
          >
            <Avatar src={conv.user?.avatar} name={conv.user?.fullName} username={conv.user?.username} size="lg" className="w-14 h-14 rounded-xl" />
            <div className="flex-1 min-w-0 text-left">
              <div className={`font-semibold text-sm flex items-center gap-1 ${isDark ? 'text-white' : 'text-black'}`}>
                {conv.user?.username}
                {conv.user?.isVerified && <Icons.Verified />}
              </div>
              <p className="text-sm text-zinc-500 truncate">
                {conv.lastMessage?.content || 'No messages yet'}
                <span className="ml-1">· {timeAgo(conv.lastMessage?.createdAt || conv.updatedAt)}</span>
              </p>
            </div>
            {conv.unreadCount > 0 && <div className="w-2 h-2 rounded-full bg-[#4CAF50]" />}
          </button>
        ))}
        {conversations.length === 0 && (
          <div className="p-8 text-center text-zinc-500">
            <Icons.Messenger />
            <p className="mt-4 text-lg">No messages yet</p>
            <p className="text-sm mt-1">Start a conversation with someone.</p>
          </div>
        )}
      </div>
    </div>
  )
}

// ============ EXPLORE PAGE ============
function ExplorePage() {
  const [posts, setPosts] = useState<Post[]>([])
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'

  useEffect(() => {
    fetch('/api/posts/feed')
      .then(r => r.json())
      .then(data => setPosts(data.posts || []))
      .catch(console.error)
  }, [])

  return (
    <div className="pb-16">
      <div className="grid grid-cols-3 gap-0.5">
        {posts.map(post => (
          <div key={post.id} className={`aspect-square relative ${isDark ? 'bg-zinc-900' : 'bg-zinc-100'}`}>
            <img 
              src={post.images[0]?.url} 
              alt=""
              className="w-full h-full object-cover"
            />
          </div>
        ))}
      </div>
    </div>
  )
}

// ============ REELS PAGE ============
function ReelsPage() {
  const [posts, setPosts] = useState<Post[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const { theme } = useInstagramStore()
  const isDark = theme === 'dark'

  useEffect(() => {
    fetch('/api/posts/feed')
      .then(r => r.json())
      .then(data => setPosts(data.posts || []))
      .catch(console.error)
  }, [])

  if (posts.length === 0) {
    return (
      <div className="h-screen flex items-center justify-center text-zinc-500">
        No reels yet
      </div>
    )
  }

  const post = posts[currentIndex]

  return (
    <div className={`h-screen relative overflow-hidden ${isDark ? 'bg-black' : 'bg-white'}`}>
      {/* Reel content */}
      <div 
        className="absolute inset-0"
        onTouchStart={(e) => {
          const touch = e.touches[0]
          const startY = touch.clientY
          const handleTouchEnd = (e: TouchEvent) => {
            const endY = e.changedTouches[0].clientY
            if (startY - endY > 50 && currentIndex < posts.length - 1) {
              setCurrentIndex(i => i + 1)
            } else if (endY - startY > 50 && currentIndex > 0) {
              setCurrentIndex(i => i - 1)
            }
            window.removeEventListener('touchend', handleTouchEnd)
          }
          window.addEventListener('touchend', handleTouchEnd)
        }}
      >
        <img 
          src={post.images[0]?.url} 
          alt=""
          className="w-full h-full object-cover"
        />
        
        {/* Overlay gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        
        {/* Right side actions */}
        <div className="absolute right-3 bottom-24 flex flex-col items-center gap-5">
          <button className="flex flex-col items-center gap-1">
            <Icons.Heart />
            <span className="text-xs text-white">{post.likes.length}</span>
          </button>
          <button className="flex flex-col items-center gap-1">
            <Icons.Comment />
            <span className="text-xs text-white">{post.comments?.length || 0}</span>
          </button>
          <button className="flex flex-col items-center gap-1">
            <Icons.Share />
          </button>
          <button className="flex flex-col items-center gap-1">
            <Icons.Bookmark />
          </button>
        </div>
        
        {/* Bottom info */}
        <div className="absolute bottom-20 left-3 right-16">
          <div className="flex items-center gap-2 mb-2">
            <Avatar src={post.author.avatar} name={post.author.fullName} username={post.author.username} size="sm" className="w-8 h-8 rounded-xl" />
            <span className="font-semibold text-sm text-white">{post.author.username}</span>
            <button className="px-3 py-1 border border-white rounded text-xs text-white">Follow</button>
          </div>
          {post.caption && (
            <p className="text-sm text-white line-clamp-2">{post.caption}</p>
          )}
        </div>
      </div>
    </div>
  )
}

// ============ MAIN APP ============
export default function HeyApp() {
  const {
    currentUser,
    isAuthenticated,
    authLoading,
    setCurrentUser,
    setAuthLoading,
    currentTab,
    setCurrentTab,
    selectedStoryUserId,
    setSelectedStoryUserId,
    viewingUserProfile,
    setViewingUserProfile,
    isCreatePostOpen,
    setCreatePostOpen,
    theme,
  } = useInstagramStore()

  const [posts, setPosts] = useState<Post[]>([])
  const [stories, setStories] = useState<{ author: User; stories: (Story & { viewed: boolean })[] }[]>([])
  const [loading, setLoading] = useState(true)
  const [showSettings, setShowSettings] = useState(false)
  const [showAdminPanel, setShowAdminPanel] = useState(false)
  const [showCreateStory, setShowCreateStory] = useState(false)
  const [selectedStories, setSelectedStories] = useState<Story[]>([])
  const [feedTab, setFeedTab] = useState<'following' | 'forYou'>('forYou')
  
  // Setup flow for new users
  const [setupStep, setSetupStep] = useState<'none' | 'avatar' | 'username'>('none')
  const [newUser, setNewUser] = useState<User | null>(null)
  
  // Direct message - initial conversation to open
  const [initialConversationId, setInitialConversationId] = useState<string | null>(null)
  const [initialConversationUser, setInitialConversationUser] = useState<any>(null)
  
  // Hide header on scroll
  const [headerVisible, setHeaderVisible] = useState(true)
  const lastScrollY = useRef(0)
  const scrollContainerRef = useRef<HTMLDivElement>(null)
  
  // Pull to refresh
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [pullDistance, setPullDistance] = useState(0)
  const touchStartY = useRef(0)
  const isPulling = useRef(false)
  
  // Unread counts for notifications and messages
  const [unreadNotifications, setUnreadNotifications] = useState(0)
  const [unreadMessages, setUnreadMessages] = useState(0)
  
  const isDark = theme === 'dark'

  // Fetch unread counts
  const fetchUnreadCounts = useCallback(async () => {
    if (!isAuthenticated) return
    try {
      const res = await fetch('/api/unread-counts')
      const data = await res.json()
      setUnreadNotifications(data.notifications || 0)
      setUnreadMessages(data.messages || 0)
    } catch (error) {
      console.error('Fetch unread counts error:', error)
    }
  }, [isAuthenticated])

  // Check auth on mount
  useEffect(() => {
    fetch('/api/auth/me')
      .then(r => r.json())
      .then(data => {
        if (data.user) {
          setCurrentUser(data.user)
        } else {
          setAuthLoading(false)
        }
      })
      .catch(() => {
        setAuthLoading(false)
      })
  }, [setCurrentUser, setAuthLoading])

  // Poll for unread counts every 10 seconds
  useEffect(() => {
    if (!isAuthenticated) return
    
    fetchUnreadCounts()
    
    const interval = setInterval(fetchUnreadCounts, 10000)
    return () => clearInterval(interval)
  }, [isAuthenticated, fetchUnreadCounts])

  // Fetch feed data when authenticated
  useEffect(() => {
    if (!isAuthenticated) return

    const fetchData = async () => {
      setLoading(true)
      try {
        const [feedRes, storiesRes] = await Promise.all([
          fetch(`/api/posts/feed?type=${feedTab}`).then(r => r.json()),
          fetch('/api/stories').then(r => r.json()),
        ])
        setPosts(feedRes.posts || [])
        setStories(storiesRes.stories || [])
      } catch (error) {
        console.error('Fetch error:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [isAuthenticated, feedTab])

  // Hide header on scroll
  useEffect(() => {
    if (currentTab !== 'home') return
    
    const handleScroll = () => {
      const currentScrollY = window.scrollY
      
      if (currentScrollY < 10) {
        // At the top, always show header
        setHeaderVisible(true)
      } else if (currentScrollY > lastScrollY.current && currentScrollY > 60) {
        // Scrolling down & past header height, hide header
        setHeaderVisible(false)
      } else if (currentScrollY < lastScrollY.current) {
        // Scrolling up, show header
        setHeaderVisible(true)
      }
      
      lastScrollY.current = currentScrollY
    }
    
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [currentTab])

  const handleAuth = useCallback(async (user?: any, isNewUser?: boolean) => {
    if (user) {
      if (isNewUser) {
        // New user - start setup flow
        setNewUser(user)
        setSetupStep('avatar')
      } else {
        // Existing user - go directly to feed
        setCurrentUser(user)
      }
    } else {
      // Fallback: fetch from /api/auth/me
      const res = await fetch('/api/auth/me')
      const data = await res.json()
      if (data.user) {
        setCurrentUser(data.user)
      }
    }
  }, [setCurrentUser])

  const handleAvatarComplete = useCallback((user: User) => {
    setNewUser(user)
    setSetupStep('username')
  }, [])

  const handleUsernameComplete = useCallback((user: User) => {
    setCurrentUser(user)
    setSetupStep('none')
    setNewUser(null)
  }, [setCurrentUser])

  const handleLogout = useCallback(async () => {
    await fetch('/api/auth/logout', { method: 'POST' })
    setCurrentUser(null)
    setShowSettings(false)
  }, [setCurrentUser])

  const handleLike = useCallback(async (postId: string) => {
    const res = await fetch(`/api/posts/${postId}/like`, { method: 'POST' })
    const data = await res.json()
    setPosts(prev => prev.map(p => 
      p.id === postId 
        ? { ...p, likes: data.isLiked ? [...p.likes, { userId: currentUser?.id || '' }] : p.likes.filter(l => l.userId !== currentUser?.id) }
        : p
    ))
  }, [currentUser?.id])

  const handleSave = useCallback(async (postId: string) => {
    const res = await fetch(`/api/posts/${postId}/save`, { method: 'POST' })
    const data = await res.json()
    setPosts(prev => prev.map(p => 
      p.id === postId 
        ? { ...p, isSaved: data.isSaved }
        : p
    ))
  }, [])

  const handleUserClick = useCallback(async (user: User) => {
    const res = await fetch(`/api/users/${user.id}`)
    const data = await res.json()
    if (data.user) {
      setViewingUserProfile(data.user)
    }
  }, [setViewingUserProfile])

  const handleMessageUser = useCallback(async (user: User) => {
    // Start or open conversation with user
    try {
      const res = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id })
      })
      const data = await res.json()
      if (data.conversationId) {
        // Set initial conversation to open and navigate to messages tab
        setInitialConversationId(data.conversationId)
        setInitialConversationUser(user)
        setCurrentTab('messages')
        setViewingUserProfile(null)
      }
    } catch (error) {
      console.error('Error starting conversation:', error)
    }
  }, [setCurrentTab, setViewingUserProfile])

  // Helper to handle message button - go directly to inbox
  const handleGoToInbox = useCallback(() => {
    setCurrentTab('messages')
    setViewingUserProfile(null)
  }, [setCurrentTab, setViewingUserProfile])

  const handleStoryClick = useCallback(async (userId: string) => {
    if (userId === currentUser?.id) {
      setShowCreateStory(true)
    } else {
      const res = await fetch(`/api/stories/user/${userId}`)
      const data = await res.json()
      if (data.stories && data.stories.length > 0) {
        setSelectedStories(data.stories)
      }
    }
  }, [currentUser?.id])

  const refreshFeed = useCallback(async () => {
    const [feedRes, storiesRes] = await Promise.all([
      fetch(`/api/posts/feed?type=${feedTab}`).then(r => r.json()),
      fetch('/api/stories').then(r => r.json()),
    ])
    setPosts(feedRes.posts || [])
    setStories(storiesRes.stories || [])
  }, [feedTab])

  // Pull to refresh handlers
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (currentTab !== 'home' || window.scrollY > 0) return
    touchStartY.current = e.touches[0].clientY
    isPulling.current = true
  }, [currentTab])

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!isPulling.current || isRefreshing || currentTab !== 'home') return
    
    const currentY = e.touches[0].clientY
    const diff = currentY - touchStartY.current
    
    if (diff > 0 && window.scrollY <= 0) {
      const distance = Math.min(diff * 0.5, 100)
      setPullDistance(distance)
    } else {
      setPullDistance(0)
      isPulling.current = false
    }
  }, [isRefreshing, currentTab])

  const handleTouchEnd = useCallback(async () => {
    if (!isPulling.current || isRefreshing) return
    
    isPulling.current = false
    
    if (pullDistance >= 60) {
      setIsRefreshing(true)
      setPullDistance(0)
      await refreshFeed()
      setIsRefreshing(false)
    } else {
      setPullDistance(0)
    }
  }, [pullDistance, isRefreshing, refreshFeed])

  const handlePullToRefresh = useCallback(async () => {
    if (isRefreshing) return
    setIsRefreshing(true)
    await refreshFeed()
    setIsRefreshing(false)
  }, [isRefreshing, refreshFeed])

  // Show loading while checking auth status
  if (authLoading) {
    return (
      <div className={`min-h-screen flex items-center justify-center ${isDark ? 'bg-black' : 'bg-white'}`}>
        <div className="flex flex-col items-center gap-4">
          <Icons.LogoAuth />
          <div className="w-8 h-8 border-2 border-t-transparent border-[#4CAF50] rounded-full animate-spin" />
        </div>
      </div>
    )
  }

  // Not authenticated - show login
  if (!isAuthenticated) {
    // Show setup flow for new users
    if (setupStep === 'avatar' && newUser) {
      return <ProfilePictureSetup user={newUser} onComplete={handleAvatarComplete} />
    }
    if (setupStep === 'username' && newUser) {
      return <UsernameSetup user={newUser} onComplete={handleUsernameComplete} />
    }
    return <AuthScreen onAuth={handleAuth} />
  }

  // Show admin panel
  if (showAdminPanel) {
    return (
      <AdminPanel onBack={() => setShowAdminPanel(false)} />
    )
  }

  // Show settings page
  if (showSettings && currentUser) {
    return (
      <SettingsPage
        user={currentUser}
        onBack={() => setShowSettings(false)}
        onLogout={handleLogout}
        onUpdated={(user) => setCurrentUser(user)}
        onAdminClick={() => setShowAdminPanel(true)}
      />
    )
  }

  // Show user profile (with bottom navigation)
  if (viewingUserProfile) {
    return (
      <div ref={scrollContainerRef} className={`min-h-screen max-w-lg mx-auto relative ${isDark ? 'bg-black text-white' : 'bg-white text-black'}`}>
        <ProfilePage
          user={viewingUserProfile}
          isOwnProfile={viewingUserProfile.id === currentUser?.id}
          currentUserId={currentUser?.id}
          onBack={() => setViewingUserProfile(null)}
          onSettings={() => setShowSettings(true)}
          onUserClick={handleUserClick}
          onMessage={handleMessageUser}
        />
        
        {/* Bottom Navigation */}
        <nav className={`fixed bottom-0 left-0 right-0 border-t max-w-lg mx-auto z-50 ${isDark ? 'bg-black border-zinc-800' : 'bg-white border-zinc-200'}`}>
          <div className="flex justify-around items-center py-2">
            <button onClick={() => { setCurrentTab('home'); setViewingUserProfile(null) }} className="p-2">
              <Icons.Home filled={false} />
            </button>
            <button onClick={() => { setCurrentTab('search'); setViewingUserProfile(null) }} className="p-2">
              <Icons.Search filled={false} />
            </button>
            <button onClick={() => setCreatePostOpen(true)} className="p-2">
              <Icons.Plus />
            </button>
            <button onClick={() => { setCurrentTab('notifications'); setViewingUserProfile(null) }} className="p-2 relative">
              <Icons.Heart filled={false} />
              {unreadNotifications > 0 && (
                <span className="absolute top-0 right-0 bg-red-500 text-white text-[10px] font-bold rounded-full min-w-[18px] h-[18px] flex items-center justify-center px-1">
                  {unreadNotifications > 99 ? '99+' : unreadNotifications}
                </span>
              )}
            </button>
            <button onClick={() => { setCurrentTab('profile'); setViewingUserProfile(null) }} className="p-2">
              <Icons.User filled={viewingUserProfile.id === currentUser?.id} />
            </button>
          </div>
        </nav>
      </div>
    )
  }

  return (
    <div ref={scrollContainerRef} className={`min-h-screen max-w-lg mx-auto relative ${isDark ? 'bg-black text-white' : 'bg-white text-black'}`}>
      {/* Header - Hide on scroll */}
      {currentTab === 'home' && (
        <header 
          className={`sticky top-0 z-30 transition-transform duration-300 ${isDark ? 'bg-black' : 'bg-white'} ${
            headerVisible ? 'translate-y-0' : '-translate-y-full'
          }`}
        >
          <div className="flex items-center justify-between p-4">
            <div className="w-10" /> {/* Spacer for centering */}
            <div className="flex-1 flex justify-center">
              <Icons.LogoThemed isDark={isDark} />
            </div>
            <div className="w-10 flex items-center justify-end relative">
              <button onClick={() => setCurrentTab('messages')} className="relative">
                <Icons.Messenger />
                {unreadMessages > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold rounded-full min-w-[18px] h-[18px] flex items-center justify-center px-1">
                    {unreadMessages > 99 ? '99+' : unreadMessages}
                  </span>
                )}
              </button>
            </div>
          </div>
        </header>
      )}

      {/* Main Content */}
      <main>
        {currentTab === 'home' && (
          <>
            {/* Feed Tabs - Always sticky at top */}
            <div className={`sticky top-0 z-20 border-b transition-all duration-300 ${isDark ? 'bg-black border-zinc-800' : 'bg-white border-zinc-200'} ${
              !headerVisible ? 'shadow-sm' : ''
            }`}>
              <div className="flex">
                <button 
                  onClick={() => setFeedTab('following')}
                  className={`flex-1 py-3 text-sm font-semibold relative ${
                    feedTab === 'following' 
                      ? isDark ? 'text-white' : 'text-black' 
                      : 'text-zinc-500'
                  }`}
                >
                  Following
                  {feedTab === 'following' && (
                    <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-12 h-1 bg-[#4CAF50] rounded-t-full" />
                  )}
                </button>
                <button 
                  onClick={() => setFeedTab('forYou')}
                  className={`flex-1 py-3 text-sm font-semibold relative ${
                    feedTab === 'forYou' 
                      ? isDark ? 'text-white' : 'text-black' 
                      : 'text-zinc-500'
                  }`}
                >
                  For you
                  {feedTab === 'forYou' && (
                    <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-12 h-1 bg-[#4CAF50] rounded-t-full" />
                  )}
                </button>
              </div>
            </div>

            {/* Stories (Instagram-style) */}
            <div className={`flex gap-4 overflow-x-auto px-4 py-3 scrollbar-hide ${isDark ? 'bg-black' : 'bg-white'}`}>
              {loading ? (
                // Stories skeleton
                <>
                  {[1, 2, 3, 4, 5].map(i => <SkeletonStory key={i} />)}
                </>
              ) : (
                <>
                  {currentUser && (
                    <StoryCard
                      user={currentUser}
                      hasStory={stories.some(s => s.author?.id === currentUser?.id)}
                      viewed={false}
                      isOwn={true}
                      storyCount={stories.find(s => s.author?.id === currentUser?.id)?.stories?.length}
                      onClick={() => {
                        const myStories = stories.find(s => s.author?.id === currentUser?.id)
                        if (myStories?.stories) {
                          setSelectedStories(myStories.stories)
                        }
                      }}
                      onCreate={() => setShowCreateStory(true)}
                    />
                  )}
                  {stories.filter(s => s.author && s.author.id !== currentUser?.id).map((storyGroup) => (
                    <StoryCard
                      key={storyGroup.author.id}
                      user={storyGroup.author}
                      hasStory={true}
                      viewed={storyGroup.stories?.every(s => s.viewed) || false}
                      storyCount={storyGroup.stories?.length || 0}
                      onClick={() => storyGroup.stories && setSelectedStories(storyGroup.stories)}
                    />
                  ))}
                </>
              )}
            </div>

            {/* Feed */}
            {loading ? (
              // Posts skeleton
              <>
                {[1, 2, 3].map(i => <SkeletonPostCard key={i} />)}
              </>
            ) : (
              <>
                {posts.map(post => (
                  post.images && post.images.length > 0 ? (
                    <PostCard
                      key={post.id}
                      post={post}
                      currentUserId={currentUser?.id}
                      onLike={() => handleLike(post.id)}
                      onComment={() => {}}
                      onSave={() => handleSave(post.id)}
                      onUserClick={() => handleUserClick(post.author)}
                    />
                  ) : (
                    <TextPostCard
                      key={post.id}
                      post={post}
                      currentUserId={currentUser?.id}
                      onLike={() => handleLike(post.id)}
                      onComment={() => {}}
                      onUserClick={() => handleUserClick(post.author)}
                    />
                  )
                ))}

                {posts.length === 0 && (
                  <div className="text-center py-16 text-zinc-500">
                    <p className="text-lg mb-2">No posts yet</p>
                    <p className="text-sm">Follow some users to see their posts here</p>
                  </div>
                )}
              </>
            )}
          </>
        )}

        {currentTab === 'search' && (
          <SearchPage onUserClick={handleUserClick} />
        )}

        {currentTab === 'notifications' && (
          <NotificationsPage onUserClick={handleUserClick} />
        )}

        {currentTab === 'explore' && (
          <ExplorePage />
        )}

        {currentTab === 'reels' && (
          <ReelsPage />
        )}

        {currentTab === 'messages' && (
          <MessagesPage 
            onUserClick={handleUserClick} 
            initialConversationId={initialConversationId}
            initialUser={initialConversationUser}
            onConversationOpened={() => {
              setInitialConversationId(null)
              setInitialConversationUser(null)
            }}
          />
        )}

        {currentTab === 'profile' && currentUser && (
          <ProfilePage
            user={currentUser}
            isOwnProfile={true}
            currentUserId={currentUser.id}
            onBack={() => {}}
            onSettings={() => setShowSettings(true)}
            onUserClick={handleUserClick}
            onMessage={handleMessageUser}
          />
        )}
      </main>

      {/* Bottom Navigation */}
      <nav className={`fixed bottom-0 left-0 right-0 border-t max-w-lg mx-auto ${isDark ? 'bg-black border-zinc-800' : 'bg-white border-zinc-200'}`}>
        <div className="flex justify-around items-center py-2">
          <button onClick={() => setCurrentTab('home')} className="p-2">
            <Icons.Home filled={currentTab === 'home'} />
          </button>
          <button onClick={() => setCurrentTab('search')} className="p-2">
            <Icons.Search filled={currentTab === 'search'} />
          </button>
          <button onClick={() => setCreatePostOpen(true)} className="p-2">
            <Icons.Plus />
          </button>
          <button onClick={() => { setCurrentTab('notifications'); setUnreadNotifications(0); }} className="p-2 relative">
            <Icons.Heart filled={currentTab === 'notifications'} />
            {unreadNotifications > 0 && (
              <span className="absolute top-0 right-0 bg-red-500 text-white text-[10px] font-bold rounded-full min-w-[18px] h-[18px] flex items-center justify-center px-1">
                {unreadNotifications > 99 ? '99+' : unreadNotifications}
              </span>
            )}
          </button>
          <button onClick={() => setCurrentTab('profile')} className="p-2">
            <Icons.User filled={currentTab === 'profile'} />
          </button>
        </div>
      </nav>

      {/* Modals */}
      {isCreatePostOpen && (
        <CreatePostModal
          onClose={() => setCreatePostOpen(false)}
          onCreated={refreshFeed}
        />
      )}

      {showCreateStory && (
        <CreateStoryModal
          onClose={() => setShowCreateStory(false)}
          onCreated={refreshFeed}
        />
      )}

      {selectedStories.length > 0 && (
        <StoryViewer
          stories={selectedStories}
          onClose={() => setSelectedStories([])}
          onRefresh={refreshFeed}
        />
      )}
    </div>
  )
}
