import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

// Twitter-style Inter font
const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-twitter",
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: "hey - Connect & Share",
  description: "Connect with friends and share your moments on hey",
  icons: {
    icon: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 36 36'><defs><linearGradient id='g' x1='0%25' y1='100%25' x2='100%25' y2='0%25'><stop offset='0%25' stop-color='%232E7D32'/><stop offset='50%25' stop-color='%234CAF50'/><stop offset='100%25' stop-color='%2381C784'/></linearGradient></defs><path d='M18 3C9.72 3 3 9.26 3 17c0 3.78 1.65 7.2 4.32 9.66L6 33l7.02-3.36c1.58.46 3.26.72 4.98.72 8.28 0 15-6.26 15-14S26.28 3 18 3z' fill='url(%23g)'/><text x='12' y='22' fill='white' font-size='14' font-weight='bold'>h</text></svg>",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} font-sans antialiased bg-black text-white`}>
        {children}
      </body>
    </html>
  );
}
