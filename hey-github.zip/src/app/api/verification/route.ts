import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'

// Get verification status
export async function GET() {
  try {
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const requests = await db.verificationRequest.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      take: 1,
    })

    return NextResponse.json({ 
      isVerified: user.isVerified,
      request: requests[0] || null 
    })
  } catch (error) {
    console.error('Get verification error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// Submit verification request
export async function POST(request: Request) {
  try {
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Check if user is already verified
    if (user.isVerified) {
      return NextResponse.json({ error: 'Already verified' }, { status: 400 })
    }

    // Check for pending request
    const existingRequest = await db.verificationRequest.findFirst({
      where: { 
        userId: user.id,
        status: 'pending'
      }
    })

    if (existingRequest) {
      return NextResponse.json({ error: 'Pending request already exists' }, { status: 400 })
    }

    const body = await request.json()
    const { fullName, category, idType, idNumber, idImageUrl, selfieUrl } = body

    if (!fullName || !category || !idType || !idNumber || !idImageUrl) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const verificationRequest = await db.verificationRequest.create({
      data: {
        userId: user.id,
        fullName,
        category,
        idType,
        idNumber,
        idImageUrl,
        selfieUrl,
      }
    })

    return NextResponse.json({ request: verificationRequest })
  } catch (error) {
    console.error('Create verification error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
