import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'

// GET unread counts for notifications and messages
export async function GET() {
  try {
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ notifications: 0, messages: 0 })
    }

    // Get unread notifications count
    const unreadNotifications = await db.notification.count({
      where: { 
        userId: user.id,
        isRead: false 
      }
    })

    // Get unread messages count
    // First get all conversations the user is part of
    const participations = await db.conversationParticipant.findMany({
      where: { userId: user.id },
      select: { conversationId: true }
    })
    
    const conversationIds = participations.map(p => p.conversationId)
    
    // Count unread messages where the sender is not the current user
    const unreadMessages = await db.message.count({
      where: {
        conversationId: { in: conversationIds },
        senderId: { not: user.id },
        isRead: false,
      }
    })

    return NextResponse.json({ 
      notifications: unreadNotifications,
      messages: unreadMessages 
    })
  } catch (error) {
    console.error('Get unread counts error:', error)
    return NextResponse.json({ notifications: 0, messages: 0 })
  }
}
