import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: userId } = await params
    const currentUser = await getCurrentUser()
    
    const followers = await db.follow.findMany({
      where: { followingId: userId, isAccepted: true },
      select: {
        follower: {
          select: {
            id: true,
            username: true,
            fullName: true,
            avatar: true,
            isVerified: true,
            isPrivate: true,
          }
        }
      }
    })
    
    let followingIds: string[] = []
    if (currentUser) {
      const following = await db.follow.findMany({
        where: { followerId: currentUser.id },
        select: { followingId: true }
      })
      followingIds = following.map(f => f.followingId)
    }
    
    const users = followers.map(f => ({
      ...f.follower,
      isFollowing: followingIds.includes(f.follower.id)
    }))
    
    return NextResponse.json({ followers: users })
  } catch (error) {
    console.error('Get followers error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
