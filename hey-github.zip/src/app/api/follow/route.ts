import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'

// Follow/Unfollow
export async function POST(request: NextRequest) {
  try {
    const currentUser = await getCurrentUser()

    if (!currentUser) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { targetUserId, followerId, followingId } = await request.json()

    // Support both old and new API formats
    const follower = followerId || currentUser.id
    const following = followingId || targetUserId

    if (!following) {
      return NextResponse.json({ error: 'Target user ID is required' }, { status: 400 })
    }

    if (follower === following) {
      return NextResponse.json({ error: 'Cannot follow yourself' }, { status: 400 })
    }

    const existing = await db.follow.findUnique({
      where: {
        followerId_followingId: { followerId: follower, followingId: following }
      }
    })

    if (existing) {
      await db.follow.delete({
        where: { id: existing.id }
      })
      return NextResponse.json({ following: false })
    } else {
      // Check if target user is private
      const targetUser = await db.user.findUnique({
        where: { id: following },
        select: { isPrivate: true }
      })

      const isAccepted = !targetUser?.isPrivate

      await db.follow.create({
        data: {
          followerId: follower,
          followingId: following,
          isAccepted
        }
      })

      // Create notification
      await db.notification.create({
        data: {
          type: targetUser?.isPrivate ? 'follow_request' : 'follow',
          content: targetUser?.isPrivate
            ? `${currentUser.username} requested to follow you`
            : `${currentUser.username} started following you`,
          userId: following,
          fromUserId: currentUser.id
        }
      })

      return NextResponse.json({
        following: isAccepted,
        isRequested: targetUser?.isPrivate || false
      })
    }
  } catch (error) {
    console.error('Follow error:', error)
    return NextResponse.json({ error: 'Failed to follow' }, { status: 500 })
  }
}
