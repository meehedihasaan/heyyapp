import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    
    const data = await request.json()
    const { type, content, bgColor, textColor, duration, privacy, shareToFeed } = data
    
    if (!content) {
      return NextResponse.json({ error: 'Content is required' }, { status: 400 })
    }
    
    const now = new Date()
    const expiresAt = new Date(now.getTime() + 24 * 60 * 60 * 1000) // 24 hours
    
    const story = await db.story.create({
      data: {
        type: type || 'image',
        content,
        bgColor: bgColor || null,
        textColor: textColor || null,
        duration: duration || 5,
        privacy: privacy || 'public',
        shareToFeed: shareToFeed || false,
        authorId: user.id,
        expiresAt
      },
      include: {
        author: {
          select: {
            id: true,
            username: true,
            fullName: true,
            avatar: true,
            isVerified: true,
          }
        }
      }
    })
    
    // If shareToFeed is true, also create a post
    if (shareToFeed && type === 'image') {
      await db.post.create({
        data: {
          caption: 'Story shared to feed',
          authorId: user.id,
          images: {
            create: { url: content, order: 0 }
          }
        }
      })
    }
    
    return NextResponse.json({ story })
  } catch (error) {
    console.error('Create story error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
