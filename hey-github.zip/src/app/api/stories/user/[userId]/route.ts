import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET(
  request: Request,
  { params }: { params: Promise<{ userId: string }> }
) {
  try {
    const { userId } = await params
    const currentUser = await getCurrentUser()
    
    const now = new Date()
    
    const stories = await db.story.findMany({
      where: {
        authorId: userId,
        expiresAt: { gt: now }
      },
      orderBy: { createdAt: 'asc' },
      include: {
        author: {
          select: {
            id: true,
            username: true,
            fullName: true,
            avatar: true,
            isVerified: true,
          }
        },
        viewers: {
          include: {
            user: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            }
          }
        },
        reactions: {
          include: {
            user: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            }
          }
        },
        replies: {
          include: {
            user: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            }
          },
          orderBy: { createdAt: 'asc' }
        }
      }
    })
    
    const storiesWithViewed = stories.map(story => {
      const userViewer = currentUser ? story.viewers.find(v => v.userId === currentUser.id) : null
      const userReaction = story.reactions.find(r => r.userId === currentUser?.id)
      
      return {
        id: story.id,
        type: story.type,
        content: story.content,
        bgColor: story.bgColor,
        textColor: story.textColor,
        duration: story.duration,
        createdAt: story.createdAt.toISOString(),
        author: story.author,
        viewed: !!userViewer,
        viewers: story.viewers.map(v => ({
          id: v.id,
          user: v.user,
          viewedAt: v.viewedAt.toISOString()
        })),
        reactions: story.reactions.map(r => ({
          id: r.id,
          type: r.type,
          user: r.user,
          createdAt: r.createdAt.toISOString()
        })),
        replies: story.replies.map(r => ({
          id: r.id,
          content: r.content,
          user: r.user,
          createdAt: r.createdAt.toISOString()
        })),
        myReaction: userReaction?.type || null
      }
    })
    
    return NextResponse.json({ stories: storiesWithViewed })
  } catch (error) {
    console.error('Get user stories error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
