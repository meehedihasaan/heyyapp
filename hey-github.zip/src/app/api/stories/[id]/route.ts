import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: storyId } = await params
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    
    // Mark story as viewed
    const existingView = await db.storyViewer.findUnique({
      where: { storyId_userId: { storyId, userId: user.id } }
    })
    
    if (!existingView) {
      await db.storyViewer.create({
        data: { storyId, userId: user.id }
      })
    }
    
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('View story error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: storyId } = await params
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    
    const story = await db.story.findUnique({
      where: { id: storyId },
      select: { authorId: true }
    })
    
    if (!story) {
      return NextResponse.json({ error: 'Story not found' }, { status: 404 })
    }
    
    if (story.authorId !== user.id) {
      return NextResponse.json({ error: 'Not authorized' }, { status: 403 })
    }
    
    await db.story.delete({ where: { id: storyId } })
    
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Delete story error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
