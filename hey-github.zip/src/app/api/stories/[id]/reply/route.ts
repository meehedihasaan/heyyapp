import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'

// Reply to a story
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { id } = await params
    const { content } = await request.json()
    
    if (!content || !content.trim()) {
      return NextResponse.json({ error: 'Content is required' }, { status: 400 })
    }

    // Check if story exists
    const story = await db.story.findUnique({
      where: { id }
    })

    if (!story) {
      return NextResponse.json({ error: 'Story not found' }, { status: 404 })
    }

    // Create reply
    const reply = await db.storyReply.create({
      data: {
        storyId: id,
        userId: user.id,
        content: content.trim()
      },
      include: {
        user: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        }
      }
    })

    return NextResponse.json({ reply })
  } catch (error) {
    console.error('Story reply error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
