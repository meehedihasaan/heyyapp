import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'

// React to a story
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { id } = await params
    const { type } = await request.json()
    
    if (!type || !['like', 'love', 'laugh', 'wow', 'sad', 'angry'].includes(type)) {
      return NextResponse.json({ error: 'Invalid reaction type' }, { status: 400 })
    }

    // Check if story exists
    const story = await db.story.findUnique({
      where: { id }
    })

    if (!story) {
      return NextResponse.json({ error: 'Story not found' }, { status: 404 })
    }

    // Check for existing reaction
    const existingReaction = await db.storyReaction.findUnique({
      where: {
        storyId_userId: {
          storyId: id,
          userId: user.id
        }
      }
    })

    if (existingReaction) {
      // Update or remove reaction
      if (existingReaction.type === type) {
        // Remove reaction
        await db.storyReaction.delete({
          where: { id: existingReaction.id }
        })
        return NextResponse.json({ reaction: null, action: 'removed' })
      } else {
        // Update reaction
        const updated = await db.storyReaction.update({
          where: { id: existingReaction.id },
          data: { type }
        })
        return NextResponse.json({ reaction: updated, action: 'updated' })
      }
    }

    // Create new reaction
    const reaction = await db.storyReaction.create({
      data: {
        storyId: id,
        userId: user.id,
        type
      }
    })

    return NextResponse.json({ reaction, action: 'created' })
  } catch (error) {
    console.error('Story reaction error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
