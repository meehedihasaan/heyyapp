import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'

// Get stories grouped by author (Facebook-style)
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser()

    if (!user) {
      return NextResponse.json({ stories: [] })
    }

    // Get stories from last 24 hours
    const stories = await db.story.findMany({
      where: {
        expiresAt: { gt: new Date() }
      },
      include: {
        author: {
          select: {
            id: true,
            username: true,
            fullName: true,
            avatar: true,
            isVerified: true,
          }
        },
        viewers: {
          include: {
            user: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            }
          }
        },
        reactions: {
          include: {
            user: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            }
          }
        },
        replies: {
          include: {
            user: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            }
          },
          orderBy: { createdAt: 'asc' }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    // Group stories by author
    const groupedStories: { [authorId: string]: { 
      author: any
      stories: any[]
    } } = {}

    for (const story of stories) {
      const authorId = story.author.id
      
      if (!groupedStories[authorId]) {
        groupedStories[authorId] = {
          author: story.author,
          stories: []
        }
      }
      
      const userViewed = story.viewers.find(v => v.userId === user.id)
      const userReaction = story.reactions.find(r => r.userId === user.id)
      
      groupedStories[authorId].stories.push({
        id: story.id,
        type: story.type,
        content: story.content,
        bgColor: story.bgColor,
        textColor: story.textColor,
        duration: story.duration,
        createdAt: story.createdAt.toISOString(),
        privacy: story.privacy,
        shareToFeed: story.shareToFeed,
        viewed: !!userViewed,
        viewedAt: userViewed?.viewedAt?.toISOString(),
        viewers: story.viewers.map(v => ({
          id: v.id,
          user: v.user,
          viewedAt: v.viewedAt.toISOString()
        })),
        reactions: story.reactions.map(r => ({
          id: r.id,
          type: r.type,
          user: r.user,
          createdAt: r.createdAt.toISOString()
        })),
        replies: story.replies.map(r => ({
          id: r.id,
          content: r.content,
          user: r.user,
          createdAt: r.createdAt.toISOString()
        })),
        myReaction: userReaction?.type || null
      })
    }

    // Convert to array and sort (current user first, then by most recent story)
    const result = Object.values(groupedStories).sort((a, b) => {
      if (a.author.id === user.id) return -1
      if (b.author.id === user.id) return 1
      return 0
    })

    return NextResponse.json({ stories: result })
  } catch (error) {
    console.error('Get stories error:', error)
    return NextResponse.json({ stories: [] })
  }
}
