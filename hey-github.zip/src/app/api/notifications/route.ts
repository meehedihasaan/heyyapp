import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'

// GET notifications
export async function GET() {
  try {
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ notifications: [] })
    }

    const notifications = await db.notification.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      take: 50,
    })

    // Get fromUser details
    const fromUserIds = [...new Set(notifications.map(n => n.fromUserId).filter(Boolean))]
    const fromUsers = await db.user.findMany({
      where: { id: { in: fromUserIds as string[] } },
      select: {
        id: true,
        username: true,
        fullName: true,
        avatar: true,
        isVerified: true,
      }
    })

    // Get post details
    const postIds = [...new Set(notifications.map(n => n.postId).filter(Boolean))]
    const posts = await db.post.findMany({
      where: { id: { in: postIds as string[] } },
      select: {
        id: true,
        images: { select: { url: true }, take: 1 }
      }
    })

    // Check if user is following the fromUsers
    const following = await db.follow.findMany({
      where: { 
        followerId: user.id,
        followingId: { in: fromUserIds as string[] }
      },
      select: { followingId: true }
    })
    const followingIds = new Set(following.map(f => f.followingId))

    const notificationsWithDetails = notifications.map(n => {
      const fromUser = fromUsers.find(u => u.id === n.fromUserId)
      const post = posts.find(p => p.id === n.postId)
      
      return {
        id: n.id,
        type: n.type,
        content: n.content,
        isRead: n.isRead,
        createdAt: n.createdAt,
        fromUser: fromUser ? {
          id: fromUser.id,
          username: fromUser.username,
          fullName: fromUser.fullName,
          avatar: fromUser.avatar,
          isVerified: fromUser.isVerified,
        } : undefined,
        post: post ? {
          id: post.id,
          images: post.images,
        } : undefined,
        isFollowing: fromUser ? followingIds.has(fromUser.id) : false,
      }
    })

    return NextResponse.json({ notifications: notificationsWithDetails })
  } catch (error) {
    console.error('Get notifications error:', error)
    return NextResponse.json({ notifications: [] })
  }
}

// PUT mark all as read
export async function PUT() {
  try {
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    await db.notification.updateMany({
      where: { userId: user.id, isRead: false },
      data: { isRead: true }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Mark notifications read error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
