import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'

export async function GET() {
  try {
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    
    // For now, return 0 as we don't have a blocked users table
    // In a real app, you would query a BlockedUser table
    const count = 0
    
    return NextResponse.json({ count })
  } catch (error) {
    console.error('Get blocked count error:', error)
    return NextResponse.json({ count: 0 })
  }
}
