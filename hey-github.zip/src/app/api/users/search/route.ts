import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const currentUser = await getCurrentUser()
    const { searchParams } = new URL(request.url)
    const q = searchParams.get('q')
    
    if (!q) {
      return NextResponse.json({ users: [] })
    }
    
    const users = await db.user.findMany({
      where: {
        OR: [
          { username: { contains: q } },
          { fullName: { contains: q } }
        ],
        NOT: { id: currentUser?.id }
      },
      take: 20,
      select: {
        id: true,
        username: true,
        fullName: true,
        avatar: true,
        isVerified: true,
        isPrivate: true,
      }
    })
    
    // Get following status for each user
    let followingIds: string[] = []
    if (currentUser) {
      const follows = await db.follow.findMany({
        where: { 
          followerId: currentUser.id,
          followingId: { in: users.map(u => u.id) },
          isAccepted: true 
        },
        select: { followingId: true }
      })
      followingIds = follows.map(f => f.followingId)
    }
    
    const usersWithFollowing = users.map(user => ({
      ...user,
      isFollowing: followingIds.includes(user.id)
    }))
    
    return NextResponse.json({ users: usersWithFollowing })
  } catch (error) {
    console.error('Search users error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
