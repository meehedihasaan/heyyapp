import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Get suggested users (users not followed by current user)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json({ users: [] })
    }

    // Get users that current user is already following
    const following = await db.follow.findMany({
      where: { followerId: userId },
      select: { followingId: true }
    })
    
    const followingIds = following.map(f => f.followingId)
    followingIds.push(userId) // Exclude self

    // Get suggested users (not followed, not self)
    const suggestedUsers = await db.user.findMany({
      where: {
        id: { notIn: followingIds },
        isPrivate: false, // Only suggest public accounts
      },
      select: {
        id: true,
        username: true,
        fullName: true,
        avatar: true,
        isVerified: true,
        bio: true,
        _count: { select: { followers: true } }
      },
      take: 10,
      orderBy: { createdAt: 'desc' }
    })

    const formattedUsers = suggestedUsers.map(user => ({
      id: user.id,
      username: user.username,
      fullName: user.fullName,
      avatar: user.avatar,
      isVerified: user.isVerified,
      bio: user.bio,
      followersCount: user._count.followers,
      isFollowing: false
    }))

    return NextResponse.json({ users: formattedUsers })
  } catch (error) {
    console.error('Get suggested users error:', error)
    return NextResponse.json({ users: [] })
  }
}
