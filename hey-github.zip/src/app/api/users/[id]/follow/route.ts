import { NextResponse } from 'next/server'
import { getCurrentUser, getUserStats } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: targetUserId } = await params
    const currentUser = await getCurrentUser()
    
    if (!currentUser) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    
    if (currentUser.id === targetUserId) {
      return NextResponse.json({ error: 'Cannot follow yourself' }, { status: 400 })
    }
    
    const existingFollow = await db.follow.findUnique({
      where: {
        followerId_followingId: { followerId: currentUser.id, followingId: targetUserId }
      }
    })
    
    // Check if target user follows current user (for follow back)
    const followBack = await db.follow.findUnique({
      where: {
        followerId_followingId: { followerId: targetUserId, followingId: currentUser.id }
      }
    })
    const isFollowedBy = !!(followBack && followBack.isAccepted)
    
    if (existingFollow) {
      // Unfollow or cancel request
      await db.follow.delete({ where: { id: existingFollow.id } })
      
      const stats = await getUserStats(targetUserId)
      return NextResponse.json({ 
        isFollowing: false, 
        isRequested: false,
        isFollowedBy,
        ...stats 
      })
    } else {
      const targetUser = await db.user.findUnique({
        where: { id: targetUserId },
        select: { isPrivate: true }
      })
      
      const isAccepted = !targetUser?.isPrivate
      
      await db.follow.create({
        data: {
          followerId: currentUser.id,
          followingId: targetUserId,
          isAccepted
        }
      })
      
      await db.notification.create({
        data: {
          type: targetUser?.isPrivate ? 'follow_request' : 'follow',
          content: targetUser?.isPrivate 
            ? `${currentUser.username} requested to follow you`
            : `${currentUser.username} started following you`,
          userId: targetUserId,
          fromUserId: currentUser.id
        }
      })
      
      const stats = await getUserStats(targetUserId)
      return NextResponse.json({ 
        isFollowing: isAccepted,
        isRequested: targetUser?.isPrivate || false,
        isFollowedBy,
        ...stats 
      })
    }
  } catch (error) {
    console.error('Follow error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// GET endpoint to check follow status
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: targetUserId } = await params
    const currentUser = await getCurrentUser()
    
    if (!currentUser) {
      return NextResponse.json({ isFollowing: false, isRequested: false, isFollowedBy: false })
    }
    
    const follow = await db.follow.findUnique({
      where: {
        followerId_followingId: { followerId: currentUser.id, followingId: targetUserId }
      }
    })
    
    // Check if target user follows current user
    const followBack = await db.follow.findUnique({
      where: {
        followerId_followingId: { followerId: targetUserId, followingId: currentUser.id }
      }
    })
    const isFollowedBy = !!(followBack && followBack.isAccepted)
    
    if (!follow) {
      return NextResponse.json({ isFollowing: false, isRequested: false, isFollowedBy })
    }
    
    return NextResponse.json({ 
      isFollowing: follow.isAccepted,
      isRequested: !follow.isAccepted,
      isFollowedBy
    })
  } catch (error) {
    console.error('Get follow status error:', error)
    return NextResponse.json({ isFollowing: false, isRequested: false, isFollowedBy: false })
  }
}
