import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUser, getUserStats } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const currentUser = await getCurrentUser()
    
    const user = await db.user.findUnique({
      where: { id },
      select: {
        id: true,
        username: true,
        fullName: true,
        avatar: true,
        bio: true,
        website: true,
        isVerified: true,
        isPrivate: true,
      }
    })
    
    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }
    
    const stats = await getUserStats(id)
    
    let isFollowing = false
    let isFollowedBy = false
    let isRequested = false
    
    if (currentUser && currentUser.id !== id) {
      // Check if current user follows this profile user
      const follow = await db.follow.findUnique({
        where: {
          followerId_followingId: { followerId: currentUser.id, followingId: id }
        }
      })
      
      if (follow) {
        if (follow.isAccepted) {
          isFollowing = true
        } else {
          isRequested = true
        }
      }
      
      // Check if this profile user follows current user
      const followBack = await db.follow.findUnique({
        where: {
          followerId_followingId: { followerId: id, followingId: currentUser.id }
        }
      })
      isFollowedBy = !!(followBack && followBack.isAccepted)
    }
    
    return NextResponse.json({
      user: { ...user, ...stats, isFollowing, isFollowedBy, isRequested }
    })
  } catch (error) {
    console.error('Get user error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
