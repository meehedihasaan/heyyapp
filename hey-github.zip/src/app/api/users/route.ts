import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Get users / search users
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const search = searchParams.get('search')
    const userId = searchParams.get('userId')
    const profileUsername = searchParams.get('profile')

    if (profileUsername) {
      const user = await db.user.findUnique({
        where: { username: profileUsername },
        include: {
          _count: { select: { posts: true, followers: true, following: true } },
          followers: userId ? { where: { followerId: userId } } : false
        }
      })

      if (!user) {
        return NextResponse.json({ user: null })
      }

      const { password: _, ...userWithoutPassword } = user
      return NextResponse.json({
        user: {
          ...userWithoutPassword,
          postsCount: user._count.posts,
          followersCount: user._count.followers,
          followingCount: user._count.following,
          isFollowing: user.followers?.length > 0
        }
      })
    }

    if (search) {
      const users = await db.user.findMany({
        where: {
          OR: [
            { username: { contains: search } },
            { fullName: { contains: search } }
          ]
        },
        take: 20,
        include: {
          _count: { select: { posts: true, followers: true, following: true } },
          followers: userId ? { where: { followerId: userId } } : false
        }
      })

      return NextResponse.json({
        users: users.map(user => {
          const { password: _, ...userWithoutPassword } = user
          return {
            ...userWithoutPassword,
            postsCount: user._count.posts,
            followersCount: user._count.followers,
            followingCount: user._count.following,
            isFollowing: user.followers?.length > 0
          }
        })
      })
    }

    // Get all suggested users
    const users = await db.user.findMany({
      where: userId ? { NOT: { id: userId } } : {},
      take: 20,
      include: {
        _count: { select: { posts: true, followers: true, following: true } },
        followers: userId ? { where: { followerId: userId } } : false
      }
    })

    return NextResponse.json({
      users: users.map(user => {
        const { password: _, ...userWithoutPassword } = user
        return {
          ...userWithoutPassword,
          postsCount: user._count.posts,
          followersCount: user._count.followers,
          followingCount: user._count.following,
          isFollowing: user.followers?.length > 0
        }
      })
    })
  } catch (error) {
    console.error('Get users error:', error)
    return NextResponse.json({ users: [] })
  }
}
