import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUser, getUserStats } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    
    const stats = await getUserStats(user.id)
    return NextResponse.json({ user: { ...user, ...stats } })
  } catch (error) {
    console.error('Get user error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    
    const data = await request.json()
    const { fullName, bio, website, phone, gender, isPrivate, avatar, username } = data
    
    // Check if username is being changed and if it's already taken
    if (username && username !== user.username) {
      const existingUser = await db.user.findFirst({
        where: {
          username,
          id: { not: user.id }
        }
      })
      if (existingUser) {
        return NextResponse.json({ error: 'Username is already taken' }, { status: 400 })
      }
    }
    
    const updatedUser = await db.user.update({
      where: { id: user.id },
      data: {
        fullName: fullName ?? undefined,
        bio: bio ?? undefined,
        website: website ?? undefined,
        phone: phone ?? undefined,
        gender: gender ?? undefined,
        isPrivate: isPrivate ?? undefined,
        avatar: avatar ?? undefined,
        username: username ?? undefined,
      }
    })
    
    const stats = await getUserStats(user.id)
    
    return NextResponse.json({
      user: {
        id: updatedUser.id,
        username: updatedUser.username,
        email: updatedUser.email,
        fullName: updatedUser.fullName,
        avatar: updatedUser.avatar,
        bio: updatedUser.bio,
        website: updatedUser.website,
        phone: updatedUser.phone,
        gender: updatedUser.gender,
        isVerified: updatedUser.isVerified,
        isPrivate: updatedUser.isPrivate,
        ...stats
      }
    })
  } catch (error) {
    console.error('Update user error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
