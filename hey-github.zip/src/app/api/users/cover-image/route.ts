import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'
import { writeFile, unlink } from 'fs/promises'
import { join } from 'path'
import { v4 as uuidv4 } from 'uuid'
import { existsSync } from 'fs'

export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    
    const formData = await request.formData()
    const file = formData.get('file') as File | null
    
    if (!file) {
      return NextResponse.json({ error: 'No file provided' }, { status: 400 })
    }
    
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp']
    if (!allowedTypes.includes(file.type)) {
      return NextResponse.json({ error: 'Invalid file type' }, { status: 400 })
    }
    
    const maxSize = 10 * 1024 * 1024 // 10MB
    if (file.size > maxSize) {
      return NextResponse.json({ error: 'File too large' }, { status: 400 })
    }
    
    // Get current user to check for existing cover image
    const currentUser = await db.user.findUnique({
      where: { id: user.id },
      select: { coverImage: true }
    })
    
    // Delete old cover image if exists
    if (currentUser?.coverImage?.startsWith('/uploads/')) {
      const oldPath = join(process.cwd(), 'public', currentUser.coverImage)
      if (existsSync(oldPath)) {
        await unlink(oldPath).catch(() => {})
      }
    }
    
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)
    
    const ext = file.name.split('.').pop() || 'jpg'
    const fileName = `cover-${uuidv4()}.${ext}`
    const filePath = join(process.cwd(), 'public', 'uploads', fileName)
    
    await writeFile(filePath, buffer)
    
    // Update user with new cover image
    const updatedUser = await db.user.update({
      where: { id: user.id },
      data: { coverImage: `/uploads/${fileName}` }
    })
    
    return NextResponse.json({ 
      coverImage: updatedUser.coverImage 
    })
  } catch (error) {
    console.error('Cover image upload error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function DELETE() {
  try {
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    
    // Get current user to check for existing cover image
    const currentUser = await db.user.findUnique({
      where: { id: user.id },
      select: { coverImage: true }
    })
    
    // Delete cover image file if exists
    if (currentUser?.coverImage?.startsWith('/uploads/')) {
      const oldPath = join(process.cwd(), 'public', currentUser.coverImage)
      if (existsSync(oldPath)) {
        await unlink(oldPath).catch(() => {})
      }
    }
    
    // Remove cover image from user
    await db.user.update({
      where: { id: user.id },
      data: { coverImage: null }
    })
    
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Cover image delete error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
