import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'

// GET - Get user's highlights (public)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const targetUserId = searchParams.get('userId')

    if (!targetUserId) {
      return NextResponse.json({ highlights: [] })
    }

    // Check if highlight model exists (might need server restart after schema change)
    if (!('highlight' in db)) {
      return NextResponse.json({ highlights: [] })
    }

    const highlights = await db.highlight.findMany({
      where: { userId: targetUserId },
      include: {
        stories: {
          orderBy: { order: 'asc' }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({ highlights })
  } catch (error) {
    console.error('Get highlights error:', error)
    // Return empty array if there's an error (model might not exist yet)
    return NextResponse.json({ highlights: [] })
  }
}

// POST - Create a new highlight (requires auth)
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Check if highlight model exists
    if (!('highlight' in db)) {
      return NextResponse.json({ error: 'Highlights feature requires server restart' }, { status: 503 })
    }

    const { title, coverImage, storyIds } = await request.json()

    if (!title?.trim()) {
      return NextResponse.json({ error: 'Title is required' }, { status: 400 })
    }

    const highlight = await db.highlight.create({
      data: {
        title,
        coverImage,
        userId: user.id,
        stories: storyIds?.length > 0 ? {
          create: storyIds.map((storyId: string, index: number) => ({
            storyId,
            order: index
          }))
        } : undefined
      },
      include: {
        stories: true
      }
    })

    return NextResponse.json({ highlight })
  } catch (error) {
    console.error('Create highlight error:', error)
    return NextResponse.json({ error: 'Failed to create highlight' }, { status: 500 })
  }
}
