import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Like/Unlike post
export async function POST(request: NextRequest) {
  try {
    const { userId, postId } = await request.json()

    const existing = await db.like.findUnique({
      where: { userId_postId: { userId, postId } }
    })

    if (existing) {
      await db.like.delete({ where: { id: existing.id } })
      return NextResponse.json({ liked: false })
    } else {
      await db.like.create({ data: { userId, postId } })
      return NextResponse.json({ liked: true })
    }
  } catch (error) {
    console.error('Like error:', error)
    return NextResponse.json({ error: 'Failed to like' }, { status: 500 })
  }
}
