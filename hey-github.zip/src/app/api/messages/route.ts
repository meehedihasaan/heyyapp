import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'

// Get all conversations for current user
export async function GET() {
  try {
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Get all conversations the user is part of
    const participations = await db.conversationParticipant.findMany({
      where: { userId: user.id },
      include: {
        conversation: {
          include: {
            participants: {
              include: {
                user: {
                  select: {
                    id: true,
                    username: true,
                    fullName: true,
                    avatar: true,
                    isVerified: true,
                  }
                }
              }
            },
            messages: {
              take: 1,
              orderBy: { createdAt: 'desc' },
              include: {
                sender: {
                  select: {
                    id: true,
                    username: true,
                    avatar: true,
                  }
                }
              }
            }
          }
        }
      },
      orderBy: {
        conversation: {
          updatedAt: 'desc'
        }
      }
    })

    // Transform into conversation list
    const conversations = participations.map(p => {
      const otherParticipant = p.conversation.participants.find(
        part => part.userId !== user.id
      )
      const lastMessage = p.conversation.messages[0]
      
      return {
        id: p.conversation.id,
        user: otherParticipant?.user || null,
        lastMessage: lastMessage ? {
          id: lastMessage.id,
          content: lastMessage.content,
          imageUrl: lastMessage.imageUrl,
          senderId: lastMessage.senderId,
          sender: lastMessage.sender,
          createdAt: lastMessage.createdAt,
          isRead: lastMessage.isRead,
        } : null,
        unreadCount: 0, // Will calculate separately
        updatedAt: p.conversation.updatedAt,
      }
    })

    // Get unread counts
    const conversationIds = conversations.map(c => c.id)
    const unreadCounts = await db.message.groupBy({
      by: ['conversationId'],
      where: {
        conversationId: { in: conversationIds },
        senderId: { not: user.id },
        isRead: false,
      },
      _count: true,
    })

    const unreadMap = new Map(unreadCounts.map(u => [u.conversationId, u._count]))
    
    const result = conversations.map(c => ({
      ...c,
      unreadCount: unreadMap.get(c.id) || 0,
    }))

    return NextResponse.json({ conversations: result })
  } catch (error) {
    console.error('Get conversations error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// Start a new conversation with a user
export async function POST(request: Request) {
  try {
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { userId, message } = await request.json()
    
    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 })
    }

    // Check if conversation already exists between these users
    const existingParticipation = await db.conversationParticipant.findFirst({
      where: { 
        userId: user.id,
        conversation: {
          participants: {
            some: { userId }
          }
        }
      },
      include: { conversation: true }
    })

    if (existingParticipation) {
      // If there's a message to send, send it
      if (message) {
        const newMessage = await db.message.create({
          data: {
            conversationId: existingParticipation.conversationId,
            senderId: user.id,
            content: message,
          },
          include: {
            sender: {
              select: {
                id: true,
                username: true,
                avatar: true,
              }
            }
          }
        })
        
        await db.conversation.update({
          where: { id: existingParticipation.conversationId },
          data: { updatedAt: new Date() }
        })
        
        return NextResponse.json({ 
          conversationId: existingParticipation.conversationId,
          message: newMessage,
          isNew: false 
        })
      }
      
      return NextResponse.json({ 
        conversationId: existingParticipation.conversationId,
        isNew: false 
      })
    }

    // Create new conversation
    const conversation = await db.conversation.create({
      data: {
        participants: {
          create: [
            { userId: user.id },
            { userId }
          ]
        }
      }
    })

    // If there's a message, create it
    let newMessage = null
    if (message) {
      newMessage = await db.message.create({
        data: {
          conversationId: conversation.id,
          senderId: user.id,
          content: message,
        },
        include: {
          sender: {
            select: {
              id: true,
              username: true,
              avatar: true,
            }
          }
        }
      })
    }

    return NextResponse.json({ 
      conversationId: conversation.id, 
      message: newMessage,
      isNew: true 
    })
  } catch (error) {
    console.error('Create conversation error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
