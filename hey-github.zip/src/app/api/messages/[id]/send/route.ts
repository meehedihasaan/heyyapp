import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'

// Send a message in a conversation
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { id } = await params
    const { content, imageUrl, emotion } = await request.json()
    
    if (!content && !imageUrl) {
      return NextResponse.json({ error: 'Message content is required' }, { status: 400 })
    }

    // Check if user is part of this conversation
    const participation = await db.conversationParticipant.findUnique({
      where: {
        conversationId_userId: {
          conversationId: id,
          userId: user.id,
        }
      }
    })

    if (!participation) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 })
    }

    // Create message
    const message = await db.message.create({
      data: {
        conversationId: id,
        senderId: user.id,
        content: content || '',
        imageUrl,
        emotion: emotion || 'casual',
      },
      include: {
        sender: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        }
      }
    })

    // Update conversation updatedAt
    await db.conversation.update({
      where: { id },
      data: { updatedAt: new Date() }
    })

    return NextResponse.json({ message })
  } catch (error) {
    console.error('Send message error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
