import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'

// Get messages in a conversation
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { id } = await params

    // Check if user is part of this conversation
    const participation = await db.conversationParticipant.findUnique({
      where: {
        conversationId_userId: {
          conversationId: id,
          userId: user.id,
        }
      }
    })

    if (!participation) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 })
    }

    // Get messages
    const messages = await db.message.findMany({
      where: { conversationId: id },
      include: {
        sender: {
          select: {
            id: true,
            username: true,
            avatar: true,
          }
        }
      },
      orderBy: { createdAt: 'asc' }
    })

    // Mark messages as read
    await db.message.updateMany({
      where: {
        conversationId: id,
        senderId: { not: user.id },
        isRead: false,
      },
      data: { isRead: true }
    })

    // Get other participant
    const otherParticipant = await db.conversationParticipant.findFirst({
      where: {
        conversationId: id,
        userId: { not: user.id }
      },
      include: {
        user: {
          select: {
            id: true,
            username: true,
            fullName: true,
            avatar: true,
            isVerified: true,
          }
        }
      }
    })

    return NextResponse.json({ 
      messages,
      otherUser: otherParticipant?.user || null 
    })
  } catch (error) {
    console.error('Get messages error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
