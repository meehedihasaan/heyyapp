import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser, getUserStats } from '@/lib/auth'

// Get posts feed or user's posts
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const username = searchParams.get('username')
    const profileUserId = searchParams.get('profileUserId') // For fetching a specific user's posts

    let where: any = {}
    let currentUserId = userId
    
    // If profileUserId is specified, get that user's posts only
    if (profileUserId) {
      // Check if the profile is private and user is not following
      const profileUser = await db.user.findUnique({
        where: { id: profileUserId },
        select: { isPrivate: true }
      })
      
      if (profileUser?.isPrivate && currentUserId !== profileUserId) {
        // Check if current user is following (accepted)
        const follow = currentUserId ? await db.follow.findUnique({
          where: {
            followerId_followingId: { followerId: currentUserId, followingId: profileUserId }
          }
        }) : null
        
        if (!follow?.isAccepted) {
          // Return empty posts for private profiles where not following
          return NextResponse.json({ 
            posts: [], 
            isPrivate: true, 
            isFollowing: follow?.isAccepted || false,
            isRequested: follow ? !follow.isAccepted : false
          })
        }
      }
      
      where.authorId = profileUserId
    } else if (username) {
      const user = await db.user.findUnique({ where: { username } })
      if (!user) return NextResponse.json({ posts: [] })
      where.authorId = user.id
    } else if (userId) {
      // Get posts from followed users + own posts (feed)
      const follows = await db.follow.findMany({
        where: { followerId: userId, isAccepted: true },
        select: { followingId: true }
      })
      const followingIds = follows.map(f => f.followingId)
      followingIds.push(userId)
      where.authorId = { in: followingIds }
    }

    const posts = await db.post.findMany({
      where,
      include: {
        author: {
          select: {
            id: true,
            username: true,
            fullName: true,
            avatar: true,
            isVerified: true,
            isPrivate: true,
            bio: true,
            website: true,
            _count: { select: { posts: true, followers: true, following: true } }
          }
        },
        images: { orderBy: { order: 'asc' } },
        likes: currentUserId ? { where: { userId: currentUserId } } : false,
        comments: {
          take: 5,
          orderBy: { createdAt: 'desc' },
          select: {
            id: true,
            content: true,
            createdAt: true,
            author: {
              select: {
                id: true,
                username: true,
                fullName: true,
                avatar: true,
                isVerified: true,
              }
            }
          }
        },
        _count: { select: { likes: true, comments: true } }
      },
      orderBy: { createdAt: 'desc' },
      take: 50
    })

    // Check if posts are saved by current user
    let savedPostIds: string[] = []
    if (currentUserId) {
      const savedPosts = await db.savedPost.findMany({
        where: { userId: currentUserId },
        select: { postId: true }
      })
      savedPostIds = savedPosts.map(s => s.postId)
    }

    // Check follow status for authors
    const authorIds = [...new Set(posts.map(p => p.author.id))]
    let followStatuses: Record<string, { isFollowing: boolean; isRequested: boolean }> = {}
    
    if (currentUserId && authorIds.length > 0) {
      const follows = await db.follow.findMany({
        where: {
          followerId: currentUserId,
          followingId: { in: authorIds }
        }
      })
      
      follows.forEach(f => {
        followStatuses[f.followingId] = {
          isFollowing: f.isAccepted,
          isRequested: !f.isAccepted
        }
      })
    }

    const formattedPosts = posts.map(post => ({
      id: post.id,
      caption: post.caption,
      location: post.location,
      backgroundColor: post.backgroundColor,
      createdAt: post.createdAt.toISOString(),
      author: {
        ...post.author,
        postsCount: post.author._count.posts,
        followersCount: post.author._count.followers,
        followingCount: post.author._count.following,
        isFollowing: followStatuses[post.author.id]?.isFollowing || false,
        isRequested: followStatuses[post.author.id]?.isRequested || false
      },
      images: post.images,
      likes: post.likes || [],
      likesCount: post._count.likes,
      comments: post.comments || [],
      commentsCount: post._count.comments,
      isLiked: (post.likes as any[])?.length > 0,
      isSaved: savedPostIds.includes(post.id)
    }))

    return NextResponse.json({ posts: formattedPosts })
  } catch (error) {
    console.error('Get posts error:', error)
    return NextResponse.json({ posts: [] })
  }
}

// Create post
export async function POST(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    
    console.log('Create post - User:', user?.id, user?.username)
    
    if (!user) {
      console.log('Create post - No user found')
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    
    const formData = await request.formData()
    const caption = formData.get('caption') as string
    const location = formData.get('location') as string
    const images = formData.getAll('images') as string[]
    const postType = formData.get('postType') as string
    const backgroundColor = formData.get('backgroundColor') as string | null
    
    console.log('Create post - postType:', postType, 'caption:', caption?.substring(0, 30), 'images:', images.length, 'backgroundColor:', backgroundColor)

    const post = await db.post.create({
      data: {
        authorId: user.id,
        caption,
        location,
        backgroundColor: backgroundColor || null,
        images: {
          create: images.map((url, index) => ({
            url,
            order: index
          }))
        }
      },
      include: {
        author: {
          select: {
            id: true,
            username: true,
            fullName: true,
            avatar: true,
            isVerified: true,
            isPrivate: true,
            bio: true,
            website: true,
            _count: { select: { posts: true, followers: true, following: true } }
          }
        },
        images: true,
        _count: { select: { likes: true, comments: true } }
      }
    })

    const stats = await getUserStats(user.id)

    return NextResponse.json({
      post: {
        id: post.id,
        caption: post.caption,
        location: post.location,
        backgroundColor: post.backgroundColor,
        createdAt: post.createdAt.toISOString(),
        author: {
          ...post.author,
          postsCount: post.author._count.posts,
          followersCount: post.author._count.followers,
          followingCount: post.author._count.following
        },
        images: post.images,
        likes: [],
        likesCount: post._count.likes,
        commentsCount: post._count.comments,
        isLiked: false,
        isSaved: false
      }
    })
  } catch (error) {
    console.error('Create post error:', error)
    return NextResponse.json({ error: 'Failed to create post' }, { status: 500 })
  }
}
