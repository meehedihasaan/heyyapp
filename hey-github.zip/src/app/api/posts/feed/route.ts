import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type') || 'forYou'
    
    const user = await getCurrentUser()
    
    let followingIds: string[] = []
    
    if (user) {
      const following = await db.follow.findMany({
        where: { followerId: user.id, isAccepted: true },
        select: { followingId: true }
      })
      followingIds = following.map(f => f.followingId)
    }
    
    // Include current user's posts in feed
    if (user) {
      followingIds.push(user.id)
    }
    
    const posts = await db.post.findMany({
      where: type === 'following' && followingIds.length > 0 
        ? { authorId: { in: followingIds } }
        : undefined,
      orderBy: { createdAt: 'desc' },
      take: 50,
      select: {
        id: true,
        caption: true,
        location: true,
        backgroundColor: true,
        createdAt: true,
        images: { orderBy: { order: 'asc' } },
        author: {
          select: {
            id: true,
            username: true,
            fullName: true,
            avatar: true,
            isVerified: true,
            isPrivate: true,
          }
        },
        likes: { select: { userId: true } },
        comments: {
          take: 2,
          orderBy: { createdAt: 'desc' },
          select: {
            id: true,
            content: true,
            createdAt: true,
            author: {
              select: {
                id: true,
                username: true,
                fullName: true,
                avatar: true,
                isVerified: true,
              }
            }
          }
        }
      }
    })
    
    // Check if posts are saved by current user
    let savedPostIds: string[] = []
    if (user) {
      const savedPosts = await db.savedPost.findMany({
        where: { userId: user.id },
        select: { postId: true }
      })
      savedPostIds = savedPosts.map(s => s.postId)
    }
    
    const postsWithSaved = posts.map(post => ({
      ...post,
      isSaved: savedPostIds.includes(post.id),
      author: {
        ...post.author,
        isFollowing: post.author.id !== user?.id && followingIds.includes(post.author.id)
      }
    }))
    
    return NextResponse.json({ posts: postsWithSaved })
  } catch (error) {
    console.error('Get feed error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
