import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: postId } = await params
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    
    const existingLike = await db.like.findUnique({
      where: { userId_postId: { userId: user.id, postId } }
    })
    
    if (existingLike) {
      await db.like.delete({ where: { id: existingLike.id } })
      return NextResponse.json({ isLiked: false })
    } else {
      await db.like.create({
        data: { userId: user.id, postId }
      })
      
      const post = await db.post.findUnique({
        where: { id: postId },
        select: { authorId: true }
      })
      
      if (post && post.authorId !== user.id) {
        await db.notification.create({
          data: {
            type: 'like',
            content: `${user.username} liked your post`,
            userId: post.authorId,
            fromUserId: user.id,
            postId
          }
        })
      }
      
      return NextResponse.json({ isLiked: true })
    }
  } catch (error) {
    console.error('Like error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
