import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: postId } = await params
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    
    const post = await db.post.findUnique({
      where: { id: postId },
      select: { authorId: true }
    })
    
    if (!post) {
      return NextResponse.json({ error: 'Post not found' }, { status: 404 })
    }
    
    if (post.authorId !== user.id) {
      return NextResponse.json({ error: 'Not authorized to edit this post' }, { status: 403 })
    }
    
    const body = await request.json()
    const { caption, hideLikeCount } = body
    
    const updatedPost = await db.post.update({
      where: { id: postId },
      data: {
        ...(caption !== undefined && { caption }),
        ...(hideLikeCount !== undefined && { hideLikeCount }),
      },
      include: {
        images: { orderBy: { order: 'asc' } },
        author: {
          select: {
            id: true,
            username: true,
            fullName: true,
            avatar: true,
            isVerified: true,
          }
        }
      }
    })
    
    return NextResponse.json({ post: updatedPost })
  } catch (error) {
    console.error('Edit post error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: postId } = await params
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    
    const post = await db.post.findUnique({
      where: { id: postId },
      select: { authorId: true }
    })
    
    if (!post) {
      return NextResponse.json({ error: 'Post not found' }, { status: 404 })
    }
    
    if (post.authorId !== user.id) {
      return NextResponse.json({ error: 'Not authorized to delete this post' }, { status: 403 })
    }
    
    await db.post.delete({ where: { id: postId } })
    
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Delete post error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: postId } = await params
    const currentUser = await getCurrentUser()
    
    const post = await db.post.findUnique({
      where: { id: postId },
      include: {
        images: { orderBy: { order: 'asc' } },
        author: {
          select: {
            id: true,
            username: true,
            fullName: true,
            avatar: true,
            isVerified: true,
            isPrivate: true,
          }
        },
        likes: { select: { userId: true } },
        comments: {
          take: 10,
          orderBy: { createdAt: 'desc' },
          select: {
            id: true,
            content: true,
            createdAt: true,
            author: {
              select: {
                id: true,
                username: true,
                fullName: true,
                avatar: true,
                isVerified: true,
              }
            }
          }
        }
      }
    })
    
    if (!post) {
      return NextResponse.json({ error: 'Post not found' }, { status: 404 })
    }
    
    let isSaved = false
    if (currentUser) {
      const savedPost = await db.savedPost.findUnique({
        where: { userId_postId: { userId: currentUser.id, postId } }
      })
      isSaved = !!savedPost
    }
    
    return NextResponse.json({ post: { ...post, isSaved } })
  } catch (error) {
    console.error('Get post error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
