import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: postId } = await params
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    
    const existingSave = await db.savedPost.findUnique({
      where: { userId_postId: { userId: user.id, postId } }
    })
    
    if (existingSave) {
      await db.savedPost.delete({ where: { id: existingSave.id } })
      return NextResponse.json({ isSaved: false })
    } else {
      await db.savedPost.create({
        data: { userId: user.id, postId }
      })
      return NextResponse.json({ isSaved: true })
    }
  } catch (error) {
    console.error('Save error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
