import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Get saved posts for a user
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json({ posts: [] })
    }

    const savedPosts = await db.savedPost.findMany({
      where: { userId },
      select: { postId: true },
    })

    const postIds = savedPosts.map(sp => sp.postId)

    if (postIds.length === 0) {
      return NextResponse.json({ posts: [] })
    }

    const posts = await db.post.findMany({
      where: { id: { in: postIds } },
      include: {
        author: {
          select: {
            id: true,
            username: true,
            fullName: true,
            avatar: true,
            isVerified: true,
            isPrivate: true,
            bio: true,
            website: true,
            _count: { select: { posts: true, followers: true, following: true } }
          }
        },
        images: { orderBy: { order: 'asc' } },
        likes: { where: { userId } },
        comments: {
          take: 5,
          orderBy: { createdAt: 'desc' },
          select: {
            id: true,
            content: true,
            createdAt: true,
            author: {
              select: {
                id: true,
                username: true,
                fullName: true,
                avatar: true,
                isVerified: true,
              }
            }
          }
        },
        _count: { select: { likes: true, comments: true } }
      },
      orderBy: { createdAt: 'desc' }
    })

    const formattedPosts = posts.map(post => ({
      id: post.id,
      caption: post.caption,
      location: post.location,
      backgroundColor: post.backgroundColor,
      createdAt: post.createdAt.toISOString(),
      author: {
        ...post.author,
        postsCount: post.author._count.posts,
        followersCount: post.author._count.followers,
        followingCount: post.author._count.following
      },
      images: post.images,
      likes: post.likes || [],
      likesCount: post._count.likes,
      comments: post.comments || [],
      commentsCount: post._count.comments,
      isLiked: (post.likes as any[])?.length > 0,
      isSaved: true
    }))

    return NextResponse.json({ posts: formattedPosts })
  } catch (error) {
    console.error('Get saved posts error:', error)
    return NextResponse.json({ posts: [] })
  }
}
