import { NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'

// GET admin stats
export async function GET() {
  try {
    const user = await getCurrentUser()
    
    if (!user || !user.isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Get various stats
    const [
      totalUsers,
      totalPosts,
      totalStories,
      totalComments,
      totalLikes,
      newUsersToday,
      newPostsToday,
      verifiedUsers,
      bannedUsers,
    ] = await Promise.all([
      db.user.count(),
      db.post.count(),
      db.story.count({ where: { expiresAt: { gt: new Date() } } }),
      db.comment.count(),
      db.like.count(),
      db.user.count({
        where: {
          createdAt: {
            gte: new Date(new Date().setHours(0, 0, 0, 0))
          }
        }
      }),
      db.post.count({
        where: {
          createdAt: {
            gte: new Date(new Date().setHours(0, 0, 0, 0))
          }
        }
      }),
      db.user.count({ where: { isVerified: true } }),
      db.user.count({ where: { isBanned: true } }),
    ])

    return NextResponse.json({
      totalUsers,
      totalPosts,
      totalStories,
      totalComments,
      totalLikes,
      newUsersToday,
      newPostsToday,
      verifiedUsers,
      bannedUsers,
    })
  } catch (error) {
    console.error('Admin stats error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
