import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { db } from '@/lib/db'

// Get verification requests
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    
    if (!user?.isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status') || 'pending'
    const page = parseInt(searchParams.get('page') || '1')
    const limit = 20

    const where = status === 'all' ? {} : { status }

    const [requests, total] = await Promise.all([
      db.verificationRequest.findMany({
        where,
        include: {
          user: {
            select: {
              id: true,
              username: true,
              fullName: true,
              avatar: true,
              email: true,
              isVerified: true,
            }
          }
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.verificationRequest.count({ where })
    ])

    return NextResponse.json({ requests, total })
  } catch (error) {
    console.error('Get verification requests error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// Approve or reject verification request
export async function PUT(request: NextRequest) {
  try {
    const user = await getCurrentUser()
    
    if (!user?.isAdmin) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 })
    }

    const body = await request.json()
    const { requestId, action, reason } = body

    if (!requestId || !['approve', 'reject'].includes(action)) {
      return NextResponse.json({ error: 'Invalid request' }, { status: 400 })
    }

    const verificationRequest = await db.verificationRequest.findUnique({
      where: { id: requestId },
      include: { user: true }
    })

    if (!verificationRequest) {
      return NextResponse.json({ error: 'Request not found' }, { status: 404 })
    }

    if (action === 'approve') {
      // Update verification request and user
      await Promise.all([
        db.verificationRequest.update({
          where: { id: requestId },
          data: { 
            status: 'approved',
            reviewedAt: new Date()
          }
        }),
        db.user.update({
          where: { id: verificationRequest.userId },
          data: { isVerified: true }
        })
      ])

      // Create notification
      await db.notification.create({
        data: {
          type: 'verification_approved',
          content: 'Your verification request has been approved! Your account is now verified.',
          userId: verificationRequest.userId,
        }
      })
    } else {
      // Reject
      await db.verificationRequest.update({
        where: { id: requestId },
        data: { 
          status: 'rejected',
          reason: reason || 'Your verification request could not be approved at this time.',
          reviewedAt: new Date()
        }
      })

      // Create notification
      await db.notification.create({
        data: {
          type: 'verification_rejected',
          content: 'Your verification request was not approved. You can submit a new request after 30 days.',
          userId: verificationRequest.userId,
        }
      })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Update verification request error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
