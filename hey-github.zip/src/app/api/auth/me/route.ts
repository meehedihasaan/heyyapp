import { NextResponse } from 'next/server'
import { getCurrentUser, getUserStats } from '@/lib/auth'

export async function GET() {
  try {
    const user = await getCurrentUser()
    
    if (!user) {
      return NextResponse.json({ user: null })
    }
    
    const stats = await getUserStats(user.id)
    
    return NextResponse.json({
      user: { ...user, ...stats }
    })
  } catch (error) {
    console.error('Get me error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
