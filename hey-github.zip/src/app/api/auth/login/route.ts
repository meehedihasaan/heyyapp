import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { verifyPassword, setCurrentUser, getUserStats } from '@/lib/auth'

export async function POST(request: NextRequest) {
  try {
    const { username, password } = await request.json()
    
    if (!username || !password) {
      return NextResponse.json({ error: 'Username and password are required' }, { status: 400 })
    }
    
    const user = await db.user.findUnique({ where: { username } })
    
    if (!user) {
      return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 })
    }
    
    const isValid = await verifyPassword(password, user.password)
    
    if (!isValid) {
      return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 })
    }
    
    // Check if user is banned
    if (user.isBanned) {
      return NextResponse.json({ error: 'This account has been banned' }, { status: 403 })
    }
    
    await setCurrentUser(user.id)
    
    const stats = await getUserStats(user.id)
    
    return NextResponse.json({
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        fullName: user.fullName,
        avatar: user.avatar,
        bio: user.bio,
        website: user.website,
        isVerified: user.isVerified,
        isPrivate: user.isPrivate,
        isAdmin: user.isAdmin,
        isBanned: user.isBanned,
        ...stats,
      }
    })
  } catch (error) {
    console.error('Login error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
