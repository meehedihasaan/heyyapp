import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { hashPassword, setCurrentUser, getUserStats } from '@/lib/auth'

export async function POST(request: NextRequest) {
  try {
    const { username, email, password, fullName } = await request.json()
    
    if (!username || !email || !password) {
      return NextResponse.json(
        { error: 'Username, email, and password are required' },
        { status: 400 }
      )
    }
    
    const existingUser = await db.user.findFirst({
      where: {
        OR: [{ username }, { email }]
      }
    })
    
    if (existingUser) {
      return NextResponse.json(
        { error: 'Username or email already exists' },
        { status: 400 }
      )
    }
    
    // Check if this is the first user - make them admin by default
    const userCount = await db.user.count()
    const isFirstUser = userCount === 0
    
    const hashedPassword = await hashPassword(password)
    
    const user = await db.user.create({
      data: {
        username,
        email,
        password: hashedPassword,
        fullName: fullName || null,
        avatar: null,
        isAdmin: isFirstUser, // First user is admin by default
        isVerified: isFirstUser, // First user is also verified by default
      }
    })
    
    await setCurrentUser(user.id)
    
    const stats = await getUserStats(user.id)
    
    return NextResponse.json({
      isNewUser: true,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        fullName: user.fullName,
        avatar: user.avatar,
        bio: user.bio,
        website: user.website,
        isVerified: user.isVerified,
        isPrivate: user.isPrivate,
        isAdmin: user.isAdmin,
        isBanned: user.isBanned,
        ...stats,
      }
    })
  } catch (error) {
    console.error('Register error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
