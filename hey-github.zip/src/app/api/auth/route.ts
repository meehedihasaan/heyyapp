import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'

// Register or Login
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { action, username, email, password, fullName } = body

    if (action === 'register') {
      const existingUser = await db.user.findFirst({
        where: { OR: [{ email }, { username }] }
      })
      
      if (existingUser) {
        return NextResponse.json({ error: 'User already exists' }, { status: 400 })
      }

      const hashedPassword = await bcrypt.hash(password, 10)
      const user = await db.user.create({
        data: {
          username,
          email,
          password: hashedPassword,
          fullName: fullName || username,
          avatar: null
        }
      })

      const { password: _, ...userWithoutPassword } = user
      return NextResponse.json({ user: userWithoutPassword })
    }

    if (action === 'login') {
      const user = await db.user.findUnique({
        where: { email },
        include: {
          _count: { select: { posts: true, followers: true, following: true } }
        }
      })

      if (!user || !(await bcrypt.compare(password, user.password))) {
        return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 })
      }

      const { password: _, ...userWithoutPassword } = user
      return NextResponse.json({ 
        user: {
          ...userWithoutPassword,
          postsCount: user._count.posts,
          followersCount: user._count.followers,
          followingCount: user._count.following
        }
      })
    }

    if (action === 'guest') {
      // Create or get guest user
      let guestUser = await db.user.findUnique({
        where: { email: 'guest@instagram.com' },
        include: {
          _count: { select: { posts: true, followers: true, following: true } }
        }
      })

      if (!guestUser) {
        const hashedPassword = await bcrypt.hash('guest123', 10)
        guestUser = await db.user.create({
          data: {
            username: 'guest_user',
            email: 'guest@instagram.com',
            password: hashedPassword,
            fullName: 'Guest User',
            avatar: null,
            bio: 'Welcome to Instagram!'
          },
          include: {
            _count: { select: { posts: true, followers: true, following: true } }
          }
        })
      }

      const { password: _, ...userWithoutPassword } = guestUser
      return NextResponse.json({ 
        user: {
          ...userWithoutPassword,
          postsCount: guestUser._count.posts,
          followersCount: guestUser._count.followers,
          followingCount: guestUser._count.following
        }
      })
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
  } catch (error) {
    console.error('Auth error:', error)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}

// Update user
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, ...updateData } = body

    const user = await db.user.update({
      where: { id: userId },
      data: updateData
    })

    const { password: _, ...userWithoutPassword } = user
    return NextResponse.json({ user: userWithoutPassword })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update user' }, { status: 500 })
  }
}
