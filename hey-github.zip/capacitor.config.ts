import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.hey.app',
  appName: 'Hey',
  webDir: 'out',
  server: {
    // IMPORTANT: Uncomment and set your deployed URL before building APK
    // Example: url: 'https://your-app.vercel.app',
    // cleartext: true, // Only needed for HTTP (not HTTPS)
    androidScheme: 'https'
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: '#000000',
      androidSplashResourceName: 'splash',
      androidScaleType: 'CENTER_CROP',
      showSpinner: false,
    },
    StatusBar: {
      style: 'Dark',
      backgroundColor: '#000000'
    }
  },
  android: {
    allowMixedContent: true,
    captureInput: true,
    webContentsDebuggingEnabled: false
  }
};

export default config;
